<script>
var num = 1;
var unit_id = "";
var is_region = "<?= $userdata->is_region ?>";
var div_id = "<?= $userdata->div_id ?>";
var sig_div_id = "";

function list_approved_docs(){
  var uid = $("#uid").val();
  var doc_type_id = $("#doc_type_id").val();
  var sub_type = $("#sub_type").val();
    $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {uid:uid,doc_type_id:doc_type_id,sub_type:sub_type},
      url: base_url+'Submit_document/get_employee_to',
      success: function(data){
        var options = "";
        // put all signatories to option
        $.each(data, function(i, value) {
          options += `<option value="${value.dtsno}">
                          ${value.dtsno} - ${value.details}
                        </option>`; 
        });
        if(doc_type_id == 107){
          $(".select_ca").html(options);
        }else{
          if(sub_type == 116){
            $(".select_liq").html(options);
          }else if(sub_type == 118){
            $(".select2_so").html(options);
          }else{
            $(".select2_11").html(options);
          }
        }
      }
    });
  }
  
function to_signatory(){
  var uid = $("#uid").val();
  var daterange = $("#daterange").val();
  var doc_type_id = $("#doc_type_id").val();
  var sub_type_id = $("#sub_type").val();

  if(doc_type_id == 5 || doc_type_id == 107 ){
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Submit_document/generate_signatory",
      dataType: "JSON",
      data:{uid:uid,doc_type_id:doc_type_id, daterange:daterange, dtsno:0},
      success: function(data){
        var doc_detail = "";
        var label, select_name, selected="", num =0;;
        $.each(data.ad_sig, function(i, value) {
          if(value!=false){
            if(value.signatory_id!=0){

              if((data.employee.is_oc == 0) || (value.ads_id != 18 && data.employee.is_oc == 1) ){// add for section / unit id of erdb main if employee is not in OC
                if(num == 0){
                  num = 1;
                  $("#divid").val(value.div_id).change();
                  sig_div_id = value.div_id;
                  unit_id = value.unit_id;
                }
                
              doc_detail += `<input type="hidden" name="to_unit_id[]" value="${value.unit_id}">`;
              doc_detail += `<input type="hidden" name="to_designation_id[]" value="${value.designation}">`;
              doc_detail += `<input type="hidden" name="ads_id[]" value="${value.ads_id}">`;
              doc_detail += `<input type="hidden" name="label[]" value="${value.label}">`;
              doc_detail +=`<label>${value.label}:</label>`;
              doc_detail +=`<select class="form-control" name="sid[]" id="sid${value.ads_id}">`;
                doc_detail += `<option value="0">Not Applicable</option>`; 
              $.each(data.signatories, function(i, val) {
                selected="";
                if(val.uid == value.uid){
                  selected = "selected";
                }
                //if for section / unit id of erdb main
                if(value.ads_id == 18){
                  //show only sicnatory within the same unit
                  if(val.unit_id == value.unit_id){
                    doc_detail += `<option unit_id="${value.unit_id}" div_id="${value.div_id}" value="${val.id}" ${selected}>${val.designation}:${val.lname}, ${val.fname} ${val.mname}</option>`; 
                  } 
                }else{
                  //show all available signatory if
                doc_detail += `<option value="${val.id}" ${selected}>${val.designation}:${val.lname}, ${val.fname} ${val.mname}</option>`; 
                }
              });
              doc_detail += `</select>`;
              }//end if oc == 0
            }
          }
        });
        $("#signature_div").html(doc_detail);
        $.each(data.ad_sig, function(i, value) {
          //enable select2 in signatory select
          $(`#sid${value.ads_id}:last`).select2();
        });
      }
    })
  }
  //Voucher
  if(doc_type_id == 2){
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Submit_document/generate_signatory",
      dataType: "JSON",
      data:{uid:uid,doc_type_id:doc_type_id, daterange:daterange, dtsno:0},
      success: function(data){
        //if division chief or center head remove initial
        if(data.employee.designation == "3" || data.employee.designation == "4" ){
          $("#unit_head_span").hide();
          $("#unit_head").prop("disabled",true);
          $(".dvch").hide();
          $("#initial").prop("disabled",true);
          //show directors office signatory
          $("#approval_span").show();
          $("#approval").prop("disabled",false);
        //if AD or D remove initial and set RC to Director
        }else if(data.employee.designation == "2" || data.employee.designation == "1" || data.employee.unit == 14 ){
          $("#unit_head_span").hide();
          $("#unit_head").prop("disabled",true);
          $(".dvch").hide();
          $("#initial").prop("disabled",true);
          $(".rc").hide();
          $("#rc").prop("disabled",true);
        }else if(data.employee.designation == "8" && data.employee.is_region == "1"){
          $("#unit_head").val(data.employee.user_unit_head_sid).change();
          $("#unit_head_span").show();
          $("#unit_head").prop("disabled",false);
          $(".dvch").show();
          $("#initial").prop("disabled",false);
          $(".rc").show();
          $("#rc").prop("disabled",false);
          //hide directors office signatory
          $("#approval_span").hide();
          $("#approval").prop("disabled",true);
          if(sub_type_id == 116){
            $("#unit_head").prop("disabled",true);
            $("#unit_head_span").hide();
          }
        }else if(data.employee.designation == "6" && data.employee.is_region == "1"){
          $("#unit_head_span").hide();
          $("#unit_head").prop("disabled",true);
          $(".dvch").show();
          $("#initial").prop("disabled",false);
          $(".rc").show();
          $("#rc").prop("disabled",false);
          //hide directors office signatory
          $("#approval_span").hide();
          $("#approval").prop("disabled",true);
        }else if(jQuery.inArray(data.employee.designation, [8,7,6,5]) && data.employee.is_region == "0" && data.employee.division!="1"){
          //hide unit head
          $("#unit_head_span").hide();
          $("#unit_head").prop("disabled",true);
          $(".dvch").show();
          $("#initial").prop("disabled",false);
          $(".rc").show();
          $("#rc").prop("disabled",false);
          //hide directors office signatory
          $("#approval_span").hide();
          $("#approval").prop("disabled",true);
        }else{
          $("#unit_head_span").hide();
          $("#unit_head").prop("disabled",true);
          $(".dvch").show();
          $("#initial").prop("disabled",false);
          $(".rc").show();
          $("#rc").prop("disabled",false);
          //show directors office signatory
          $("#approval_span").show();
          $("#approval").prop("disabled",false);
        }
        $('#r_initial_select:last').select2();
      }
    });
  }//end voucher

}

function getDiv(div_id) {
  $("#divid").prop("disabled",true);
    var unit_options = "";
    $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>General/unit_list",
    dataType: "JSON",
    data:{divunit_id:div_id},
    success: function(data){
      var selected="";
        if(data != false){
            $.each(data, function(i, val) {
              if(unit_id == val.divunit_id){
                selected = 'selected';
              }else{
                selected = '';
              }
            unit_options +=`<option value='${val.divunit_id}' title='${val.divunit_name}' ${selected}>${val.divunit_abv} - ${val.divunit_name}</option>`;
            });
        }
        else{
            unit_options +=`<option value=''>Please Select Division First</option>`;
            }
            $("#unitid").html(unit_options);
            $("#divid").prop("disabled",false);

    }
    });
}

function field_generator(doc_type_id, is_sub_type){
  $.ajax({
  type: "POST",
  dataType: "JSON",
  data: {doc_type_id:doc_type_id, is_sub_type:is_sub_type},
  url: base_url+'Submit_document/get_fields',
  success: function(data){
    let doc_detail="", special_detail="", special_btn="", attachment_detail="";
    
    if(data.subtype){
        doc_detail +=`<label class="red">Sub-Type:</label>
                      <select class="select2_sub_type form-control" name="sub_type" id="sub_type" required>
                      <option value="" selected disabled>Select Sub-Type</option>
                      `;
        $.each(data.subtype, function(key, val) {
          doc_detail += `<option value="${val.id}">${val.doc_t}</option>`;
        });
        doc_detail += `</select>`;
    }
    if(doc_type_id == 117){
    doc_detail +=`<label class="red">Fund Cluster:</label>
                  <select class="form-control" name="fund_cluster" id="fund_cluster" required>
                    <option value="01">01</option>
                    <option value="02">02</option>
                    <option value="07">07</option>
                  </select>
                  `;
    }
    if(doc_type_id==107){
      $(".textarea_span").hide();
      $(".textarea").prop("required",false);
      $(".text_span").hide();
      $(".text").prop("required",false);
    }else{
      $(".textarea_span").show();
      $(".textarea").prop("required",true);
      $(".text_span").show();
      $(".text").prop("required",true);
    }
    $.each(data.doc_detail, function(key, val) {
      unique_case_no = val.unique_case_no;
      let required = (val.is_required == 1)?`required="required"`:``;
      let red = (val.is_required == 1)?`red`:``;
      switch(val.fieldtype){
        case "1":
        doc_detail +=`<span class="text_span ${red}"><label>${val.fieldname}:</label><input type="text" class="form-control text" name="${val.id}" ${required}></span>
                      `;
        break;
        case "3":
        doc_detail +=`<span class="textarea_span ${red}"><label>${val.fieldname}:</label><textarea class="form-control textarea" rows="3" name="${val.id}" ${required}></textarea></span>
                      `;
        break;
        case "4"://for erdb employees list

        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_names erdbnames" name="${val.id}" ${required}  id="uid">`;
                       doc_detail += `<option value="" selected disabled>Select Employee</option>`; 
                      //put all names to option
                      $.each(data.names, function(i, val) {
                       doc_detail += `<option value="${val.uid}">${val.lname}, ${val.fname} ${val.mname}</option>`; 
                      });
       doc_detail +=`</select>`;
          break;
        case "5":

        doc_detail +=`<label class="${red}">${val.fieldname}:</label>`;
        doc_detail +=`<input type="text" class="form-control datepicker_dynamic" name="${val.id}" ${required}>
                      `;
         break;
        case "6":

        doc_detail +=`<label class="${red}">${val.fieldname}:</label>`;
        doc_detail +=`<input type="text" class="form-control daterangepicker_dynamic" name="${val.id}" ${required} id="daterange">
                      `;
         break;
        case "7"://for AD
        //value = array[signatory_id,unique_case_no,fullname]
        doc_detail +=`<span class="rc ${red}"><label>${val.fieldname}:</label>
                      <select class="form-control select2_ra" style="width:100% !important" name="${val.id}" id="rc">`;
                        doc_detail += `<option value="">Not Applicable</option>`; 
                        //put all signatories to option
                        $.each(data.signatories, function(i, val) {
                        if(doc_type_id == 5 && is_region == 1){
                        }else{//if logged user is from erdb main                          
                          if(val.designation_id == "2"){
                            var selected = "selected";
                          }else{
                            var selected = "";
                          }
                        }
                        doc_detail += `<option value="${val.id}" ${selected}>${val.designation}:${val.lname}, ${val.fname} ${val.mname}</option>`; 
                        });
        doc_detail +=`</select></span>`;
        //if logged user is from region and doc type is travel order
         break;
        case "8"://for A(signatory)
        //value = array[signatory_id,unique_case_no,fullname]
        doc_detail +=`<span id="approval_span"><label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_a" style="width:100% !important" name="${val.id}" id="approval" ${required}>`;
                      //put all signatories to option
                      $.each(data.signatories, function(i, val) {
                        //if logged user is from region and doc type is travel order
                        if(doc_type_id == 5 && is_region == 1){
                          if(div_id == val.division && val.designation_id == 4){
                            var selected = "selected";
                          }
                        }else{//if logged user is from erdb main
                          if(val.designation_id == "1"){
                            var selected = "selected";
                          }else{
                            var selected = "";
                          }
                        }
                        doc_detail += `<option  value="${val.id}" ${selected}>${val.designation}:${val.lname},${val.fname}</option>`; 
                      });
        doc_detail +=`</select></span>`;
         break;            
      case "9"://for Division Chief / Center Head
      //value = array[signatory_id,unique_case_no,fullname]
        doc_detail +=`<span class="dvch ${red}"><label>${val.fieldname}:</label>
                      <select class="form-control select2_9" style="width:100% !important" name="${val.id}" id="initial">`;
                      doc_detail += `<option value="">Not Applicable</option>`; 
                      //put all signatories to option
                      $.each(data.signatories, function(i, val) {
                        //if travel order and from region
                      if(doc_type_id == 5 && is_region == 1){
                      }else{
                        if(val.div_id == "<?= $userdata->div_id ?>" && (val.designation_id=='3' || val.designation_id=='4')){
                          var selected = "selected";
                        }else{
                          var selected = "";
                        }
                      }
                        doc_detail += `<option value="${val.id}" ${selected}>${val.designation}:${val.lname},${val.fname}</option>`; 
                      });
        doc_detail +=`</select></span>`;
         break;
       case "10"://for upload file
        doc_detail +=`<input type="hidden" name="upload_id[]" value="${val.id}">`
        doc_detail +=`<div class="box-body box-body-upload" id="file">
                        <div class="form-group form-group-upload">
                            <label for="inputEmail3" class="col-sm-2 control-label ${red}">${val.fieldname}</label>    
                            <div class="input-group col-sm-10">
                                <div class="form-group">
                                <div class="input-group">
                                  <input type="text" class="form-control" readonly>
                                <div class="input-group-btn">
                                  <span class="fileUpload btn btn-success">
                                      <span class="upl" id="upload">Upload file</span>
                                      <input type="file" class="upload up" id="up" name="upload_file${val.id}" accept="application/pdf,application/vnd.ms-excel" ${required}/>
                                    </span><!-- btn-orange -->
                                 </div><!-- btn -->
                                 </div><!-- group -->
                                 </div><!-- form-group -->
                            </div>
                        </div>
                    </div>
                    `
         break;
      case "11"://list of approved TO
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_11"  style="width:100% !important" name="approved_to[]" ${required} multiple="multiple">`;
                      //put all signatories to option
                      // $.each(data.doc_list_to, function(i, value) {
                      //   doc_detail += `<option value="${value.dtsno}">
                      //                   ${value.dtsno}
                      //                 </option>`; 
                      // });
        doc_detail +=`</select>`;
        break;
      case "12"://list of approved IT
        doc_detail +=`<label class="${red}">${val.fieldname}:</label><a class="label label-success pull-right"><span>Create</span></a>
                      <select class="form-control select2_12" style="width:100% !important" name="iot" ${required}>`;
                      doc_detail += `<option value="">Select Linked ${val.fieldname}</option>`; 
                      //put all signatories to option
                      $.each(data.doc_list_it, function(i, value) {
                        doc_detail += `<option value="${value.dtsno}">
                                        ${value.dtsno}
                                      </option>`; 
                      });
        doc_detail +=`</select>`;
        break;
      case "13"://list pf approved OBR
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_13" style="width:100% !important" name="obr" ${required}>`;
                      doc_detail += `<option value="">Select Linked ${val.fieldname}</option>`; 
                      //put all signatories to option
                      $.each(data.doc_list_obr, function(i, value) {
                        doc_detail += `<option value="${value.dtsno}">
                                        ${value.dtsno}
                                      </option>`; 
                      });
        doc_detail +=`</select>`;
        break;
      case "14"://list pf approved COTC
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_14"  style="width:100% !important" name="cotc" ${required}>`;
                      doc_detail += `<option value="">Select Linked ${val.fieldname}</option>`; 
                      //put all signatories to option
                      $.each(data.doc_list_cotc, function(i, value) {
                        doc_detail += `<option value="${value.dtsno}">
                                        ${value.dtsno}
                                      </option>`; 
                      });
        doc_detail +=`</select>`;
        break;
      case "15"://for Accountant
      //value = array[signatory_id,unique_case_no,fullname]
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_15" name="${val.id}" id="initial" style="width:100% !important" ${required}>`;
                      doc_detail += `<option value="">Not Applicable</option>`; 
                      //put all signatories to option
                      $.each(data.signatories, function(i, val) {
                        if(val.designation_id=='5'){
                          var selected = "selected";
                        }else{
                          var selected = "";
                        }
                        doc_detail += `<option value="${val.id}" ${selected}>${val.designation}:${val.lname},${val.fname}</option>`; 
                      });
        doc_detail +=`</select>`;
         break;      
      case "16"://for Unit Head
      //value = array[signatory_id,unique_case_no,fullname]
        doc_detail +=`<span id="unit_head_span"><label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_16" name="${val.id}" id="unit_head" style="width:100% !important" ${required}>`;
                      doc_detail += `<option value="">Not Applicable</option>`; 
                      //put all signatories to option
                      $.each(data.signatories, function(i, val) {
                        if(val.unit_id == "<?= $userdata->unit_id ?>"){
                          var selected = "selected";
                        }else{
                          var selected = "";
                        }
                        doc_detail += `<option value="${val.id}" ${selected} unit_id="${val.unit_id}">${val.designation}:${val.lname},${val.fname}</option>`; 
                      });
        doc_detail +=`</select></span>`;
         break;        
      case "17"://for Budget Officer
      //value = array[signatory_id,unique_case_no,fullname]
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_17" name="${val.id}" id="initial" ${required}>`;
                      doc_detail += `<option value="">Not Applicable</option>`; 
                      //put all signatories to option
                      $.each(data.signatories, function(i, val) {
                        if(val.designation_id=='7'){
                          var selected = "selected";
                        }else{
                          var selected = "";
                        }
                        doc_detail += `<option value="${val.id}" ${selected}>${val.designation}:${val.lname},${val.fname}</option>`; 
                      });
        doc_detail +=`</select>`;
        break;
        case "18"://list approve CA
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select_ca" name="approved_ca" id="approved_ca" ${required} `;
        doc_detail +=`</select>`;
        break;      
        case "19"://list approve liquidation of CA
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select_liq" name="approved_liq" id="select_liq" ${required} >`;
        doc_detail +=`</select>`;
        break;      
        case "20"://list of RC
        doc_detail +=`<label class="${red}">Responsibility Center:</label>
                      <select class="form-control select2_rc" name="${val.id}" id="select2_rc" ${required} >`;
                      doc_detail += `<option value="">Not Applicable</option>`; 
                      //put all signatories to option
                      $.each(data.rc, function(i, val) {
                        doc_detail += `<option value="${val.id}" rc_desc="${val.description} (${val.code})">${val.description} (${val.code})</option>`; 
                      });
        doc_detail +=`</select>`;
        doc_detail +=`<input type="hidden" name="rc_desc" id="rc_desc">`;
        doc_detail +=`<input type="hidden" name="rc_id" id="rc_id">`;
        break;      
        case "21"://list of Approved DV
        doc_detail +=`<label class="${red}">Approve DV:</label>
                      <select class="form-control select2_dv" name="dv_dtsno[]" id="select2_dv" ${required} multiple>`;
                      //put all signatories to option
                      $.each(data.dv, function(i, val) {
                        doc_detail += `<option value="${val.dtsno}">${val.fund_cluster} - ${val.approved_number} - ${val.fullname} - ${val.dtsno}</option>`; 
                      });
        doc_detail +=`</select>`;
        break;      
        case "22"://list of SO
        doc_detail +=`<label class="${red}">Special Order:</label>
                      <select class="form-control select2_so" name="so_dtsno" id="select2_so" ${required}>`;
        doc_detail +=`</select>`;
        break;
        case "23"://Yes or No
        doc_detail +=`<label class="${red}">${val.fieldname}:</label>
                      <select class="form-control select2_yn" name="${val.id}" id="select2_yn" ${required}>
                      <option value="NO">NO</option>
                      <option value="YES">YES</option>
                      </select>`;
        doc_detail +=`</select>`;
        break;      
       }
    });

    $("#special_detail").html(special_detail);
    if(is_sub_type == 0){
    attachment_detail +=`<div class="box-body box-body-upload" id="file">
                    <div class="form-group form-group-upload">
                        <label for="inputEmail3" class="col-sm-2 control-label">Attach File</label>    
                        <div class="input-group col-sm-10">
                            <div class="form-group">
                            <div class="input-group">
                              <input type="text" class="form-control" readonly>
                            <div class="input-group-btn">
                              <span class="fileUpload btn btn-success">
                                  <span class="upl" id="upload">Upload file</span>
                                  <input type="file" class="upload up" id="up" name="upload_file_general" accept="application/pdf"/>
                                </span><!-- btn-orange -->
                             </div><!-- btn -->
                             </div><!-- group -->
                             </div><!-- form-group -->
                        </div>
                    </div>
                </div>
                `;
      $("#attachment_detail").html(attachment_detail);
      $("#sub_type_details").html("");
      doc_detail += `<div class="for_region_initial"></div>`;
      $("#doc_details_body").html(doc_detail);
    }else{
      $("#sub_type_details").html(doc_detail);
    }
    //initialize dynamically created select2
    $('.select2_names:last').select2();
    $('.select2_ra:last').select2();
    $('.select2_a:last').select2();
    $('.select2_9:last').select2();
    $('.select2_15:last').select2();
    $('.select2_16:last').select2();
    $('.select2_17:last').select2();
    $('.select2_11:last').select2();
    $('.select2_12:last').select2();
    $('.select2_13:last').select2();
    $('.select2_14:last').select2();
    $('.select2_sub_type:last').select2();
    $('.select2_ca:last').select2();
    $('.select2_rc:last').select2();
    $('.select2_dv:last').select2();
    $('.select2_so:last').select2();
    $("#doc_type_id").prop("disabled",false);
    $("#sub_type").prop("disabled",false);

 //  $("#uid").select2({
 //  ajax: { 
 //   url: "<?php echo base_url(); ?>Submit_document/erdb_employee",
 //   type: "post",
 //   dataType: 'json',
 //   delay: 250,
 //   data: function (params) {
 //    return {
 //      doc_type_id: $("#doc_type_id").val(), // search term
 //      search: params.term, // search term
 //    };
 //   },
 //  processResults: function (data) {
 //    // add ALL to array
 //    if(data.length >= 20 ){
 //      data.unshift({
 //        name : 'ALL', 
 //        id : ''
 //      });
 //    }
 //      return {
 //        results: $.map(data, function (item) {
 //          return {
 //            text: item.fullname,
 //            id: item.uid
 //          }
 //        })
 //      };
 //    }
 //  }
 // }); 
    //initialize dynamically created datepicker
    $('.datepicker_dynamic').datepicker({ 
      dateFormat: 'MM dd, yy', 
    }).datepicker("setDate",'now');
    //initialize dynamically created daterangepicker
    $('.daterangepicker_dynamic').daterangepicker({
      // autoUpdateInput: false,
      autoApply: true,
      locale: {
          format: 'MMMM D, YYYY'
        }
    });
  }
});
}
// Initialize select2
$(document).ready(function() {  

  $("#doc_details_body").on("change","#uid", function(e){
    e.preventDefault();
    to_signatory();
    list_approved_docs();
  })
  $("#doc_details_body").on("change","#daterange", function(e){
    e.preventDefault();
    to_signatory();
  })
  $("#doc_type_id").change(function(){
    var doc_type_id = $(this).val();
    var is_sub_type = 0;
    $("#signature_div").html("");
    $("#doc_type_id").prop("disabled",true);
      if($(this).val() == 5){
        $("#divid").attr('readonly', 'readonly');
        $("#unitid").attr('readonly', 'readonly');
      }else{
        $("#divid").removeAttr('readonly');
        $("#unitid").removeAttr('readonly');
      }
    field_generator(doc_type_id, is_sub_type)
  })   

  $("#signature_div").on('change','#sid18',function(){
      if($(this).val() == 0){
        $("#divid").removeAttr('readonly');
        $("#unitid").removeAttr('readonly');
      }else{
        var element = $(this).find('option:selected');       
        $("#divid").val(element.attr("div_id")).change();
        $("#divid").attr('readonly', 'readonly');
        $("#unitid").attr('readonly', 'readonly');
      }
  })

  $("#doc_details_body").on('change','#sub_type',function(){
    var doc_type_id = $(this).val();
    var is_sub_type = 1;
    $("#sub_type").prop("disabled",true);
    field_generator(doc_type_id, is_sub_type);
    to_signatory();
    list_approved_docs();
  })    

  $("#doc_details_body").on('change','#select2_rc',function(){
    var rc_desc = $('option:selected', this).attr('rc_desc');
    var rc_id = $(this).val();
    $("#rc_desc").val(rc_desc);
    $("#rc_id").val(rc_id);
  })    

  $("#add_track").click(function(e){
    e.preventDefault();
    var action_req = ($('#copy_last_detail').is(":checked"))?$('#action_req').val():'';
    num++;
    $.ajax({
      type: "POST",
      data: {num:num, action_req:action_req},
      url: base_url+'Submit_document/add_track',
      success: function(data){
        $("#track_details_copy").append(data);
      }
    });
  })

  $(".content").on("click",'.remove_track',function(e){
    e.preventDefault();
    if(num>1){
      num--;
      $('#track_details_copy .track_details_copy:last').remove();
    }else{
      toastr.warning("Tracks Cannot be Empty!");
    }
  })

  $("#btnSubmit").click(function (e) {
    if($("#form1")[0].checkValidity()!=false){
      e.preventDefault();
      var doc_type_id = $("#doc_type_id").val();
      var form_data = new FormData($('#form1')[0]);
      var url = "<?php echo base_url(); ?>Submit_document/add";
      $.ajax({
          type: "POST",
          url: url,
          dataType: "JSON",
          data:form_data,
          contentType: false, 
          processData: false, 
          success: function(data){
            if(data){
              window.location.replace("<?php echo base_url(); ?>Document/"+data);
            }else{
              toastr.warning("Something Went Wrong!");
            }
          }
      });
    }
  });

  $("#doc_details_body").on('change','#initial', function(){
    var uid = $('option:selected', this).attr('uid');
    var div_id = $('option:selected', this).attr('div_id');
    var unit_id = $('option:selected', this).attr('unit_id');
    $("#initial_uid").val(uid);
    $("#initial_div_id").val(div_id);
    $("#initial_unit_id").val(unit_id);
  })

  $("#doc_details_body").on('change','#approval', function(){
    var uid = $('option:selected', this).attr('uid');
    var div_id = $('option:selected', this).attr('div_id');
    var unit_id = $('option:selected', this).attr('unit_id');
    $("#approval_uid").val(uid);
    $("#approval_div_id").val(div_id);
    $("#approval_unit_id").val(unit_id);
  })

  $("#doc_details_body").on('change','#rc', function(){
    var uid = $('option:selected', this).attr('uid');
    var div_id = $('option:selected', this).attr('div_id');
    var unit_id = $('option:selected', this).attr('unit_id');
    $("#rc_uid").val(uid);
    $("#rc_div_id").val(div_id);
    $("#rc_unit_id").val(unit_id);
  })

  $("#special_detail").on('click','#add_obr_details', function(){
    var tbody;
    tbody += `<tr>
                <td><input type="text" class="form-control" name="rc_code[]"></td>
                <td><input type="text" class="form-control" name="rc_desc[]"></td>
                <td><input type="text" class="form-control" name="mfo[]"></td>
                <td><input type="text" class="form-control" name="uacs_code[]"></td>
                <td><input type="text" class="form-control" name="uacs_desc[]"></td>
                <td><input type="text" class="form-control" name="amount[]"></td>
              </tr>
            `;
            $("#obr_tbody").append(tbody);
  });

  $("#special_detail").on('click','#remove_obr_details', function(){
    $("#obr_table").each(function(){
        if($('tr', this).length > 2){
            $('tbody tr:last', this).remove();
        }else {
            alert("Cannot remove all row!")
        }
    });
  });

  $("#doc_details_body").on('change','#fund_cluster', function(){
    $.ajax({
      type: "POST",
      data: {fund_cluster:$(this).val()},
      url: base_url+'Submit_document/list_ada_dv',
      dataType: "JSON",
      success: function(data){
        var options = "";
        if(data){
          $.each(data, function(i, val) {
            options += `<option value="${val.dtsno}">
                          ${val.fund_cluster} - ${val.approved_number} - ${val.fullname} - ${val.dtsno}
                        </option>`; 
          });
        }
        $("#select2_dv").html(options);
        $("#track_details_copy").append(data);
      }
    });
  });

})

$(document).on('change','.up', function(){
  myfile= $( this ).val();
  var ext = myfile.split('.').pop();
  if(ext=="pdf"){
    var names = [];
    var length = $(this).get(0).files.length;
    var file = event.target.files[0];
    if(file.size<=50*1024*1024) {
      for (var i = 0; i < $(this).get(0).files.length; ++i) {
        names.push($(this).get(0).files[i].name);
      }
        // $("input[name=file]").val(names);
      if(length>2){
        var fileName = names.join(', ');
        $(this).closest('.form-group').find('.form-control').attr("value",length+" files selected");
      }
      else{
        $(this).closest('.form-group').find('.form-control').attr("value",names);
      }
    }else{
      $( this ).val('');
      $(this).closest('.form-group').find('.form-control').attr("value",'');
      alert('Max file size is 50mb!')
    }
  }else{
    $(this).closest('.form-group').find('.form-control').attr("value",'');
    $( this ).val('');
    alert(ext + ' Not Allowed!')
  }
 
});
</script>