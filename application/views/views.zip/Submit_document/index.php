<style>
.header-inside{
    padding: 2px;
}
.fileUpload {
    position: relative;
    overflow: hidden;
}
.red{
    color: red !important;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
.pdfobject-container, #display_pdf { 
    height: 550px; 
    border: 
    1rem solid rgba(0,0,0,.1); 
}
.form-group-upload {
    margin-bottom: 0px !important;
}
.box-body-upload {
    padding: 3px !important;
}
</style>
<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        Create Document
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Create Document</li>
        </ol>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <form id="form1" action="<?= base_url().'Submit_document/new'?>" method="POST">
                    <div class="col-lg-7 col-md-7">
                     <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Select Document Type</h3>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <select class="form-control select2" name="doc_type_id" id="doc_type_id" required="required">
                                    <option value="" selected disabled="">Select Document Type</option>
                                    <?php
                                    foreach($doc_type as $val){
                                        if($val->id == 117){
                                            if( $userdata->unit_id == 21 || $userdata->unit_id == 71 ){
                                                echo "<option value='$val->id'>$val->doc_t</option>";
                                            }
                                        }else{
                                            echo "<option value='$val->id'>$val->doc_t</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                     </div>
                     <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Add Document Details</h3>
                        </div>
                        <div class="box-body" >
                            <div id="doc_details_body"></div>
                            <hr>
                            <div id="signature_div"></div>
                        </div>
                        <div class="box-body" id="sub_type_details">
                        </div>
                        <div class="box-body" id="attachment_detail">
                        </div>
                     </div>
                    </div>

                    <div class="col-lg-5 col-md-5">
                     <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Input Tracks Details</h3>
                            <button class="label label-warning pull-right remove_track" id="remove_track">
                                Remove Track <i class="fa fa-minus-circle"></i>
                            </button>

                            <button class="label label-primary pull-right " id="add_track">
                                Add Track <i class="fa fa-plus-circle"></i>
                            </button>
                        </div>
                        <div class="box-body" id="track_details_body">
                            <div class="box box-default">
                                <span class="pull-right" style="font-size: 16px;">
                                <label>
                                <input type="checkbox" name="copy_last_detail" id="copy_last_detail"> Copy Last Detail
                                </label>
                                </span>
                               <br><br>
                            </div>


                            <div class="box box-default">
                            <div class="box-header with-border header-inside">
                                <h1 class="box-title">Track 1</h1>
                            </div>
                            <div class="form-group" >
                                <label for="divid" class="col-sm-2 control-label">Division</label>
                                <div class="col-sm-10">
                                    <select class="select2 form-control divid" id="divid" name="div_id[]" onChange="getDiv(this.value);" required="required">
                                        <option value="" selected disabled>Select Division</option>
                                        <?php foreach($division as $val){ ?>
                                            <option value="<?= $val->divunit_id?>"><?= $val->divunit_abv ." - ".$val->divunit_name?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group" >
                                <label for="unitid" class="col-sm-2 control-label">Unit</label>
                                <div class="col-sm-10">
                                    <select class="select2 form-control unitid" id="unitid" name="unit_id[]" id="unitid"  required="required">
                                        <option value="" selected disabled>Select Division First</option>
                                    </select>
                                    <br>
                                </div>
                            </div>

                            <div class="form-group" >
                                <label for="unitid" class="col-sm-2 control-label">Action Requested</label>
                                <div class="col-sm-10">
                                    <input list="encodings"  value="" class="form-control" name="action_req[]" id="action_req" required="required">
                                    <datalist id="encodings">
                                        <?php foreach($action_list as $val){ ?>
                                        <option value="<?= $val->action_requested ?>"><?= $val->action_requested ?></option>
                                        <?php } ?>
                                    </datalist>
                                    <br>
                                </div>
                            </div>
                        </div>

                        </div>
                        <div class="box-body" id="track_details_copy">
                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary pull-right" id="btnSubmit">Submit</button>
                        </div>
                    </div>
                   </div>

                    <div class="col-lg-12 col-md-12" id="special_detail">
                    </div>
                </form>
            </div>
        </div>
</div>
<?php  $this->load->view('Submit_document/submit_document_js'); ?>
