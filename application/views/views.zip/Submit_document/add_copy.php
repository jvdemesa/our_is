<script>
 $('.select2_tracks').select2({ width: '100%' });
 function getDiv<?= $num ?>(e) {
    var unit_options = "";
    $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>General/unit_list",
    dataType: "JSON",
    data:{divunit_id:e.value},
    success: function(data){
        if(data != false){
            unit_options +=`<option value=''>Select Unit</option>`;
            $.each(data, function(i, val) {
            unit_options +=`<option value='${val.divunit_id}' title='${val.divunit_name}'>${val.divunit_abv} - ${val.divunit_name}</option>`;
            });
        }
        else{
            unit_options +=`<option value=''>Please Select Division First</option>`;
            }
            $("#unitid<?= $num ?>").html(unit_options);
    }
    });
}
</script>
<div class="box-body track_details_copy" id="track_details_copy">
 <div class="box box-default">
    <div class="box-header with-border header-inside">
        <h1 class="box-title track_count">Track <?= $num ?></h1>
    </div>
    <div class="form-group" >
        <label for="divid" class="col-sm-2 control-label">Division</label>
        <div class="col-sm-10">
            <select class="select2_tracks form-control" id="divid" name="div_id[]" onChange="getDiv<?= $num ?>(this);" required="required">
                <option value="" selected disabled>Select Division</option>
                <?php foreach($division as $val){ ?>
                    <option value="<?= $val->divunit_id?>"><?= $val->divunit_abv ." - ".$val->divunit_name?></option>
                <?php } ?>
            </select>
        </div>
    </div>
    <div class="form-grop" >
        <label for="unitiud" class="col-sm-2 control-label">Unit</label>
        <div class="col-sm-10">
            <select class="select2_tracks form-control" id="unitid<?= $num ?>" name="unit_id[]" required="required">
                <option value="">Select Division First</option>
            </select>
            <br>
        </div>
    </div>

    <div class="form-group" >
        <label for="unitid" class="col-sm-2 control-label">Action Requested</label>
        <div class="col-sm-10">
            <input list="encodings"  value="<?= $action_req ?>" class="form-control" name="action_req[]" id="action_req" required="required">
            <datalist id="encodings">
                <?php foreach($action_list as $val){ ?>
                <option value="<?= $val->action_requested ?>"><?= $val->action_requested ?></option>
                <?php } ?>
            </datalist>
            <br>
        </div>
    </div>
</div>
</div>