
<div class="modal fade" id="sign_pad_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header modal-header-success">
          <button type="button" class="close" 
             data-dismiss="modal">
                 <span aria-hidden="true">&times;</span>
                 <span class="sr-only">Close</span>
          </button>
          <h4 class="modal-title">
              <p>Draw signature</p>
          </h4>
      </div>
        
        <!-- Modal Body -->
        <div class="modal-body">
            <div style="height: 480px; width:100%;">
               <iframe id="frame_signature_pad" height="480" width="100%"  src="<?php echo base_url(); ?>signature_pad" ></iframe>
             
            </div>
        </div>
        <div class="modal-footer" align="right">
            <div class="form-group">
                <div class="col-sm-12" align="right">
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                    Close
                    </button>
                    <button type="button" class="btn btn-success" onclick="save_signature()" >Save</button>
                </div>
            </div>
        </div>
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->

<div class="modal fade" id="initial_sign_pad_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header modal-header-success">
                <button type="button" class="close" 
                    data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title">
                    <p>Draw initial signature</p>
                </h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <div style="height: 480px; width:100%;">
                    <iframe id="frame_initial_signature_pad" height="480" width="100%"  src="<?php echo base_url(); ?>signature_pad/initial_sinature" ></iframe>
                </div>
            </div>
            <div class="modal-footer" align="right">
                <div class="form-group">
                    <div class="col-sm-12" align="right">
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                        Close
                        </button>
                        <button type="button" class="btn btn-success" onclick="save_initial_signature()" >Save</button>
                    </div>
                </div>
            </div>
        </div><!--end Modal body-->
    </div><!--end Modal dialog-->
</div><!--end modal receive-->