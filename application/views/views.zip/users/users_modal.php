<div class="modal fade" id="modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header modal-header-success">
          <button type="button" class="close" 
             data-dismiss="modal">
                 <span aria-hidden="true">&times;</span>
                 <span class="sr-only">Close</span>
          </button>
          <h4 class="modal-title" id="myModalLabel">
              <p id="modal_title_add"></p>
          </h4>
      </div>
        
        <!-- Modal Body -->
      <div class="modal-body">
        <form method="POST" id="form1" class="form-horizontal" role="form" action="<?php echo base_url()."users/add_users"; ?>">
          <input type="hidden" name="uid" id="uid">
          <input type="hidden" name="display_pic" id="display_pic">
          <div class="table table-responsive">
          <table class="table table-bordered table-hover">
            <tr>
              <td colspan="2">
                <label>First Name:</label> 
                <input type="text" name="fname" id="fname" class="form-control uppercase" required="required"/>
              </td>
              <td colspan="2">
                <label>Last Name:</label>
                <input type="text" name="lname" id="lname" class="form-control uppercase" required="required"/></td>
              <td colspan="2">
                <label>Middle Name:</label>
                <input type="text" name="mname" id="mname" class="form-control uppercase"/>
              </td>
            </tr>
            <tr>
              <td colspan="2">
                <label>Middle Initial:</label>
                <input type="text" name="middle_initial" id="middle_initial" class="form-control uppercase"/>
              </td>
              <td colspan="4">
                <label>Suffix:</label>
                <select class="select2" name="suffix" id="suffix">
                  <option value="" selected>Not Applicable</option>
                  <option value="Sr.">Sr.</option>
                  <option value="Jr.">Jr.</option>
                  <option value="II">II</option>
                  <option value="III">III</option>
                </select>
              </td>
            </tr>
            <tr>
              <td colspan="2">
                Position:
                <select name="position" class="select2 position" required="required" >
                 <option></option>
                  <?php 
                  foreach($positions as $pos) 
                  { 
                  ?>
                  <option value="<?php echo $pos->posidkey; ?>"><?php echo $pos->position; ?></option>
                  <?php 
                  } 
                  ?>
                </select>
              </td>
              <td colspan="2">
                Division:
                <select name="division" onChange="getDiv(this.value);" class="division select2" required="required">
                  <option value="" selected disabled>Division/Center*</option>
                  <?php 
                  foreach($divunit as $divunit_list) 
                  { 
                  ?>
                  <option value="<?php echo $divunit_list->divunit_id; ?>" ><?php echo $divunit_list->divunit_abv; ?></option>
                  <?php 
                  } 
                  ?>
                </select>
              </td>
              <td colspan="2">
                Unit:
                <select required="required" name="unit" id="unit" class="form-control input-sm select2 unit">
                  <option value="" selected disabled>Select Division First</option>
                </select>
              </td>
            </tr>
            <tr>
              <td colspan="2">
                Province:
                <select name="provCode" id="provCode" class="select2 provCode" required="required" >
                 <option value="" selected disabled>Select Province</option>
                  <?php 
                  foreach($province as $val) 
                  { 
                  ?>
                  <option value="<?php echo $val->provCode; ?>" province="<?= $val->provDesc ?>"><?php echo $val->provDesc; ?></option>
                  <?php 
                  } 
                  ?>
                </select>
                <input type="hidden" name="province" id="province" class="province">
              </td>
              <td colspan="2">
                City / Municipality:
                <select name="citymunCode" id="citymunCode" class="citymunCode select2" required="required">
                 <option value="" selected disabled>Select Province First</option>
                </select>
                <input type="hidden" name="citymun" id="citymun" class="citymun">
              </td>
              <td colspan="2">
                Barangay:
                <select required="required" name="brgyCode" id="brgyCode" class="form-control input-sm select2 brgyCode">
                 <option value="" selected disabled>Select City / Municipality First</option>
                </select>
                <input type="hidden" name="brgy" id="brgy" class="brgy">
              </td>
            </tr>
            <tr>
              <td colspan="2">
                Employment Status:
                <select name="employmentStatus" class="form-control select2 employmentStatus" required="required" >
                  <option value="contractual">Contractual</option>
                  <option value="regular">Regular</option>
                </select>
              </td>
                <td>Email Address:
                  <input type="email" name="email" id="email"  class="form-control"/>
                </td>
              <td colspan="2">
                ID Number:
                <input type="text" name="idnum" id="idnum"  class="form-control"/>
              </td>
              </tr>
                <td>Official Station: </td>
                <td colspan="2">
                  <select name="official_station" id="official_station" class="select2">
                    <option value="" selected disabled>Select Official Station</option>
                    <?php foreach($official_station as $val){ 
                      echo "<option value='{$val->id}'>{$val->official_station}</option>";
                    }?>
                  </select>
                </td>
                <td width="30%" rowspan="7" colspan="3">
                  <p>Select Image: <input type="file" id="images" class="form-control btn btn-primary"></p>
                  <div id="croppie_div">
                    <div class="col-sm-12" id="upload-image">
                    </div>
                    <center>
                      <button type="button" id="rotateLeft" data-rotate="90" class="btn btn-success">Rotate Left</button>
                      <button type="button" id="rotateRight" data-rotate="-90" class="btn btn-success">Rotate Right</button>
                    </center>
                  </div>
                  <center>
                    <div id="current_dp"></div>
                  </center>
                </td>
              </tr>
<!--               <tr>
                <td>Bank Account Number: </td>
                <td colspan="2">
                  <input type="text" name="bank_acc_no" id="bank_acc_no" class="form-control" required="required"/>
                </td>
              </tr>
 -->              </tr>
                <td>username: </td>
                <td colspan="2">
                  <input type="text" name="username" id="username" class="form-control" required="required"/>
                </td>
              </tr>
              <tr>
                  <td>Password: </td>
                  <td colspan="2"><input type="password" name="password" id="password"  class="form-control"/></td>
              </tr>
              <tr>
                  <td>PMS Access Type: </td>
                  <td colspan="2">
                      <select name="access[]" id="access" class="form-control select2"  multiple="multiple" style="width: 100%">
                        <?php foreach($at_list as $val){
                          echo "<option value='".$val->at_id."'>".$val->access_type."</option>";
                        }?>
                      </select>
                  </td>
              </tr>
              <tr>
                  <td>DTS Privilege: </td>
                  <td colspan="2">
                      <select name="privilege[]" id="privilege" class="form-control select2"  multiple="multiple" style="width: 100%">
                        <?php foreach($at_list as $val){
                          echo "<option value='".$val->at_id."'>".$val->access_type."</option>";
                        }?>
                      </select>
                  </td>
              </tr>
             <tr>
                  <td>Home Page: </td>
                  <td colspan="2">
                      <select name="home_page" id="home_page" class="form-control select2" style="width: 100%">
                        <option value='' selected disabled>Select Home Page</option>
                        <?php foreach($link_list as $val){
                          echo "<option value='".$val->link_id."'>".$val->link."</option>";
                        }?>
                      </select>
                  </td>
              </tr>
             <tr>
                  <td>Signature: </td>
                  <td colspan="2">
                    <p>
                      <input type="file" class="upload up" id="up" name="signature" accept="image/png, image/gif, image/jpeg" />
                    </p>
                  </td>
              </tr>
           </table>
         </div>
            <!--SUBMIT BUTTON -->
          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                   Close
                </button>
                <button type="submit" class="btn btn-success" id="submit_add">Save</button>
              </div>
            </div>
           </div>
        </form>
      </div><!--end Modal body-->
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->

<div class="modal fade" id="acc_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header modal-header-success">
          <button type="button" class="close" 
             data-dismiss="modal">
                 <span aria-hidden="true">&times;</span>
                 <span class="sr-only">Close</span>
          </button>
          <h4 class="modal-title" id="myModalLabel">
              Update User
          </h4>
      </div>
        
        <!-- Modal Body -->
      <div class="modal-body">
        <form method="POST" id="form1" class="form-horizontal" role="form" action="<?php echo base_url()."Users_acc/update_bank_acc"; ?>">
          <input type="hidden" name="uid" id="uid_acc">
          <div class="table table-responsive">
                <label>First Name:</label> 
                <input type="text" name="fname" id="fname_acc" class="form-control uppercase" required="required" readonly="readonly" />
                <label>Last Name:</label>
                <input type="text" name="lname" id="lname_acc" class="form-control uppercase" required="required" readonly="readonly" /></td>
                <label>Middle Name:</label>
                <input type="text" name="mname" id="mname_acc" class="form-control uppercase"/>
                <label>Bank Account Number: </label>
                <input type="text" name="bank_acc_no" id="bank_acc_no_acc" class="form-control" required="required"/>
         </div>
            <!--SUBMIT BUTTON -->
          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                   Close
                </button>
                <button type="submit" class="btn btn-success" id="submit_add">Save</button>
              </div>
            </div>
           </div>
        </form>
      </div><!--end Modal body-->
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->


<div class="modal fade" id="reset_pw_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header modal-header-success">
          <button type="button" class="close" 
             data-dismiss="modal">
                 <span aria-hidden="true">&times;</span>
                 <span class="sr-only">Close</span>
          </button>
          <h4 class="modal-title" id="myModalLabel">
              Password Reset
          </h4>
      </div>
        
        <!-- Modal Body -->
      <div class="modal-body">
        <div id="pw_body">
        </div>
            <!--SUBMIT BUTTON -->
          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-success" id="copy_pw">Copy and Close</button>
              </div>
            </div>
           </div>
        </form>
      </div><!--end Modal body-->
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->