<link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/croppie/croppie.css">
<script src="<?php echo base_url(); ?>assets/js/croppie/croppie.min.js"></script>

<script>
var unit_id = "", selected_provCode="", selected_citymunCode="", selected_brgyCode="", selected_citymun="",selected_brgy="";
var $image_crop;
function getDiv(val) {
  
    var unit_options="";
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>General/unit_list",
      dataType: "JSON",
      data:'divunit_id='+val,
      success: function(data){
        if(data != false){
            unit_options +=`<option value='' selected disabled>Select Unit</option>`;
            $.each(data, function(i, val) {
            unit_options +="<option value='"+val.divunit_id+"' title='"+val.divunit_name+"'>"+val.divunit_abv+"</option>";
            });
        }
        else{
            unit_options +="<option value=''>Please Select Division First</option>";
        }
        $("#unit").html(unit_options);
        if(unit_id != ""){
          $(".unit").val(unit_id).change();     
        }
      }
    });
  }

  function save_signature() {
    var dataUrl =  document.getElementById('frame_signature_pad').contentWindow.getDataUrl();

    if(dataUrl) {
      $('#signed_image').attr('src', dataUrl);
      $('#input_signature_img').val( dataUrl);
      $('#sign_pad_modal').modal('hide');

      $('html, body').animate({ scrollTop: $('#signed_image').offset().top }, 'slow');
    }
  }

  function save_initial_signature() {
    var dataUrl =  document.getElementById('frame_initial_signature_pad').contentWindow.getDataUrl();

    if(dataUrl) {
      $('#initial_signed_image').attr('src', dataUrl);
      $('#input_initial_signature_img').val( dataUrl);
      $('#initial_sign_pad_modal').modal('hide');

      $('html, body').animate({ scrollTop: $('#initial_signed_image').offset().top }, 'slow');
    }
  }



  function get_brgy_list(citymunCode, citymun){
      $("#citymun").val(citymun);
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>General/get_brgy_list",
        dataType: "JSON",
        data:{citymunCode:citymunCode},
        success: function(data){
          var options = "<option value='' selected disabled>Select Brgy</option>";
          $.each(data, function(i, val) {
            if(selected_brgyCode == val.brgyCode){
              options +=`<option selected value="${val.brgyCode}" brgy="${val.brgyDesc}">${val.brgyDesc}</option>`;
            }else{
              options +=`<option value="${val.brgyCode}" brgy="${val.brgyDesc}">${val.brgyDesc}</option>`;
            }
          })
          $("#brgyCode").html(options);
          $("#brgyCode").val(selected_brgyCode).change();
        }
      })
  }

  function check(src) {
  return $("<img>").attr('src', src);
}
  $('#croppie_div').hide();
   $image_crop = $('#upload-image').croppie({
    enableExif: true,
    viewport: {
        width: 200,
        height: 200,
        type: 'circle',
    },
    boundary: {
        width: 300,
        height: 300
    },
    showZoomer: true,
    enableOrientation: true
});
$('#images').on('change', function () { 
    $('#croppie_div').show();
    $('#current_dp').hide();
    var reader = new FileReader();
    reader.onload = function (e) {
        $image_crop.croppie('bind', {
            url: e.target.result
        }).then(function(){
            console.log('jQuery bind complete');
        });         
    }
    reader.readAsDataURL(this.files[0]);
});
$(document).ready(function() {
  $('input[name=action_signature]').change( function(e) {
    $('input[name=action_signature]').not(this).prop('checked', false);  
    if($(this).val() == 2) {
      $('#signed_image').show();
      $('#up').hide();
    } else {
      $('#signed_image').hide();
      $('#up').show();
    }
  });

  $('input[name=action_initial_signature]').change( function(e) {
    $('input[name=action_initial_signature]').not(this).prop('checked', false);  
    if($(this).val() == 2) {
      $('#initial_signed_image').show();
      $('#initial_up').hide();
    } else {
      $('#initial_signed_image').hide();
      $('#initial_up').show();
    }
  });

  $( "#draw_signature_btn" ).click(function(e) {
    e.preventDefault();
    $("#check_draw_signature").prop('checked', true).trigger('change');
    $('#sign_pad_modal').modal('show');
    return false;
  });
  
  $( "#draw_initial_signature_btn" ).click(function(e) {
    e.preventDefault();
    $("#check_draw_initial_signature").prop('checked', true).trigger('change');
    $('#initial_sign_pad_modal').modal('show');
    return false;
  });


  $("#filter").click(function(e){
    table.ajax.reload( null, false );
  }) 
  
  $( "#rotateLeft" ).click(function(e) {
    e.preventDefault();
            $image_crop.croppie('rotate', parseInt($(this).data('rotate')));
        });
       
        $( "#rotateRight" ).click(function() {
            $image_crop.croppie('rotate',parseInt($(this).data('rotate')));
        });

    $( "#form1" ).on( "click", "#submit_add", function(e) {
        e.preventDefault();
        
        if ( $('input[name=action_signature]:checked').val() != undefined ) {
            if ( $('input[name=action_signature]:checked').val() == 1 && $.trim( $('#up').val()) =='' ) {
                toastr.error("Please upload a signature.");
            } else if($('input[name=action_signature]:checked').val() == 2 && $.trim( $('#input_signature_img').val())  =='' )  {
                toastr.error("Please draw a signature.");
            }
        }

        if ( $('input[name=action_initial_signature]:checked').val() != undefined ) {
            if ( $('input[name=action_initial_signature]:checked').val() == 1 && $.trim( $('#initial_up').val()) =='' ) {
                toastr.error("Please upload a initial_signature.");
            } else if($('input[name=action_initial_signature]:checked').val() == 2 && $.trim( $('#input_initial_signature_img').val())  =='' )  {
                toastr.error("Please draw a signature.");
            }
        }

        


        if (!$('form')[0].checkValidity()) {
            $('form').find('input[type="submit"]').click();
            $("form")[0].reportValidity();
            return false;
        } else {
            var password = $("#password").val();
            var cpassword = $("#cpassword").val();
            if(password != cpassword) {
                toastr.error("Password and Confirm password did not match!");
                return false;
            }

            if( $('#images').val() != '') {
                $image_crop.croppie('result', {
                    type: 'canvas',
                    size: 'viewport'
                }).then(function (response) {
                    //add data to display_pic input
                    $('#display_pic').val(response);
                    submitForm();
                }).then(function(){});
            } else {
                submitForm();
            }
        }
  });
  

  function submitForm() {
    var form_data = new FormData($("form")[0]);
        $.ajax({
            type: "POST",
            url: $('#form1').attr('action'),
            dataType: "JSON",
            data:form_data,
            contentType: false, 
            processData: false, 
            success: function(msg){
                toastr.success(msg);
            }
        });

  }


  $('#current_dp').show();
  var uid = <?=$userdata->uid ?>;
  $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>Users/users_details_json",
    dataType: "JSON",
    data:{uid:uid},
    success: function(data){
      $('#croppie_div').hide();
      var dt = new Date();
      $('#form1')[0].reset();
      var uid = data.uid;
      var fname = data.fname;
      var lname = data.lname;
      var mname = data.mname;
      var middle_initial = data.middle_initial;
      var suffix = data.suffix;
      var position = data.position;
      var division = data.division;
      var unit = data.unit;
      var employmentStatus = data.employmentStatus;
      var bday = data.bday;
      var idnum = data.idnum;
      var email = data.email;
      var address = data.address;
      var username = data.username;
      var home_page = data.home_page;
      var access = data.access;
      var privilege = data.privilege;
      var official_station = data.official_station;
      var is_included = data.is_included;
      selected_provCode = data.provCode;
      selected_citymunCode = data.citymunCode;
      selected_brgyCode = data.brgyCode;
      selected_citymun = data.citymun;
      selected_brgy = data.brgy;
      var accessarray = access.split(',');
      var privilege_array = privilege.split(',');
        
      if(jQuery.inArray("5", accessarray)){
        //$("#initial_up").prop("required",true);
      }else{
        //$("#initial_up").prop("required",false);
      }

      $("#icon_label_signature").show(function() {
        if( data.has_signed == 0 ) {
          $("#icon_label_signature").attr('class', 'fa fa-times text-red');
        } else {
          $("#icon_label_signature").attr('class', 'fa fa-check text-green');
        }
      } );



      $("#icon_label_initial_signature").show(function() {
        if( data.has_initial_signed == 0 ) {
          $("#icon_label_initial_signature").attr('class', 'fa fa-times text-red');
        } else {
          $("#icon_label_initial_signature").attr('class', 'fa fa-check text-green');
        }
      });
      
      $("#username").val(username);
      $("#home_page").val(home_page).change();
      $("#access").val(accessarray).change();
      $("#privilege").val(privilege_array).change();

      getDiv(division);
      // if(is_included == 1){
      //   $( "#action_initial_signature]" ).prop( "checked", true );
      //   $( "#is_included" ).prop( "checked", true );
      // }else{
      //   $( "#is_included" ).prop( "checked", false );
      // }
      $("#provCode").val(selected_provCode).change();
      $("#uid").val(uid);
     
      $("#fname").val(fname);
      $("#lname").val(lname);
      $("#mname").val(mname);
      $("#middle_initial").val(middle_initial);
      $("#suffix").val(suffix).change();
      $(".position").val(position).change();
      $(".division").val(division).change();
      
      $(".employmentStatus").val(employmentStatus).change();
      $("#bday").val(bday);
      $("#idnum").val(idnum);
      $("#email").val(email);
      $("#address").val(address);
      $("#citymun").val(selected_citymun);
      $("#brgy").val(selected_brgy);
      $("#official_station").val(official_station).change();
      $("#modal_title_add").text('Update User Information');
      $(".unit").val(unit).change();

      unit_id = unit;
        var dp = '<?php echo base_url(); ?>assets/images/user_photo/user'+uid+'.jpg';
        check(dp)
        .on("error", function(e) {
          $("#current_dp").html('<img src="<?php echo base_url(); ?>assets/dist/img/portrait_placeholder.png" width="300" height="300" class="user-image">');
        })
        .on("load", function(e) {
          $("#current_dp").html('<img src="'+dp+'"  class="user-image" width="300" height="300">');
        })

    }
  });


  

    $( "#datepicker" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });
    $( "#bday" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });

    $("#provCode").change(function(){
      var provCode = $(this).val();
      var province = $('option:selected', this).attr('province');
      $("#province").val(province);
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>General/get_citymun_list",
        dataType: "JSON",
        data:{provCode:provCode},
        success: function(data){
          var options = "<option value='' selected disabled>Select City / Municipality</option>";
          $.each(data, function(i, val) {
            if(selected_citymunCode == val.citymunCode){
              options +=`<option selected value="${val.citymunCode}" citymun="${val.citymunDesc}">${val.citymunDesc}</option>`;
            }else{
              options +=`<option value="${val.citymunCode}" citymun="${val.citymunDesc}">${val.citymunDesc}</option>`;
            }
          })
          $("#citymunCode").html(options);
          $("#citymunCode").val(selected_citymunCode).change();
        }
      })
    })

    $("#citymunCode").change(function(){
      var citymunCode = $("#citymunCode").val();
      var citymun = $('option:selected', this).attr('citymun');
      get_brgy_list(citymunCode,citymun);
    })

    $("#brgyCode").change(function(){
      var brgy = $('option:selected', this).attr('brgy');
      $("#brgy").val(brgy);
    })

    $("#showpassword").click(function(){
      if($('#password').attr('type') == "password"){
         $('#password').prop('type', 'text');
         $('#cpassword').prop('type', 'text');
         $("#showpassword_span").html(`<i class="fa fa-eye-slash"></i>Hide Password`);
         $("#showpassword_span").removeClass("label-danger");
         $("#showpassword_span").addClass("label-primary");
      }else{
         $('#password').prop('type', 'password');
         $('#cpassword').prop('type', 'password');
         $("#showpassword_span").html(`<i class="fa fa-eye"></i>Show Password`);
         $("#showpassword_span").removeClass("label-primary");
         $("#showpassword_span").addClass("label-danger");
      }
    })
});
</script>
