<style>
.fileUpload {
    position: relative;
    overflow: hidden;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        Users
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li><a href="#"> Admin</a></li>
        <li class="active">Users</li>
        </ol>
    </section>

    <section class="content">
        <div class="box box-default">
            <div class="box-body">
                <div class="col-xs-12">
                    <div class="col-xs-8">
                    </div>
                    <div class="col-xs-3">
                        <select class="select2" name="div_id" id="div_id">
                            <option value="" selected disabled>Select Division</option>
                            <option value="">ALL</option>
                            <?php foreach($division as $val){
                                echo "<option value='$val->divunit_id'> $val->divunit_abv - $val->divunit_name</option>";
                            }?>
                        </select>
                    </div>
                    <div class="col-xs-1">
                        <button class="btn btn-primary" id="filter">Filter</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                    <h3 class="box-title">Users List</h3>
                        <div class="box-tools">
                            <button class="btn btn-info btn-sm" id="add_users" >
                                <i  class="fa fa-plus fa-1x"> </i> Add Users
                            </button>
                        </div>
                    </div>
                    
                    <div class="box-body">
                        <div id="refresh">
                            <div class="table-responsive">
                                <table style="width: 100%;" class="table table-striped table-bordered table-hover" id="viewresult_acc">
                                    <thead>
                                        <tr >
                                        <th width="10%">Users ID</th>
                                        <th width="">Full Name</th>
                                        <th width="">Username</th>
                                        <th width="">Division / Unit</th>
                                        <th width="10%">Access</th>
                                        <th style="width:100px;"><center>Action</center></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php  $this->load->view('users/users_modal'); ?>
<?php  $this->load->view('users/users_js'); ?>
