<link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/croppie/croppie.css">
<script src="<?php echo base_url(); ?>assets/js/croppie/croppie.min.js"></script>

<script>
var unit_id = "", selected_provCode="", selected_citymunCode="", selected_brgyCode="", selected_citymun="",selected_brgy="";

function unsecuredCopyToClipboard(text) {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand('copy');
  } catch (err) {
    console.error('Unable to copy to clipboard', err);
  }
  document.body.removeChild(textArea);
}
function getDiv(val) {
  
    var unit_options="";
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>General/unit_list",
      dataType: "JSON",
      data:'divunit_id='+val,
      success: function(data){
        if(data != false){
            unit_options +=`<option value='' selected disabled>Select Unit</option>`;
            $.each(data, function(i, val) {
            unit_options +="<option value='"+val.divunit_id+"' title='"+val.divunit_name+"'>"+val.divunit_abv+"</option>";
            });
        }
        else{
            unit_options +="<option value=''>Please Select Division First</option>";
        }
        $("#unit").html(unit_options);
        if(unit_id != ""){
          $(".unit").val(unit_id).change();     
        }
      }
    });
  }

  function get_brgy_list(citymunCode, citymun){
      $("#citymun").val(citymun);
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>General/get_brgy_list",
        dataType: "JSON",
        data:{citymunCode:citymunCode},
        success: function(data){
          var options = "<option value='' selected disabled>Select Brgy</option>";
          $.each(data, function(i, val) {
            if(selected_brgyCode == val.brgyCode){
              options +=`<option selected value="${val.brgyCode}" brgy="${val.brgyDesc}">${val.brgyDesc}</option>`;
            }else{
              options +=`<option value="${val.brgyCode}" brgy="${val.brgyDesc}">${val.brgyDesc}</option>`;
            }
          })
          $("#brgyCode").html(options);
          $("#brgyCode").val(selected_brgyCode).change();
        }
      })
  }

  function check(src) {
  return $("<img>").attr('src', src);
}
  $('#croppie_div').hide();
   $image_crop = $('#upload-image').croppie({
    enableExif: true,
    viewport: {
        width: 200,
        height: 200,
        type: 'circle',
    },
    boundary: {
        width: 300,
        height: 300
    },
    showZoomer: true,
    enableOrientation: true
});
$('#images').on('change', function () { 
    $('#croppie_div').show();
    $('#current_dp').hide();
    var reader = new FileReader();
    reader.onload = function (e) {
        $image_crop.croppie('bind', {
            url: e.target.result
        }).then(function(){
            console.log('jQuery bind complete');
        });         
    }
    reader.readAsDataURL(this.files[0]);
});
$(document).ready(function() {
  $("#filter").click(function(e){
    table.ajax.reload( null, false );
  }) 
  
  $( "#rotateLeft" ).click(function(e) {
    e.preventDefault();
            $image_crop.croppie('rotate', parseInt($(this).data('rotate')));
        });
       
        $( "#rotateRight" ).click(function() {
            $image_crop.croppie('rotate',parseInt($(this).data('rotate')));
        });

  $( "#form1" ).on( "click", "#submit_add", function(e) {
    e.preventDefault();
    if (!$('form')[0].checkValidity()) {
      $('form').find('input[type="submit"]').click();
      $("form")[0].reportValidity();
      return false;
    }else{
      $image_crop.croppie('result', {
          type: 'canvas',
          size: 'viewport'
        }).then(function (response) {
          //add data to display_pic input
          $('#display_pic').val(response);
        }).then(function(){
          //send form1
          var form_data = new FormData($("form")[0]);
          $.ajax({
            type: "POST",
            url: $('#form1').attr('action'),
            dataType: "JSON",
            data:form_data,
            contentType: false, 
            processData: false, 
            success: function(msg){
              toastr.success(msg);
              table.ajax.reload( null, false );
              $('#modal').modal('hide');
            }
          })
        });
    }
  });
  $("#add_users").click(function() {
      $('#form1')[0].reset();
      $("#modal_title_add").text('Add User');
      $(".position").val('').change();
      $(".division").val('').change();
      $(".unit").val('').change();
      $(".employmentStatus").val('').change();
      $("#suffix").val('').change();
      $("#current_dp").html('');
      $("#home_page").val('').change();
      $("#access").val('').change();
      $("#privilege").val('').change();
      $("#provCode").val('').change();
      document.getElementById('form1').action =  '<?php echo base_url()."users/add_users"; ?>';
      $('#modal').modal('show');
});

  $( "#viewresult" ).on( "click", ".edit_info", function(e) {
    e.preventDefault();
    $('#current_dp').show();
    var uid = this.getAttribute("uid");
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Users/users_details_json",
      dataType: "JSON",
      data:{uid:uid},
      success: function(data){
        $('#croppie_div').hide();
        var dt = new Date();
        $('#form1')[0].reset();
        var uid = data.uid;
        var fname = data.fname;
        var lname = data.lname;
        var mname = data.mname;
        var middle_initial = data.middle_initial;
        var suffix = data.suffix;
        var position = data.position;
        var division = data.division;
        var unit = data.unit;
        var employmentStatus = data.employmentStatus;
        var bday = data.bday;
        var idnum = data.idnum;
        var email = data.email;
        var address = data.address;
        var bank_acc_no = data.bank_acc_no;

        var username = data.username;
        var home_page = data.home_page;
        var access = data.access;
        var privilege = data.privilege;
        var official_station = data.official_station;
        selected_provCode = data.provCode;
        selected_citymunCode = data.citymunCode;
        selected_brgyCode = data.brgyCode;
        selected_citymun = data.citymun;
        selected_brgy = data.brgy;
        var accessarray = access.split(',');
        var privilege_array = privilege.split(',');

        $("#username").val(username);
        $("#home_page").val(home_page).change();
        $("#access").val(accessarray).change();
        $("#privilege").val(privilege_array).change();

        getDiv(division);
        $("#provCode").val(selected_provCode).change();
        $("#uid").val(uid);
        $("#fname").val(fname);
        $("#lname").val(lname);
        $("#mname").val(mname);
        $("#middle_initial").val(middle_initial);
        $("#bank_acc_no").val(bank_acc_no);
        $("#suffix").val(suffix).change();
        $(".position").val(position).change();
        $(".division").val(division).change();
        
        $(".employmentStatus").val(employmentStatus).change();
        $("#bday").val(bday);
        $("#idnum").val(idnum);
        $("#email").val(email);
        $("#address").val(address);
        $("#citymun").val(selected_citymun);
        $("#brgy").val(selected_brgy);
        $("#official_station").val(official_station).change();
        $("#modal_title_add").text('Update User Information');
        $(".unit").val(unit).change();

        unit_id = unit;
          var dp = '<?php echo base_url(); ?>assets/images/user_photo/user'+uid+'.jpg';
          check(dp)
          .on("error", function(e) {
            $("#current_dp").html('<img src="<?php echo base_url(); ?>assets/dist/img/portrait_placeholder.png" width="300" height="300" class="user-image">');
          })
          .on("load", function(e) {
            $("#current_dp").html('<img src="'+dp+'"  class="user-image" width="300" height="300">');
          })
        document.getElementById('form1').action =  '<?php echo base_url()."users/edit_info"; ?>';
        $('#modal').modal('show');
      }
    });
  });

  $( "#viewresult" ).on( "click", ".reset_password", function(e) {
    e.preventDefault();
    $('#current_dp').show();
    var uid = this.getAttribute("uid");
    var uname = this.getAttribute("uname");
    if ( confirm('Are you sure you want to reset the password of ' + uname + ' ?') ) {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Users/reset_password",
        dataType: "JSON",
        data:{uid:uid},
        success: function(data){
          $("#pw_body").html('The new password is <strong id="new_pw">' + data.new_password + '</strong>');
          $("#reset_pw_modal").modal("show");
        }
      });
    } 
  });

  $( "#viewresult" ).on( "click", ".disable_user", function(e) {
    e.preventDefault();
    $('#current_dp').show();
    var uid = this.getAttribute("uid");
    var uname = this.getAttribute("uname");
    if ( confirm('Are you sure you want to DISABLE user ' + uname + ' ?') ) {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Users/disable_user",
        dataType: "JSON",
        data:{uid:uid,is_disable:"1"},
        success: function(data){
          toastr.warning("User has been DISABLED!");
          table.ajax.reload( null, false );
        }
      });
    } 
  });

  $( "#viewresult" ).on( "click", ".enable_user", function(e) {
    e.preventDefault();
    $('#current_dp').show();
    var uid = this.getAttribute("uid");
    var uname = this.getAttribute("uname");
    if ( confirm('Are you sure you want to ENABLE user ' + uname + ' ?') ) {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Users/disable_user",
        dataType: "JSON",
        data:{uid:uid,is_disable:"0"},
        success: function(data){
          toastr.success("User has been ENABLED!");
          table.ajax.reload( null, false );
        }
      });
    } 
  });


  $("#copy_pw").click(function(){
    var new_pw = $("#new_pw").html();
     if (window.isSecureContext && navigator.clipboard) {
        navigator.clipboard.writeText(new_pw);
      } else {
        unsecuredCopyToClipboard(new_pw);
      }
    toastr.success("New Password "+new_pw+" has been Copied to clipboard");
    $("#reset_pw_modal").modal("hide");
  })


  $( "#viewresult_acc" ).on( "click", ".edit_info_acc", function(e) {
    e.preventDefault();
    $('#current_dp').show();
    var uid = this.getAttribute("uid");
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Users_acc/users_details_json",
      dataType: "JSON",
      data:{uid:uid},
      success: function(data){
        $('#croppie_div').hide();
        $('#form1')[0].reset();
        var uid = data.uid;
        var fname = data.fname;
        var lname = data.lname;
        var mname = data.mname;
        var bank_acc_no = data.bank_acc_no;


        $("#uid_acc").val(uid);
        $("#fname_acc").val(fname);
        $("#lname_acc").val(lname);
        $("#mname_acc").val(mname);
        $("#bank_acc_no_acc").val(bank_acc_no);
        $('#acc_modal').modal('show');
      }
    });
  });
    // $('#viewresult').DataTable({
    //   responsive: true,
    //   serverside: true,
    //   "aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
    //   "iDisplayLength": 10
    // });
    table = $('#viewresult').DataTable({ 
      "processing": true, //Feature control the processing indicator.
      "serverSide": true, //Feature control DataTables' server-side processing mode.
      "order": [], //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
      select: true,
      "ajax": {
        "url": "<?php echo site_url('Users/get_users_json')?>",
        "type": "POST",
        "data": function ( data ) {
          data.div_id = $("#div_id").val();
          data.privilege = $("#privilege_filter").val();
        },
        "dataSrc": function(json){
          return json.data;
        }
      },
      //Set column definition initialisation properties.
      "columnDefs": [
        { 
          "targets": [ 0 ], //first column / numbering column
          "orderable": false, //set not orderable
        },
      ],
    createdRow: function( row, data, dataIndex ) {
        // Set the data-status attribute, and add a class
        if(data[6]==1){
          $(row).addClass("label-danger");
        }
    }
    });

    table2 = $('#viewresult_acc').DataTable({ 
      "processing": true, //Feature control the processing indicator.
      "serverSide": true, //Feature control DataTables' server-side processing mode.
      "order": [], //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
      select: true,
      "ajax": {
        "url": "<?php echo site_url('Users_acc/get_users_json')?>",
        "type": "POST",
        "data": function ( data ) {
          data.div_id = $("#div_id").val();
        },
        "dataSrc": function(json){
          return json.data;
        }
      },
      //Set column definition initialisation properties.
      "columnDefs": [
        { 
          "targets": [ 0 ], //first column / numbering column
          "orderable": false, //set not orderable
        },
      ],
    createdRow: function( row, data, dataIndex ) {
        // Set the data-status attribute, and add a class
        // if(data[6]==1){
        //   $(row).addClass("label-warning");
        // }
        // }
    }
    });

    $( "#datepicker" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });
    $( "#bday" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });

    $("#provCode").change(function(){
      var provCode = $(this).val();
      var province = $('option:selected', this).attr('province');
      $("#province").val(province);
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>General/get_citymun_list",
        dataType: "JSON",
        data:{provCode:provCode},
        success: function(data){
          var options = "<option value='' selected disabled>Select City / Municipality</option>";
          $.each(data, function(i, val) {
            if(selected_citymunCode == val.citymunCode){
              options +=`<option selected value="${val.citymunCode}" citymun="${val.citymunDesc}">${val.citymunDesc}</option>`;
            }else{
              options +=`<option value="${val.citymunCode}" citymun="${val.citymunDesc}">${val.citymunDesc}</option>`;
            }
          })
          $("#citymunCode").html(options);
          $("#citymunCode").val(selected_citymunCode).change();
        }
      })
    })

    $("#citymunCode").change(function(){
      var citymunCode = $("#citymunCode").val();
      var citymun = $('option:selected', this).attr('citymun');
      get_brgy_list(citymunCode,citymun);
    })

    $("#brgyCode").change(function(){
      var brgy = $('option:selected', this).attr('brgy');
      $("#brgy").val(brgy);
    })
});
</script>
