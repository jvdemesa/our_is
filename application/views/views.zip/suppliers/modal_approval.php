
<!---- Disapprove MODAL-->
<div class="modal fade" id="disapprove_modal" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header alert alert-danger">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 id="status_title">
          <i class="fa fa-user-edit"></i> Disapprove Supplier
        </h4>
      </div>
      <form id="form1" method="POST" action="<?= base_url(); ?>Suppliers/disapprove">
      <input type="hidden" name="userid" value="<?= $detail->userid ?>">
      <div class="modal-body">
        <div class="form-group">
          <div class="bottom-border">
            <label>Remarks / Reason for disapproval:</label>  
            <textarea class="form-control" id="remarks" name="remarks" required="required"></textarea>  
          </div>
        </div>

          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                  <i class="fa fa-times fa-lg"></i> Close
                </button>

                <button type="submit" class="btn btn-danger" id="disapprove_btn">
                  <i class="fa fa-thumbs-down"></i> Disapprove
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- UPDATE PROFILE MODAL-->
<div class="modal fade" id="approval_modal" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header alert alert-success">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 id="status_title">
          <i class="fa fa-user-edit"></i> Approve Supplier
        </h4>
      </div>
      <form id="form1" method="POST" action="<?= base_url(); ?>Suppliers/approve">
      <input type="hidden" name="userid" value="<?= $detail->userid ?>">
      <div class="modal-body">
        <div class="form-group">
          <div class="bottom-border">
            <label>Remarks:</label>  
            <textarea class="form-control" id="remarks" name="remarks"></textarea>  
          </div>
        </div>

          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                  <i class="fa fa-times fa-lg"></i> Close
                </button>

                <button type="submit" class="btn btn-success" id="approve_btn">
                  <i class="fa fa-thumbs-up"></i> Approve
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
  $('#disapprove').click(function(){
    $('#disapprove_modal').modal('show');
  })
  $('#approve').click(function(){
    $('#approval_modal').modal('show');
  })
});

</script>
