<style>
  .bottom-border{
    padding-bottom: 10px !important;
  }
  .fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
.pdfobject-container, #display_pdf { 
  height: 550px; 
  border: 
  1rem solid rgba(0,0,0,.1); 
}
.modalBtn{
  visibility: none;
}
</style>
<!---- UPDATE PROFILE MODAL-->
<div class="modal fade" id="update_modal" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header alert alert-info">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 id="status_title">
          <i class="fa fa-user-edit"></i> Update Profile
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form1" method="POST" action="<?= base_url(); ?>Suppliers/update_profile" enctype="multipart/form-data">
        <input type="hidden" name="userid" value="<?= $detail->userid ?>">
        <input type="hidden" name="philgeps_file_old" id="philgeps_file_old" value="<?= $detail->philgeps_file ?>">
        <input type="hidden" name="form2303_file_old" id="form2303_file_old" value="<?= $detail->form2303_file ?>">
        <input type="hidden" name="m_file_old" id="m_file_old" value="<?= $detail->m_file ?>">
        <input type="hidden" name="dti_file_old" id="dti_file_old" value="<?= $detail->dti_file ?>">
        <input type="hidden" name="tc_file_old" id="tc_file_old" value="<?= $detail->tc_file ?>">
        <div class="modal-body">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" id="tab1" aria-expanded="true"><i class="fa fa-info-circle"></i>Basic Info</a></li>
              <li class=""><a href="#tab_2" id="tab2" aria-expanded="false"><i class="fa fa-id-badge"></i>Organization Details</a></li>
              <li class=""><a href="#tab_3" id="tab3" aria-expanded="false"><i class="fa fa-certificate"></i>Mayors Permit</a></li>
              <li class=""><a href="#tab_4" id="tab4" aria-expanded="false"><i class="fa fa-building"></i>DTI</a></li>
              <li class=""><a href="#tab_5" id="tab5" aria-expanded="false"><i class="fa fa-money"></i>Tax</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">

                <div class="form-group">
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">First Name:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                      <input type="text" id="fname" class="form-control" name="fname" value="<?= $detail->fname ?>" required="required">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Middle Name</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                      <input type="text" id="mname" class="form-control" name="mname" value="<?= $detail->mname ?>">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Last Name</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                      <input type="text" id="lname" class="form-control" name="lname" value="<?= $detail->lname ?>" required="required">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Designation:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-id-card"></i></span>
                      <input type="text" id="designation" class="form-control" name="designation" value="<?= $detail->designation ?>" required="required">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Email Address:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                      <input type="text" id="email" class="form-control" name="email" value="<?= $detail->email ?>" required="required">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mobile Number:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-mobile"></i></span>
                      <input type="text" id="mobile_number" class="form-control" name="mobile_number" value="<?= $detail->mobile_number ?>" required="required">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Area Code:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                      <input type="text" id="areacode" class="form-control" name="areacode" value="<?= $detail->areacode ?>">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Landline:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                      <input type="text" id="landline" class="form-control" name="landline" value="<?= $detail->landline ?>">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Philgeps Number:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                      <input type="text" id="philgeps_no" class="form-control" name="philgeps_no" value="<?= $detail->philgeps_no ?>" required="required">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Philgeps Certificate:</label>    
                    <div class="input-group col-sm-9">
                      <div class="form-group">
                        <div class="input-group">
                          <input type="text" class="form-control" readonly>
                          <div class="input-group-btn">
                            <span class="fileUpload btn btn-success">
                                <span class="upl" id="upload">Upload PDF file</span>
                                <input type="file" class="upload up" id="philgeps_file" name="philgeps_file" accept="application/pdf" required="required" />
                              </span><!-- btn-orange -->
                           </div><!-- btn -->
                         </div><!-- group -->
                       </div><!-- form-group -->
                   </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Form 2303:</label>    
                    <div class="input-group col-sm-9">
                      <div class="form-group">
                        <div class="input-group">
                          <input type="text" class="form-control" readonly>
                          <div class="input-group-btn">
                            <span class="fileUpload btn btn-success">
                                <span class="upl" id="upload">Upload PDF file</span>
                                <input type="file" class="upload up" id="form2303_file" name="form2303_file" accept="application/pdf" required="required" />
                              </span><!-- btn-orange -->
                           </div><!-- btn -->
                         </div><!-- group -->
                       </div><!-- form-group -->
                   </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Curriculum Vitae:</label>    
                    <div class="input-group col-sm-9">
                      <div class="form-group">
                        <div class="input-group">
                          <input type="text" class="form-control" readonly>
                          <div class="input-group-btn">
                            <span class="fileUpload btn btn-success">
                                <span class="upl" id="upload">Upload PDF file</span>
                                <input type="file" class="upload up" id="cv_file" name="cv_file" accept="application/pdf" />
                              </span><!-- btn-orange -->
                           </div><!-- btn -->
                         </div><!-- group -->
                       </div><!-- form-group -->
                   </div>
                  </div>

                </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                <div class="form-group">

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Location:</label>    
                    <div class="input-group col-sm-9">
                      <select class="select2 form-control" name="location" id="location" required="required">
                        <option value="" selected disabled=""> Select Location </option>
                        <option <?php echo ($detail->location == 'Local')?'selected':''; ?> value="Local"> Local </option>
                        <option <?php echo ($detail->fname == 'Foreign')?'selected':''; ?>  value="Foreign"> Foreign </option>
                      </select>
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Form of Organization:</label>   
                    <div class="input-group col-sm-9">
                      <select class="select2 form-control" name="foo" id="foo" required="required">
                        <option value="" <?php echo ($detail->location == '')?'selected':''; ?> disabled=""> Select Form of Organization </option>
                        <option <?php echo ($detail->location == 'Single Proprietorship')?'selected':''; ?> value="Single Proprietorship"> Single Proprietorship </option>
                        <option <?php echo ($detail->location == 'Partnership')?'selected':''; ?> value="Partnership"> Partnership </option>
                        <option <?php echo ($detail->location == 'Corporation')?'selected':''; ?> value="Corporation"> Corporation </option>
                        <option <?php echo ($detail->location == 'Cooperative')?'selected':''; ?> value="Cooperative"> Cooperative </option>
                        <option <?php echo ($detail->location == 'Individual Local Consultant')?'selected':''; ?> value="Individual Local Consultant"> Individual Local Consultant </option>
                      </select>
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Organization Name:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-list-alt"></i></span>
                      <input type="text" name="org_name" id="org_name" class="form-control" value="<?= $detail->org_name ?>">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Business TIN:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-id-card"></i></span>
                      <input type="text" name="btin" id="btin" class="form-control" required="required"  value="<?= $detail->btin ?>">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Form of Organization:</label>   
                    <div class="input-group col-sm-9">
                      <select class="select2 form-control" name="lob_id" id="lob_id" required="required">
                        <option value="" selected disabled=""> Select Line Of Business </option>
                        <?php foreach($lob as $val){ ?>
                          <option value="<?= $val->lob_id ?>" <?php if($detail->lob_id == $val->lob_id){echo 'selected';} ?>><?= $val->lob ?></option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>

                </div>
              </div>

              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
                <div class="form-group">

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mayors Permit Expiration Date:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                      <input type="text" name="m_exp_date" id="m_exp_date" class="form-control datepicker" required="required" value="<?= $detail->m_exp_date ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mayors Permit Issuance Date:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                      <input type="text" name="m_issue_date" id="m_issue_date" class="form-control datepicker" required="required"  value="<?= $detail->m_issue_date ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mayors Permit Place of Issue:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-building"></i></span>
                      <input type="text" name="m_place" id="m_place" class="form-control" required="required"  value="<?= $detail->m_place ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mayors Permit Number:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                      <input type="text" name="m_permit_no" id="m_permit_no" class="form-control" required="required"  value="<?= $detail->m_permit_no ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mayors Permit Issued By:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                      <input type="text" name="m_signatory" id="m_signatory" class="form-control" required="required"  value="<?= $detail->m_signatory ?>">
                    </div>
                  </div>

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Mayors Permit Upload File:</label>    
                    <div class="input-group col-sm-9">
                      <div class="form-group">
                        <div class="input-group">
                          <input type="text" class="form-control" readonly>
                          <div class="input-group-btn">
                            <span class="fileUpload btn btn-success">
                                <span class="upl" id="upload">Upload PDF file</span>
                                <input type="file" class="upload up" id="m_file" name="m_file" accept="application/pdf" required="required" />
                              </span><!-- btn-orange -->
                           </div><!-- btn -->
                         </div><!-- group -->
                       </div><!-- form-group -->
                   </div>
                  </div>

                </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_4">
                <div class="form-group">

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">DTI Expiration Date:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                      <input type="text" name="dti_exp_date" id="dti_exp_date" class="form-control datepicker" required="required" value="<?= $detail->dti_exp_date ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">DTI Registration Date:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                      <input type="text" name="dti_issue_date" id="dti_issue_date" class="form-control datepicker" required="required"  value="<?= $detail->dti_issue_date ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">DTI Certificate Number:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                      <input type="number" name="dti_permit_no" id="dti_permit_no" class="form-control" required="required" value="<?= $detail->dti_permit_no ?>" pattern="\d*" >
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">DTI Issued By / Signatory:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                      <input type="text" name="dti_signatory" id="dti_signatory" class="form-control" required="required" value="<?= $detail->dti_signatory ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">DTI Upload File:</label>    
                    <div class="input-group col-sm-9">
                      <div class="form-group">
                        <div class="input-group">
                          <input type="text" class="form-control" readonly>
                          <div class="input-group-btn">
                            <span class="fileUpload btn btn-success">
                                <span class="upl" id="upload">Upload PDF file</span>
                                <input type="file" class="upload up" id="dti_file" name="dti_file" accept="application/pdf" required="required" />
                              </span><!-- btn-orange -->
                           </div><!-- btn -->
                         </div><!-- group -->
                       </div><!-- form-group -->
                   </div>
                  </div>

                </div>
              </div>
              <!-- /.tab-pane -->
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_5">
                <div class="form-group">

                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Tax Clearance Expiration Date:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                      <input type="text" name="tc_exp_date" id="tc_exp_date" class="form-control datepicker" required="required"  value="<?= $detail->tc_exp_date ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Tax Clearance Registration Date:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                      <input type="text" name="tc_issue_date" id="tc_issue_date" class="form-control datepicker" required="required"  value="<?= $detail->tc_issue_date ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Tax Certificate Number:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                      <input type="text" name="tc_permit_no" id="tc_permit_no" class="form-control" required="required"  value="<?= $detail->tc_permit_no ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Issued By / Signatory:</label>    
                    <div class="input-group col-sm-9">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                      <input type="text" name="tc_signatory" id="tc_signatory" class="form-control" required="required" value="<?= $detail->tc_signatory ?>">
                    </div>
                  </div>
                  <div class="bottom-border">
                    <label for="inputEmail3" class="col-sm-3 control-label">Tax Clearance Upload File:</label>    
                    <div class="input-group col-sm-9">
                      <div class="form-group">
                        <div class="input-group">
                          <input type="text" class="form-control" readonly>
                          <div class="input-group-btn">
                            <span class="fileUpload btn btn-success">
                                <span class="upl" id="upload">Upload PDF file</span>
                                <input type="file" class="upload up" id="tc_file" name="tc_file" accept="application/pdf" required="required" />
                              </span><!-- btn-orange -->
                           </div><!-- btn -->
                         </div><!-- group -->
                       </div><!-- form-group -->
                   </div>
                  </div>

                </div>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>

          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                  <i class="fa fa-times fa-lg"></i> Close
                </button>

                <button type="button" class="btn btn-info modalBtn" id="backBtn">
                  <i class="fa fa-backward"></i> Back
                </button>

                <button type="button" class="btn btn-info modalBtn" id="modalBtn">
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<!---MODAL END -->

<div class="modal fade" id="list_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header alert alert-success">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">
          <p id="list_title"></p>
        </h4>
      </div>               
<!-- Modal Body For Update -->
      <div class="modal-body"> 
        <div id="reg_details">
          <div class="form-row">
            <div class="col-sm-12 col-xs-12">
              <div class="info-box main-box table-responsive">
                <table class="table table-responsive table-bordered table-striped" id="list_table" width="100%">
                  <thead>
                    <tr>
                      <td>Reference Number</td>
                      <td>Notice Title</td>
                      <td style="width: 100px !important">Action</td>
                    </tr>
                  </thead>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!--SUBMIT BUTTON -->
          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                  <i class="fa fa-times fa-lg"></i>&nbsp; Close
                </button>
              </div>
            </div>
          </div>
      </div><!--end Modal body-->
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->

<div class="modal fade" id="message_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header alert alert-success">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">
          Notes on the Bidding Forms
        </h4>
      </div>               
<!-- Modal Body For Update -->
      <div class="modal-body"> 
        <ul class="list-group list-group-unbordered">
            <li class="list-group-item">
              <p>
                The Bidder shall complete and submit with its Bid the Bid Form and Price Schedules in accordance with ITB Clause 15 with the requirements of the Bidding Documents and the format set out in this Section.
              </p>
            </li>
            <li class="list-group-item">
              <p>
                When requested in the BDS, the Bidder should provide the Bid Security, either in the form included hereafter or in another form acceptable to the Entity, pursuant to ITB Clause 18.1.
              </p>
            </li>
            <li class="list-group-item">
              <p>
                The Contract Agreement Form, when it is finalized at the time of contract award, should incorporate any corrections or modifications to the accepted Bid resulting from price corrections.  The Price Schedule and Schedule of Requirements deemed to form part of the contract should be modified accordingly.
              </p>
            </li>
            <li class="list-group-item">
              <p>
                The Performance Security Form and Bank Guarantee Form for Advance Payment should not be completed by the Bidders at the time of their Bid preparation.  Only the successful Bidder will be required to provide performance security and bank guarantee for advance payment in accordance with one of the forms indicated herein or in another form acceptable to the Procuring Entity and pursuant to GCC Clause 13 and its corresponding SCC provision.
              </p>
            </li>
            <li class="list-group-item">
              <p>
                The sworn affidavit must be completed by all Bidders in accordance with ITB Clause 4.2. Failure to do so and submit it with the bid shall result in the rejection of the bid and the Bidder’s disqualification.
              </p>
            </li>
        </ul>
        <!--SUBMIT BUTTON -->
          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                  <i class="fa fa-times fa-lg"></i>&nbsp; Close
                </button>
              </div>
            </div>
          </div>
      </div><!--end Modal body-->
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->
<script type="text/javascript">
$(document).ready(function() {
<?php if($detail->account_status == 3){ ?>
$('#message_modal').modal('show');
<?php } ?>
$("#dti_permit_no").keypress(function() {
  if($(this).val().length > 6) {
      return false
  }
});
var table =  $('#list_table').DataTable({
    responsive: true,
    "aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
    "iDisplayLength": 10,
     "ordering": false,
     'sorting': false,
      "aaSorting": []
    });

  $(document).on('click', '.view_list', function (e) {
    var status = this.getAttribute('status');
    if(status == 0){
      $('#list_title').html('Pending List');
    }else if(status == 1){
      $('#list_title').html('Win List');
    }else{
      $('#list_title').html('Failed List');
    }
      $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Suppliers/get_list",
      dataType: "JSON",
      data:{status:status },
      success: function(data){ 
      table.clear().draw();
      $.each(data, function(key, val){
          var rowNode = table.row.add([
                        val.ref_num, 
                        val.notice_title,
                        `<a class="view_opp" href="<?= base_url(); ?>/Opportunities/view/${val.o_id}" title="View Opportunity"
                          >
                          <i class="fa fa-eye"></i> 
                        </a>`
                        ]).draw().node();
            })
          }
        });
    $('#list_modal').modal('show');
  });

  $('#updateBtn').click(function(){
    $('#modalBtn').html('Next <i class="fa fa-forward"></i>');
    $('#modalBtn').addClass('next1');
    $('#backBtn').hide();
    $('#update_modal').modal('show');
  })
  //next1
  $('#update_modal').on('click','.next1',function(){
    var fname = $('#fname').val();
    var lname = $('#lname').val();
    var designation = $('#designation').val();
    var email = $('#email').val();
    var mobile_number = $('#mobile_number').val();
    var philgeps_no = $('#philgeps_no').val();
    var philgeps_file = $('#philgeps_file_old').val()!=''?$('#philgeps_file_old').val():$('#philgeps_file').val();
    var form2303_file = $('#form2303_file_old').val()!=''?$('#form2303_file_old').val():$('#form2303_file').val();
    if(fname!='' && lname!='' && designation!='' && email!='' && mobile_number!='' && philgeps_no!='' && philgeps_file!='' && form2303_file!=''){
      $('#backBtn').show().addClass('back1');
      $('#modalBtn').removeClass('next1').addClass('next2');
      $('[href="#tab_2"]').tab('show');
    }else{
        $("#form2303_file")[0].reportValidity();
        $("#philgeps_file")[0].reportValidity();
        $("#philgeps_no")[0].reportValidity();
        $("#mobile_number")[0].reportValidity();
        $("#email")[0].reportValidity();
        $("#designation")[0].reportValidity();
        $("#lname")[0].reportValidity();
        $("#fname")[0].reportValidity();
    }
  })
  //next2
  $('#update_modal').on('click','.next2',function(){
    var location = $('#location').val();
    var foo = $('#foo').val();
    var btin = $('#btin').val();
    var lob_id = $('#lob_id').val();
    if(location!=null && foo!=null && btin!=''&& lob_id!=null){
      $('#backBtn').removeClass('back1').addClass('back2');
      $('#modalBtn').removeClass('next2').addClass('next3');
      $('[href="#tab_3"]').tab('show');
    }else{
      $("#btin")[0].reportValidity();
      $("#foo")[0].reportValidity();
      $("#lob_id")[0].reportValidity();
      $("#location")[0].reportValidity();
    }
  })
  //next3
  $('#update_modal').on('click','.next3',function(){
    var m_exp_date = $('#m_exp_date').val();
    var m_issue_date = $('#m_issue_date').val();
    var m_place = $('#m_place').val();
    var m_permit_no = $('#m_permit_no').val();
    var m_signatory = $('#m_signatory').val();
    var m_file = $('#m_file_old').val()!=''?$('#m_file_old').val():$('#m_file').val();
    if(m_exp_date!='' && m_issue_date!='' && m_place!='' && m_permit_no!='' && m_signatory!='' && m_file!=''){
      $('#backBtn').removeClass('back2').addClass('back3');
      $('#modalBtn').removeClass('next3').addClass('next4');
      $('#modalBtn').html('Next <i class="fa fa-forward"></i>');
      $('[href="#tab_4"]').tab('show');
    }else{
      $("#m_file")[0].reportValidity();
      $("#m_signatory")[0].reportValidity();
      $("#m_permit_no")[0].reportValidity();
      $("#m_place")[0].reportValidity();
      $("#m_issue_date")[0].reportValidity();
      $("#m_exp_date")[0].reportValidity();
    }
  })
  //next4
  $('#update_modal').on('click','.next4',function(){
    var dti_exp_date = $('#dti_exp_date').val();
    var dti_issue_date = $('#dti_issue_date').val();
    var dti_permit_no = $('#dti_permit_no').val();
    var dti_signatory = $('#dti_signatory').val();
    var dti_file = $('#dti_file_old').val()!=''?$('#dti_file_old').val():$('#dti_file').val();
    if(dti_exp_date!='' && dti_issue_date!='' && dti_permit_no!='' && dti_signatory!='' && dti_file!=''){
      $('#backBtn').removeClass('back3').addClass('back4');
      $('#modalBtn').removeClass('next4').addClass('confirmUpdateBtn');
      $('#modalBtn').html('<i class="fa fa-save"></i> Save');
      $('[href="#tab_5"]').tab('show');
    }else{
      $("#dti_file")[0].reportValidity();
      $("#dti_signatory")[0].reportValidity();
      $("#dti_permit_no")[0].reportValidity();
      $("#dti_issue_date")[0].reportValidity();
      $("#dti_exp_date")[0].reportValidity();
    }
  })

  //back1
  $('#update_modal').on('click','.back1',function(){
    $('#backBtn').hide().removeClass('back1');
    $('#modalBtn').removeClass('next2').addClass('next1');
     $('[href="#tab_1"]').tab('show');
  })
  //back2
  $('#update_modal').on('click','.back2',function(){
    $('#backBtn').removeClass('back2').addClass('back1');
    $('#modalBtn').removeClass('next3').addClass('next2');
     $('[href="#tab_2"]').tab('show');
  })
  //back3
  $('#update_modal').on('click','.back3',function(){
    $('#backBtn').removeClass('back3').addClass('back2');
    $('#modalBtn').removeClass('next4').addClass('next3');
     $('[href="#tab_3"]').tab('show');
  })
  //back4
  $('#update_modal').on('click','.back4',function(){
    $('#backBtn').removeClass('back4').addClass('back3');
    $('#modalBtn').removeClass('confirmUpdateBtn').addClass('next4');
    $('#modalBtn').html('Next <i class="fa fa-forward"></i>');
     $('[href="#tab_4"]').tab('show');
  })

  $('#update_modal').on('click','.confirmUpdateBtn',function(){
    var tc_exp_date = $('#tc_exp_date').val();
    var tc_issue_date = $('#tc_issue_date').val();
    var tc_permit_no = $('#tc_permit_no').val();
    var tc_signatory = $('#tc_signatory').val();
    var tc_file = $('#tc_file_old').val()!=''?$('#tc_file_old').val():$('#tc_file').val();
    if(tc_exp_date!='' && tc_issue_date!='' && tc_permit_no!='' && tc_signatory!='' && tc_file!=''){
      $('#form1').submit();
    }else{
      $("#tc_file")[0].reportValidity();
      $("#tc_signatory")[0].reportValidity();
      $("#tc_permit_no")[0].reportValidity();
      $("#tc_issue_date")[0].reportValidity();
      $("#tc_exp_date")[0].reportValidity();
    }        
  });

  $("#confirmUpdate_btn").click(function (e) {
    e.preventDefault();
    $("#form1").submit();
  });

  $("#proposalList_tbl").on('click', '.award_btn', function (e) {
    var id = this.getAttribute("proposal_id"); 
    var fullname = this.getAttribute("fullname"); 
    var org_name = this.getAttribute("org_name"); 
    $('#proposal_id').val(id);
    $('#fullname').val(fullname);
    $('#org_name').val(org_name);
    $('#award_modal').modal('show');
  })
});

$(document).on('change','.up', function(event){
  myfile= $( this ).val();
  var ext = myfile.split('.').pop();
  if(ext=="pdf"){
    var names = [];
    var length = $(this).get(0).files.length;
    var file = event.target.files[0];
    if(file.size<=5*1024*1024) {
      for (var i = 0; i < $(this).get(0).files.length; ++i) {
        names.push($(this).get(0).files[i].name);
      }
        // $("input[name=file]").val(names);
      if(length>2){
        var fileName = names.join(', ');
        $(this).closest('.form-group').find('.form-control').attr("value",length+" files selected");
      }
      else{
        $(this).closest('.form-group').find('.form-control').attr("value",names);
      }
    }else{
      $( this ).val('');
      $(this).closest('.form-group').find('.form-control').attr("value",'');
      alert('Max file size is 5mb!')
    }
  }else{
    $(this).closest('.form-group').find('.form-control').attr("value",'');
    $( this ).val('');
    alert(ext + ' Not Allowed!')
  }
});

</script>
