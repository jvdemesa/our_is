<div class="content-wrapper" style="min-height: 1135.8px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Supplier Profile
      </h1>
      <ol class="breadcrumb">
        <li class="active">Suppliers profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
<!--               <img class="profile-user-img img-responsive img-circle" src="../../dist/img/user4-128x128.jpg" alt="User profile picture">
 -->
              <h3 class="profile-username text-center"><?= $detail->fname.' '.$detail->lname ?></h3>

              <p class="text-muted text-center"><?= $detail->designation ?></p>
              <p class="text-muted text-left">Mobile Number: <u style="color: black;"><?= $detail->mobile_number ?></u></p>
              <p class="text-muted text-left">Landline: <u style="color: black;"><?= "(".$detail->areacode.") ".$detail->landline ?></u></p>
              <p class="text-muted text-left">Email: <u style="color: black;"><?= $detail->email ?></u></p>
              <p class="text-muted text-left">PhilGEPS Number: <u style="color: black;"><?= $detail->philgeps_no ?></u></p>
              <p class="text-muted text-left">Philgeps Certificate: 
                <?php if($detail->philgeps_file!=''){ ?>
                <u style="color: black;">
                  <a href='<?= base_url().$detail->philgeps_file; ?>' target='_blank'> View</a>
                </u>
                <?php } ?>
              </p>
              <p class="text-muted text-left">Form 2303: 
                <?php if($detail->form2303_file!=''){ ?>
                <u style="color: black;">
                  <a href='<?= base_url().$detail->form2303_file; ?>' target='_blank'> View</a>
                </u>
                <?php } ?>
              </p>
              <p class="text-muted text-left">Curriculum Vitae: 
                <?php if($detail->cv_file!=''){ ?>
                <u style="color: black;">
                  <a href='<?= base_url().$detail->cv_file; ?>' target='_blank'> View</a>
                </u>
                <?php } ?>
              </p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Pending Bids</b> <a class="pull-right"><?= $pending_bids ?></a>
                </li>
                <li class="list-group-item">
                  <b>Win Bids</b> <a class="pull-right"><?= $win_bids ?></a>
                </li>
                <li class="list-group-item">
                  <b>Failed Bids</b> <a class="pull-right"><?= $failed_bids ?></a>
                </li>
              <?php if($detail->account_status == 1){ ?>
                	<h4>Account Status: <span class="badge bg-light-blue">Basic / Unverified</span></h4>
                </ul>
            	<?php }elseif($detail->account_status == 2){ ?>
                	<h4>Account Status: <span class="badge bg-yellow">Pending Verification</span></h4>
                </ul>
                <div class="col-md-12">
                  <button class="btn btn-danger col-md-6" id="disapprove"><i class="fa fa-thumbs-down"></i> Disapprove</button>
                  <button class="btn btn-success col-md-6" id="approve"><i class="fa fa-thumbs-up"></i>  Approve</button>
                </div>
            	<?php }elseif($detail->account_status == 3){ ?>
                	<h4>Account Status: <span class="badge bg-green">Verified</span></h4>
                </ul>
            	<?php }?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Organization Details</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
              <p class="text-muted"><?= $detail->location ?></p>
              <hr>

              <strong><i class="fa fa-users margin-r-5"></i> Form of organization</strong>
              <p class="text-muted"><?= $detail->foo ?></p>
              <hr>

              <strong><i class="fa fa-list-alt margin-r-5"></i> Organization Name</strong>
              <p class="text-muted"><?= $detail->org_name ?></p>
              <hr>

              <strong><i class="fa fa-id-card margin-r-5"></i> Business Tax Identification Number</strong>
                <p><span class="label label-success"><?= $detail->btin ?></span></p>
              <hr>

              <strong><i class="fa fa-list-alt margin-r-5"></i> Line of Business</strong>
              <p class="text-muted"><?= $detail->lob ?></p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="content">
            	<div class="content-header">
            		<h4>Permits, Clearances & Forms</h4>
            	</div>
            	<hr>
                <!-- Post -->
                <div class="box">
                  <div class="box-header with-border">
                  	<h5><i class="fa fa-certificate"></i> Mayors Permit</h5>
                  </div>
                  <div class="box-body">
	                  <div class="col-md-12">
	                  	<div class="col-md-2"><label>Expiration Date:</label><br><?= $detail->m_exp_date ?></div>
	                  	<div class="col-md-2"><label>Place of Issue<br><?= $detail->m_place ?></label></div>
	                  	<div class="col-md-2"><label>Issuance Date</label><br><?= $detail->m_issue_date ?></div>
	                  	<div class="col-md-2"><label>Permit Number</label><br><?= $detail->m_permit_no ?></div>
	                  	<div class="col-md-2"><label>Issued By</label><br><?= $detail->m_signatory ?></div>
	                  	<div class="col-md-2"><label>
	                  		Uploaded File</label><br>
	                  		<a href='<?= base_url().$detail->m_file; ?>' target='_blank'> View</a>
	                  		</div>
	                  </div>
	              </div>
              	</div>
                <div class="box">
                  <div class="box-header with-border">
                  	<h5><i class="fa fa-certificate"></i> DTI Permit</h5>
                  </div>
                  <div class="box-body">
	                  <div class="col-md-12">
	                  	<div class="col-md-2"><label>Registration Date:</label><br><?= $detail->dti_issue_date ?></div>
	                  	<div class="col-md-2"><label>Expiration Date</label><br><?= $detail->dti_exp_date ?></div>
	                  	<div class="col-md-2"><label>Certificate Number</label><br><?= $detail->dti_permit_no ?></div>
	                  	<div class="col-md-4"><label>Issued By / Signatory</label><br><?= $detail->dti_signatory ?></div>
	                  	<div class="col-md-2"><label>
	                  		Uploaded File</label><br>
	                  		<a href='<?= base_url().$detail->dti_file; ?>' target='_blank'> View</a>
	                  		</div>
	                  </div>
	                  </div>
	              </div>
              	</div>
                <div class="box">
                  <div class="box-header with-border">
                  	<h5><i class="fa fa-certificate"></i> Tax Clearance</h5>
                  </div>
                  <div class="box-body">
	                  <div class="col-md-12">
	                  	<div class="col-md-2"><label>Expiration Date:</label><br><?= $detail->tc_exp_date ?></div>
	                  	<div class="col-md-2"><label>Issuance Date</label><br><?= $detail->tc_issue_date ?></div>
	                  	<div class="col-md-2"><label>TCC Number</label><br><?= $detail->tc_permit_no ?></div>
	                  	<div class="col-md-4"><label>Issued By / Signatory</label><br><?= $detail->tc_signatory ?></div>
	                  	<div class="col-md-2"><label>
	                  		Uploaded File</label><br>
	                  		<a href='<?= base_url().$detail->tc_file; ?>' target='_blank'> View</a>
                  		</div>
	                  </div>
	                  </div>
	              </div>
              	</div>
                <!-- /.post -->
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
<?php  $this->load->view('suppliers/modal_approval'); ?>
<script type="text/javascript">
$(document).ready(function() {
});
</script>
