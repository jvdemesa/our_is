<style>
  .badge-info{
    background-color: #17a2b8;
  }
  .badge-primary{
    background-color: #007bff;
  }
  .badge-success{
    background-color: #28a745;
  }
</style>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        Suppliers
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li><a href="#"> Admin</a></li>
        <li class="active">Suppliers</li>
        </ol>
    </section>
      <section class="content">
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="panel-body">
                  <form  id="form-filter" class="form-horizontal">
                    <div class="col-md-2"> 
                    </div>
                    <div class="col-md-2"> 
                    </div>
                    <div class="col-md-2">  
                    </div> 
                    <div class="col-md-2">  
                    </div> 
                    <div class="col-md-2"> 
                      <label>Account Status</label>
                      <select name='status' id='status' class="form-control select2 filter">
                        <option value="">ALL</option>
                        <option value="1">Unverified</option>
                        <option value="2">Pending Verification</option>
                        <option value="3">Verified</option>
                      </select>  
                    </div> 
                    <div class="col-md-2"> 
                      <label>Line of Business</label>
                        <select name='lob_id' id='lob_id' class="form-control select2 filter">
                          <option value="">ALL</option>
                          <?php foreach($lob as $val){ ?>
                          <option value="<?= $val->lob_id ?>"><?= $val->lob ?></option>
                          <?php } ?>
                        </select>  
                      </div> 
                  </form>   
                </div> 
              </div>
              <!--START TABLE-->
            </div>
          </div>
          <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                    <h3 class="box-title">Suppliers List</h3>
                        <div class="box-tools">
                        </div>
                    </div>
                <div class="box-body table-responsive">
                <hr />
                   <table class="table table-striped table-bordered table-hover" id="viewresult">
                        <thead>
                            <tr >
                              <th width="10%">Suppliers ID</th>
                              <th width="20%">Full Name</th>
                              <th width="20%">Organization Name</th>
                              <th width="15%">Email Address</th>
                              <th width="15%">Line of Business</th>
                              <th width="10%">Account Status</th>
                              <th style="width:100px;">action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script>
$(document).ready(function() {  
  $("#viewresult").on('click','.view_profile', function() {
    var userid = this.getAttribute('userid');
    window.location.href = "<?= base_url(); ?>"+'Suppliers/view_profile/'+userid;
  });
    //datatables
    table = $('#viewresult').DataTable({ 
      "processing": true, //Feature control the processing indicator.
      "serverSide": true, //Feature control DataTables' server-side processing mode.
      "order": [], //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
          buttons:[
              {
                extend: 'excelHtml5',
                title: 'LSPU Suppliers Portal Suppliers List',
                exportOptions: {
                    columns: 'th:not(:last-child)'
                 }
              },
              {
                extend: 'print',
                title: 'LSPU Suppliers Portal Suppliers List',
                exportOptions: {
                    columns: 'th:not(:last-child)'
                 }
              },
            ],
      select: true,
      "ajax": {
        "url": "<?php echo site_url('Suppliers/ajax_list')?>",
        "type": "POST",
        "data": function ( data ) {
          data.status = $('#status').val();
          data.lob_id = $('#lob_id').val();
        },
        "dataSrc": function(json){
          return json.data;
        }
      },
      //Set column definition initialisation properties.
      "columnDefs": [
        { 
          "targets": [ 0 ], //first column / numbering column
          "orderable": false, //set not orderable
        },
      ],
    createdRow: function( row, data, dataIndex ) {
    }
    });

    $('.filter').change(function(){
            table.ajax.reload();  //just reload table 
    })
});

</script>
