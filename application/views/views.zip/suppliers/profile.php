<div class="content-wrapper" style="min-height: 1135.8px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Supplier Profile
      </h1>
      <ol class="breadcrumb">
        <li class="active">Suppliers profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <h3 class="profile-username text-center"><?= $detail->fname.' '.$detail->lname ?></h3>

              <p class="text-muted text-center"><b><?= $detail->designation ?></b></p>
              <p class="text-muted text-left">Mobile Number: <u style="color: black;"><?= $detail->mobile_number ?></u></p>
              <p class="text-muted text-left">Landline: <u style="color: black;"><?php echo ($detail->areacode!='')?"(".$detail->areacode.") ":''; echo $detail->landline; ?></u></p>
              <p class="text-muted text-left">Email: <u style="color: black;"><?= $detail->email ?></u></p>
              <p class="text-muted text-left">PhilGEPS Number: <u style="color: black;"><?= $detail->philgeps_no ?></u></p>
              <p class="text-muted text-left">Philgeps Certificate: 
                <?php if($detail->philgeps_file!=''){ ?>
                <u style="color: black;">
                  <a href='<?= base_url().$detail->philgeps_file; ?>' target='_blank'> View</a>
                </u>
                <?php } ?>
              </p>
              <p class="text-muted text-left">Form 2303: 
                <?php if($detail->form2303_file!=''){ ?>
                <u style="color: black;">
                  <a href='<?= base_url().$detail->form2303_file; ?>' target='_blank'> View</a>
                </u>
                <?php } ?>
              </p>
              <p class="text-muted text-left">Curriculum Vitae: 
                <?php if($detail->cv_file!=''){ ?>
                <u style="color: black;">
                  <a href='<?= base_url().$detail->cv_file; ?>' target='_blank'> View</a>
                </u>
                <?php } ?>
              </p>

              <ul class="list-group list-group-unbordered">
                <a href="#" class="view_list" status='0'>
                  <li class="list-group-item">
                    <b>Pending Bids</b> <a class="pull-right"><?= $pending_bids ?></a>
                  </li>
                </a>
                <a href="#" class="view_list" status='1'>
                  <li class="list-group-item">
                    <b>Win Bids</b> <a class="pull-right"><?= $win_bids ?></a>
                  </li>
                </a>
                <a href="#" class="view_list" status='2'>
                  <li class="list-group-item">
                    <b>Failed Bids</b> <a class="pull-right"><?= $failed_bids ?></a>
                  </li>
                </a>
                <?php if($detail->account_status == 1){ ?>
                	<h4>Account Status: <span class="badge bg-light-blue">Basic</span></h4>
            	<?php }elseif($detail->account_status == 2){ ?>
                	<h4>Account Status: <span class="badge bg-yellow">Pending Verification</span></h4>
            	<?php }elseif($detail->account_status == 3){ ?>
                	<h4>Account Status: <span class="badge bg-green">Verified</span></h4>
            	<?php }?>
              </ul>
              <button class="btn btn-primary btn-block" id="updateBtn">UPDATE PROFILE</button>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Organization Details</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
              <p class="text-muted"><?= $detail->location ?></p>
              <hr>

              <strong><i class="fa fa-users margin-r-5"></i> Form of organization</strong>
              <p class="text-muted"><?= $detail->foo ?></p>
              <hr>

              <strong><i class="fa fa-list-alt margin-r-5"></i> Organization Name</strong>
              <p class="text-muted"><?= $detail->org_name ?></p>
              <hr>

              <strong><i class="fa fa-id-card margin-r-5"></i> Business Tax Identification Number</strong>
                <p><span class="label label-success"><?= $detail->btin ?></span></p>
              <hr>

              <strong><i class="fa fa-list-alt margin-r-5"></i> Line of Business</strong>
              <p class="text-muted"><?= $detail->lob ?></p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="content">
            	<div class="content-header">
            		<h4>Permits, Clearances & Forms</h4>
            	</div>
            	<hr>
                <!-- Post -->
                <div class="box">
                  <div class="box-header with-border">
                  	<h5><i class="fa fa-certificate"></i> Mayors Permit</h5>
                  </div>
                  <div class="box-body">
	                  <div class="col-md-12">
	                  	<div class="col-md-2"><label>Expiration Date:</label><br><?= $detail->m_exp_date ?></div>
	                  	<div class="col-md-2"><label>Place of Issue<br><?= $detail->m_place ?></label></div>
	                  	<div class="col-md-2"><label>Issuance Date</label><br><?= $detail->m_issue_date ?></div>
	                  	<div class="col-md-2"><label>Permit Number</label><br><?= $detail->m_permit_no ?></div>
	                  	<div class="col-md-2"><label>Issued By</label><br><?= $detail->m_signatory ?></div>
	                  	<div class="col-md-2"><label>
	                  		Uploaded File</label><br>
	                  		<a href='<?= base_url().$detail->m_file; ?>' target='_blank'> View</a>
	                  		</div>
	                  </div>
	              </div>
              	</div>
                <div class="box">
                  <div class="box-header with-border">
                  	<h5><i class="fa fa-certificate"></i> DTI Permit</h5>
                  </div>
                  <div class="box-body">
	                  <div class="col-md-12">
	                  	<div class="col-md-2"><label>Registration Date:</label><br><?= $detail->dti_issue_date ?></div>
	                  	<div class="col-md-2"><label>Expiration Date</label><br><?= $detail->dti_exp_date ?></div>
	                  	<div class="col-md-2"><label>Certificate Number</label><br><?= $detail->dti_permit_no ?></div>
	                  	<div class="col-md-4"><label>Issued By / Signatory</label><br><?= $detail->dti_signatory ?></div>
	                  	<div class="col-md-2"><label>
	                  		Uploaded File</label><br>
	                  		<a href='<?= base_url().$detail->dti_file; ?>' target='_blank'> View</a>
	                  		</div>
	                  </div>
	                  </div>
	              </div>
              	</div>
                <div class="box">
                  <div class="box-header with-border">
                    <h5><i class="fa fa-certificate"></i> Tax Clearance</h5>
                  </div>
                  <div class="box-body">
                    <div class="col-md-12">
                      <div class="col-md-2"><label>Expiration Date:</label><br><?= $detail->tc_exp_date ?></div>
                      <div class="col-md-2"><label>Issuance Date</label><br><?= $detail->tc_issue_date ?></div>
                      <div class="col-md-2"><label>TCC Number</label><br><?= $detail->tc_permit_no ?></div>
                      <div class="col-md-4"><label>Issued By / Signatory</label><br><?= $detail->tc_signatory ?></div>
                      <div class="col-md-2"><label>
                        Uploaded File</label><br>
                        <a href='<?= base_url().$detail->tc_file; ?>' target='_blank'> View</a>
                      </div>
                    </div>
                    </div>
                </div>
                <?php if($detail->account_status == 3){ ?>
<!--                 <div class="box">
                  <div class="box-header with-border">
                    <h5><i class="fa fa-certificate"></i> FORMS</h5>
                  </div>
                  <div class="box-body">
                    <div class="col-md-12">
                      <div class="col-md-2"><label>Bid Form:</label><br>
                        <br><a href='<?= base_url().'/assets/uploads/for_downloads/BID-Form.docx'; ?>' target='_blank'> Download</a>
                      </div>
                      <div class="col-md-2"><label>Bank Guarantee</label><br>
                        <br><a href='<?= base_url().'/assets/uploads/for_downloads/Bank-Guarantee-Form.docx'; ?>' target='_blank'> Download</a>
                      </div>
                      <div class="col-md-2"><label>Bid securing declaration</label><br>
                        <a href='<?= base_url().'/assets/uploads/for_downloads/BID-SECURING-DECLARATION-FORM.docx'; ?>' target='_blank'> Download</a>
                      </div>
                      <div class="col-md-2"><label>Goods offered from abroad</label><br>
                        <a href='<?= base_url().'/assets/uploads/for_downloads/For-Goods-Offered-From-Abroad.docx'; ?>' target='_blank'> Download</a>
                      </div>
                      <div class="col-md-2"><label>Goods offered from local</label><br>
                        <a href='<?= base_url().'/assets/uploads/for_downloads/For-Goods-Offered-From-Local.docx'; ?>' target='_blank'> Download</a>
                      </div>
                      <div class="col-md-2"><label>Omnibus Sworn Statement</label><br>
                        <a href='<?= base_url().'/assets/uploads/for_downloads/Omnibus-Sworn-Statement.docx'; ?>' target='_blank'> Download</a>
                      </div>
                    </div>
                    </div>
                </div>
 -->                <?php }//end if status !=3 ?>
              	</div>
                <!-- /.post -->
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
<?php  $this->load->view('suppliers/modal'); ?>
