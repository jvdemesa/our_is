<style>
    .badge {
        white-space: normal;
    }
</style>

<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        <i class="fa fa-address-card-o"></i> Cancelled travel order
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Reports</li>
        </ol>
    </section>

    <section class="content">
       

        <div class="row">
        <br>   
            <div class="box-body">
              <div class="col-lg-12 col-md-12">

                <div class="box box-default <?=$display_division?>">
                    <div class="box-body">
                        <div class="col-lg-3  pull-right">
                            <div id="div_unit"> 
                                <select class="form-control select2 " name="div_id" id="div_id" onchange="filter();">
                                    <option value="" disabled>SELECT DIVISION</option>
                                    <option value="">ALL</option>
                                    <?php foreach($division as $val){
                                        echo "<option value='$val->divunit_id'> $val->divunit_abv - $val->divunit_name</option>";
                                    }?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box box-success" id="details_box">
                  <div class="box-header  with-border">
                      <h3 class="box-title" id="document_list-title">Documents</h3>
                  </div>
                  <div class="box-body" id="document_list" style="overflow-x:auto;">
                    <table class="table table-responsive table-bordered table-striped table-hover"   id="document_list_table">
                      <thead>
                        <tr>
                          <td style='width=150px;' id="first_row">Date Created</td>
                          <td style='width=150px;'>DTSNO</td>
                          <td style='width=150px;'>Type</td>
                          <td style='width=500px;'>Doc Details</td>
                          <td style='width=500px;'>Reason</td>
                          <td style='width=500px;'>Date Cancelled</td>
                          <td style='width=500px;'>Cancelled by</td>
                        </tr>
                      </thead>
                      <tbody id="tbody">
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
            </div>
      </div>
    </section>
</div>
<?php  $this->load->view('reports/cancelled_travel_order/index_js'); ?>
<?php  $this->load->view('reports/cancelled_travel_order/index_modal'); ?>
