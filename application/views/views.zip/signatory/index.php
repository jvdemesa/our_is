<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        <i class="fa fa-address-card-o"></i> Signatory Dashboard
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        </ol>
    </section>

    <section class="content">
      <div class="row">
        <br>   
            <div class="box-body">
              <div class="col-lg-8 col-md-8">
                <div class="box box-danger" id="details_box">
                  <div class="box-header  with-border">
                      <h3 class="box-title" id="document_list-title">Documents for signature</h3>
                  </div>
                  <div class="box-body" id="document_list"style="overflow-x:auto;">
                    <table class="table table-responsive table-bordered table-striped table-hover" id="document_list_table">
                      <thead>
                        <tr>
                          <td width="10%" id="first_row">Date Created</td>
                          <td width="10%">DTSNO</td>
                          <td width="15%">Type</td>
                          <td width="45%">Details</td>
                          <td width="5%">Action</td>
                        </tr>
                      </thead>
                      <tbody id="tbody">
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4">
                  <div class="box box-success">
                      <div class="box-header with-border">
                          <h3 class="box-title">Digitally signed documents</h3>
                      </div>
                      <div class="box-body" id="recent_documents">
                      <table class="table table-bordered table-striped table-hover" id="digitally_signed_table" style="cursor:pointer">
                      <thead>
                        <tr>
                          <td width="40%">Date signed</td>
                          <td width="30%">DTSNO</td>
                          <td width="30%">Type</td>
                        </tr>
                      </thead>
                      <tbody id="tbody">
                      </tbody>
                    </table>
                      </div>
                  </div>
              </div>
            </div>
      </div>
    </section>
</div>
<?php  $this->load->view('signatory/index_js'); ?>
<?php  $this->load->view('signatory/index_modal'); ?>
