<script>
$(document).ready(function() {  
    var table = $('#document_list_table').DataTable({ 
      "order": false, //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
    });

    var table_right = $('#digitally_signed_table').DataTable({ 
      "order": false, //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
    });

  function get_data(){
    $.ajax({
      type: "POST",
      dataType: "json",
      url: "<?php echo base_url().'Signatory/for_signature_list'; ?>",
      // data: $("#form1").serializeArray(),
      beforeSend: function() {
        tr = `<tr id="loader">
                    <td colspan="41">
                      <div class="callout callout-info"><p><i class="fa fa-circle-o-notch fa-spin"></i> Loading Data...</p></div>
                    </td>
                </tr>`;
        $('#tbody').html(tr);
      },
      complete: function(){
        $('#loader').hide();
      },
      //data:formData,
        success: function(data){ 
          table.clear();
           $.each(data, function(key, val){
                          //             <button class="btn btn-xs btn-primary embed_signature" title="Embed Signature" dtsno="${val.dtsno}">
                          //   <i class="fa fa-thumbs-up"></i>
                          // </button>

             var rowNode = table.row.add([  
                          val.date_created,
                          val.dtsno,
                          val.doc_t,
                          val.doc_details,
                          `
                          <button class="btn btn-xs btn-info view_details" dtsno="${val.dtsno}" >
                            <i class="fa fa-eye"></i>
                          </button>
                          `
                      ]).node();
             // if(){
             //    $( rowNode ).addClass('warning'); 
             //  }
            })    
            table.draw();     
        }
    });
  }

  function get_data_signed(){
    $.ajax({
      type: "POST",
      dataType: "json",
      url: "<?php echo base_url().'Signatory/signed_list'; ?>",
      // data: $("#form1").serializeArray(),
      beforeSend: function() {
        tr = `<tr id="loader">
                    <td colspan="41">
                      <div class="callout callout-info"><p><i class="fa fa-circle-o-notch fa-spin"></i> Loading Data...</p></div>
                    </td>
                </tr>`;
        $('#tbody').html(tr);
      },
      complete: function(){
        $('#loader').hide();
      },
      //data:formData,
        success: function(data){ 
          table_right.clear();
           $.each(data, function(key, val){
             var rowNode = table_right.row.add([  
                          val.date_signed,
                          val.dtsno,
                          val.doc_t,
                      ]).node();
             // if(){
             //    $( rowNode ).addClass('warning'); 
             //  }
            })    
            table_right.draw();     
        }
    });
  }

  get_data();
  get_data_signed();

  table_right.on('click', 'tbody tr', function() {
    var dtsno = $(this).find('td:eq(1)').text();
    window.location.href = `<?php echo base_url(); ?>Document/${dtsno}`;
  });

  $("#document_list_table").on('click','.embed_signature',function(){
    var dtsno = this.getAttribute("dtsno");
    $("#dtsno").val(dtsno);
    $('#confirm_modal').modal("show");
  })

  $("#confirm_btn").click(function(){
    var dtsno = $("#dtsno").val();
    $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {dtsno:dtsno},
      url: base_url+'Signatory/embed_signature',
      success: function(data){
        if(data!=false){
          get_data();
          get_data_signed();
          check_alerts();
          $('#confirm_modal').modal("hide");
          toastr.success("E-Signature / E-Initial has been attached to the document");
        }else{
          get_data();
          get_data_signed();
          check_alerts();
          $('#confirm_modal').modal("hide");
          toastr.warning("Document may have been removed for E-Signature / E-Initial");
        }
      }
    })
  })

  $("#document_list_table").on('click','.view_details',function(){
    var dtsno = this.getAttribute('dtsno');
    window.location.replace("<?php echo base_url(); ?>Document/"+dtsno);
  })
})
</script>