  <script>
  let quick_search_body;
  function check_alerts(){
    $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>"+'Alerts/check',
    dataType: "JSON",
    success: function(data){
      var alert_list='';
      var alert_count = 0, seen_count=0;
      $.each(data.for_signature, function(key, val){
        val.notif!=0?alert_count++:seen_count++;
      var color = val.notif==0?'red':'green';
        alert_list +=`<li class='viewAlert ' dtsno='${val.dtsno}' notif='${data.notif}'>
                        <a href="#">
                          <div class="pull-left text text-${color} ">
                           DTSNO: ${val.dtsno}
                          </div>
                          <h4>
                            <small>View</small>
                          </h4>
                          <br>
                          <p class="text-left"><i class="fa fa-clock-o"></i>${val.date_for_signature}</p>
                        </a>
                      </li>
                      `;
            });
      if(alert_count!=0){
        $('#alert_count').html(alert_count);
      }
      if(seen_count!=0){
        $('#seen_count').html(seen_count);
      }
      if(data.designation == 8){
        $('#alert_header_title').html(`${alert_count} Newly Signed Documents`);
      }else{
        $('#alert_header_title').html(`${alert_count} New for Signature / Initial`);
      }
      $('#restricted_client_list').html(alert_list);
    }
  });
  }

  $('.navbar-custom-menu').on('click','.viewAlert',function(){
    $('#markAsRead').removeClass('readOpp').addClass('readAlert');
    var dtsno = this.getAttribute("dtsno");
    var notif = this.getAttribute("notif");
    $('#alert_id').val(alert_id);
    $.ajax({
    type: "POST",
    data: {dtsno:dtsno,notif:notif},
    dataType: "JSON",
    url: "<?php echo base_url(); ?>"+'Alerts/view',
    success: function(data){
        window.location.replace("<?php echo base_url(); ?>Document/"+data);
      }
    });
  })

  $('.navbar-custom-menu').on('click','.viewOpp',function(){
    var alert_id = this.getAttribute("alert_id");
    $('#markAsRead').removeClass('readAlert').addClass('readOpp');
    $('#alert_id').val(alert_id);
    $.ajax({
    type: "POST",
    data: {alert_id:alert_id},
    dataType: "JSON",
    url: "<?php echo base_url(); ?>"+'admin/view_opp',
    success: function(data){
        var text = `<h3>Bid has been Awarded!</h3>
                    <h6>
                      <label>Reference No:</label><br> ${data.details.ref_num}<hr>
                      <label>Notice Title:</label><br>${data.details.notice_title}<hr>
                      <label>Details:</label><br>${data.details.details}<hr>
                    </h6>
                    <a href='<?= base_url(); ?>/Opportunities/view/${data.details.o_id}'>View Bid details</a>
                  `;
        $('.div_message').html(text);
        $('#alert_modal').modal('show');
      }
    });
  })

  $(document).on('click','.readAlert',function(){
    var alert_id = $('#alert_id').val();
    $.ajax({
    type: "POST",
    data: {alert_id:alert_id},
    dataType: "JSON",
    url: "<?php echo base_url(); ?>"+'admin/markAsRead',
    success: function(data){
        toastr.success('Successfully Marked as Read.');
        check_alerts();
        $('#alert_modal').modal('hide');
      }
    });
  })

  $(document).on('click','.readOpp',function(){
    var alert_id = $('#alert_id').val();
    $.ajax({
    type: "POST",
    data: {alert_id:alert_id},
    dataType: "JSON",
    url: "<?php echo base_url(); ?>"+'admin/markAsRead_opp',
    success: function(data){
        toastr.success('Successfully Marked as Read.');
        check_alerts();
        $('#alert_modal').modal('hide');
      }
    });
  })

  setInterval(function(){
  check_alerts();
  }, 50000);
  check_alerts();

  function fast_received(dtsno){
      $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {dtsno:dtsno},
      url: base_url+'General/fast_receive',
      success: function(data){
        if(data.result == true){
          toastr.success(`Document Received! <br> DTSNO: ${dtsno}`);  
        }else{
          toastr.warning(data.error_msg);  
        }
        $("#fast_receive").val('');
      }
    });
  }

  function dts_quick_search(dtsno){
      $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {dtsno:dtsno},
      url: base_url+'General/quick_search',
      success: function(data){
        if(data.result){
         quick_search_dtsno = data.result.dtsno;
          if(data.result.receiver==""){
            var curr_loc = data.result.from_div+" - "+data.result.from_unit;
          }else{
            var curr_loc = data.result.to_div+" - "+data.result.to_unit;
          }
          if(data.result.sub_type != null){
            var doc_type = `${data.result.doc_type} - ${data.result.sub_type}`;
          }else{
            var doc_type = `${data.result.doc_type}`;
          }
            var html = "";
            html = `<table class="table table-bordered">
                      <thead>
                        <th>Date Forwarded</th>
                        <th>DTSNO</th>
                        <th>Type / Sub-Type</th>
                        <th>Details</th>
                        <th>Current Location</th>
                      </thead>
                      <tbody>
                        <td>${data.result.date_forwarded}</td>
                        <td>${data.result.dtsno}</td>
                        <td>${doc_type}</td>
                        <td>${data.result.doc_details}</td>
                        <td>${curr_loc}</td>
                      </tbody
                    </table>`;
            $("#quick_search_body").html(html);
            $("#quick_search_modal").modal("show");
        }else{
          toastr.warning(data.error_msg);  
        }
        $("#fast_receive").val('');
      }
    });
  }

  $(document).on('click','#quick_search_div',function(){
    if($("#quick_search").is(":checked")){
      $("#fast_receive").attr("placeholder", "Quick Search");
    }else{
      $("#fast_receive").attr("placeholder", "Fast Receive");  
    }
  });

  $(document).ready(function () {
    $("#fast_receive-btn").click(function(e){
      let dtsno = $("#fast_receive").val();
      var quick_search = $("#quick_search").is(":checked");
      if(!quick_search){
        fast_received(dtsno);      
      }else{
        dts_quick_search(dtsno);      
      }
    });

    $("#fast_receive").keypress(function(e){
      var keycode = (e.keyCode ? e.keyCode : e.which);
      let dtsno = $(this).val();
      if(keycode == '13'){
        var quick_search = $("#quick_search").is(":checked");
        if(!quick_search){
          fast_received(dtsno);      
        }else{
          dts_quick_search(dtsno);      
        }
      }
    })

    $("#view_quick_search").click(function(e){
      window.location = "<?php echo base_url(); ?>"+"Document/"+quick_search_dtsno;
    })

    $("#goto_profile").click(function(){
      window.open("<?= base_url("/Users/profile") ?>");
    })
  });
</script>
<?php  $this->load->view('template/admin_modal'); ?>