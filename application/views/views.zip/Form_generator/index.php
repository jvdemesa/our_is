<style>
.fileUpload {
    position: relative;
    overflow: hidden;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
.FixedHeightContainer
{
  height: 600px;
}



table#form_preview>tbody>tr>td {
    vertical-align: middle;
}

table#form_preview>tbody>tr {
    cursor: pointer;
}
</style>
<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        <i class="fa fa-list-ol"></i> Form Generator
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        </ol>
    </section>

    <section class="content">
      <div class="row">
        <br>   
        <div class="col-lg-6 col-md-6">
          <div class="box box-default" id="details_box">
            <div class="box-header  with-border">
              <h3 class="box-title" id="document_list-title">List</h3>
              <div class="box-tools">
                  <button class="btn btn-info btn-sm" id="add_doc_type">
                      <i class="fa fa-plus fa-1x"> </i> Add Doc Type
                  </button>
              </div>
            </div>
            <div class="box-body">
              <table class="table table-responsive table-bordered" id="list">
                <thead>
                  <th width="45%">Doc Type</th>
                  <th width="40%">Parent</th>
                  <th width="10%">Enable</th>
                  <th width="5%">Action</th>
                </thead>
                <tbody>
                  <?php foreach($list as $val){ ?>
                  <tr>
                    <td><?= $val->doc_t ?></td>
                    <td><?= ($val->parent=="")?"N/A":$val->parent ?></td>
                    <td><?= $val->is_disable ?></td>
                    <td>
                      <center>
                        <button type="button" class="btn bg-primary btn-xs edit_form" data-name='<?= $val->doc_t ?>' data-id='<?= $val->id ?>' title="Edit form" >
                          <i class="fa fa-edit"></i>
                        </button>
                      </center>
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        <!--END DOCTYPE LIST-->
          <div class="box box-default" id="details_box">
            <div class="box-header  with-border">
              <h3 class="box-title" id="document_list-title">Form Creator:</h3>
              <div class="box-tools">
              </div>
            </div>
            <form class="form-horizontal" id="form_creator">
              <div class="box-body">
                
               
                <div class="form-group">
                  <label for="field_type" class="col-sm-3 control-label">Field Type:</label>
                  <div class="col-sm-9">
                    <select class="select2" id="field_type">
                      <option value="1" >Text Box</option>
                      <option value="3" >Text Area</option>
                      <option value="4" >Drop Down of ERDBD employee</option>
                      <option value="5" >Single Date Picker</option>
                      <option value="6" >Daterange Picker</option>
                      <option value="9" >Signatory Division Chief / Center Head</option>
                      <option value="8" >Signatory Director's Office</option>
                      <option value="7" >Signatory Assistant Director's Office</option>
                      <option value="10" >Upload PDF File</option>
                      <option value="11" >Approved T.O List</option>
                      <option value="12" >Approved Itinerary List</option>
                      <option value="13" >Approved OBR List</option>
                      <option value="14" >Approved COTC List</option>
                      <option value="15" >Signatory Accountants Office</option>
                      <option value="16" >Signatory Unit Head</option>
                      <option value="17" >Signatory Budget Officer</option>
                      <option value="18" >Approved CA</option>
                      <option value="19" >Approved Liquidation of CA with reimbursement</option>
                      <option value="20" >List of RC</option>
                      <option value="21" >List of Approved DV For ADA</option>
                      <option value="22" >List of SO</option>
                      <option value="23" >Yes or No</option>
                    </select>
                  </div>
                </div>

                <div class="form-group">
                  <label for="field_name" class="col-sm-3 control-label">Field Name:</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="field_name" id="field_name">
                  </div>
                </div>

                <div class="form-group">
                  <label for="is_required" class="col-sm-3 control-label">Is Required?</label>
                  <div class="col-sm-9">
                    <select class="form-control" id="is_required">
                      <option value="1" >Yes</option>
                      <option value="0" >No</option>
                    </select>
                  </div>
                </div>

                <div class="box-footer">
                  <button type="submit" id="add_field" class="btn btn-info pull-right">ADD</button>
                </div>
              </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 ">
          <div class="box box-default" id="details_box">
            <div class="box-header  with-border">
              <h3 class="box-title" id="document_list-title">Form Preview <span id="doc_type_name"></span>:</h3>
              <div class="box-tools">
              </div>
            </div>
            <div class="box-body" id='doc_type_form_fields'>
                
                <input type='hidden' id="update_doc_type" value='' /> 
                <table id="form_preview" class="table table-striped">
                    <thead></thead>
                    <tbody></tbody>
                </table>
                
            </div>
            <div class="box-footer">
              <button type="button" class="btn btn-warning pull-left" onclick="reset_fields();">Reset</button> 
              <button type="button" class="btn btn-success pull-right" onclick="save_generated_fields();">Save</button>
            </div>
          </div>
        </div>
        <!--END FORM CREATOR-->
      </form>
      </div>
    </section>
</div>
<?php  $this->load->view('Form_generator/index_js'); ?>
<?php  $this->load->view('Form_generator/index_modal'); ?>
