<style type="text/css">

</style>

<div class="modal fade" id="add_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
        <!-- Modal Header -->
            <div class="modal-header modal-header-success">
                <button type="button" class="close" 
                    data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" >
                    Add Document Type
                </h4>
            </div>
            <form id="form_add_doc_type" method="POST" action="<?= base_url("/Form_generator/save_doc_type") ?>">
            <!-- Modal Body -->
            <div class="modal-body">
                <div class="table table-responsive">
                <table class="table table-bordered table-hover">
                    <tr>
                        <td>
                            <label>Document Type: 
                        </td>
                        <td>
                            <input type="text" name="doc_type_name" id="add_doc_type_name" class="form-control" required="required" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Parent Document: 
                        </td>
                        <td>
                            <select name="parent_id" class="form-control" id="add_parent_id">
                                <option value="" selected disabled>Select Document Type</option>
                                <?php foreach($list as $val){ ?>
                                <option value="<?= $val->id ?>" ><?= $val->doc_t ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Is Disabled?: 
                        </td>
                        <td>
                            <select class="form-control" name="is_disable" id="add_is_disable">
                                <option value="1" selected>Yes</option>
                                <option value="0" selected>No</option>
                            </select>
                        </td>
                    </tr>
                </table>
                </div>
            </div><!--end Modal body-->
            <!--SUBMIT BUTTON -->
            <div class="modal-footer" align="right">
                <div class="form-group">
                    <div class="col-sm-12" align="right">
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                            Close
                        </button>
                        <input type="submit" id="add_doc_type_btn" class="btn btn-success" value="Save" >
                    </div>
                </div>
            </div>
        </form>
        </div><!--end Modal content-->
    </div><!--end Modal dialog-->
</div><!--end modal receive-->




<!-- update_field_modal -->
<div class="modal fade" id="update_field_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
        <!-- Modal Header -->
            <div class="modal-header modal-header-success">
                <button type="button" class="close" 
                    data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title">
                    Update field name
                </h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">

                <div class="table table-responsive">
                <table class="table table-bordered table-hover">
                    <tr>
                        <td>
                            <label>Field Name: 
                        </td>
                        <td>
                            <input type="text" name="name" id="update_field_name" class="form-control"/>
                        </td>
                    </tr>
                </table>
                </div>
            </div><!--end Modal body-->
            <!--SUBMIT BUTTON -->
            <div class="modal-footer" align="right">
                <div class="form-group">
                    <div class="col-sm-12" align="right">
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                            Close
                        </button>
                        <button type="button" class="btn btn-success" onclick="save_field_name()">Save</button>
                    </div>
                </div>
            </div>
        </div><!--end Modal content-->
    </div><!--end Modal dialog-->
</div><!--end modal receive-->

