<script>
$(document).ready(function() {  
    // $('.select2_names:last').select2();
let is_required = [];
let field_name = [];
let doc_type = [];
let type = [];

var table = $('#list').DataTable({ 
    "order": [], //Initial no order.
    responsive: true,
    "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
    "iDisplayLength": 3,
    dom: 'Blfrtip',
});

$("table#form_preview").find('tbody').sortable();
    
$("#add_field").click(function(e){
    e.preventDefault();
    var data_field = {};
    data_field.is_required = $("#is_required").val();
    data_field.fieldname = $("#field_name").val();
    data_field.fieldtype = $("#field_type").val();
    data_field.id = 0;
    data_field.is_field_used = '0';

    append_form_field(data_field);
    // $("#is_required").val(1).trigger('change');
    $("#field_name").val('');
    // $("#field_type").val(1).trigger('change');
}); 
    
$("#save_fields").click(function(e){
    e.preventDefault();
    $.ajax({
    type: "POST",
    dataType: "JSON",
    data: {is_required:is_required, field_name:field_name, field_type:type, doc_type:doc_type},
    url: base_url+'Form_generator/generate_form',
    success: function(data){
        toastr.success("Form Has Been Saved!");
        $("#form_creator").trigger("reset");
        $("#form_preview").html("");
    }
    });
})

$("#add_doc_type").click(function(){
    $("#add_modal").modal("show");
});



    $("#list").on("click",".edit_form",function(e){
        e.preventDefault();

        var form_id = $(this).data("id");
        var doc_name = $(this).data("name");
        $("table#form_preview").find('thead').html("<tr><td colspan='3'><center><label>"+doc_name+"</label></center></td></tr>");

        generate_form(form_id);
    });

});

function generate_form(id) {
    $.post(base_url+'Form_generator/form_details', { id: id },
        function(data) {
            var form_preview = $("#form_preview").html();
            $("table#form_preview").find('tbody').html('');
            $("#update_doc_type").val(id);
            $.each(data, function(i, item) {
                append_form_field(data[i]);
            });
        }, 'json'
    );
}

function append_form_field(data_field) {
    if ($("#update_doc_type").val() == '') {
        toastr.warning("Please select a doc type before adding a new field.");
        return false;
    } 
    var tr = $("<tr></tr>");
    var label = "";
    var required = data_field.is_required == 1?`style="color: #ff0040;"`:``;
    var fieldname = data_field.fieldname;
    var field_type = data_field.fieldtype;
    var field_id = data_field.id;
    var form_preview_tbody = $("table#form_preview").find('tbody');


    var label_hidden_input = "<td>" ;
    label_hidden_input += "<input type='hidden' name='is_required[]' value='" +  data_field.is_required  + "' />" ;
    label_hidden_input += "<input type='hidden' name='fieldname[]' class='fieldname' value='" + fieldname + "' />" ;
    label_hidden_input += "<input type='hidden' name='field_type[]'  value='" + field_type + "' />" ;
    label_hidden_input += "<input type='hidden' name='field_id[]'  value='" + field_id + "' />" ;
    label_hidden_input += "<label " + required + " class='label_fieldname'> " + fieldname + ":</label></td>";
    $(tr).append(label_hidden_input);

    var disable_delete = data_field.is_field_used != '0' ? true : false;

    switch(field_type) {
            case "1":
                // var td = $(`<td><label ${required}>${fieldname}:</label></td></td>`);
                // $(tr).append(td);
                $(tr).append('<td><input type="text" class="form-control" ' + required + '>');
               
                break;
            case "3":
                $(tr).append('<td><textarea class="form-control" rows="3" ></textarea></td>');
                break;
            case "4"://for erdb employees list
                var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');

            break;
            case "5":
                $(tr).append('<td><input type="text" class="form-control datepicker_dynamic" >');
            break;
            case "6":
                $(tr).append('<td><input type="text" class="form-control daterangepicker_dynamic" >');
                break;
        case "7"://for AD
            var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
                // $(select2_signatories).select2();

        break;
        case "8"://for A
        //value = array[signatory_id,unique_case_no,fullname]
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
                // $(select2_signatories).select2();
        break;            
    case "9"://for Division Chief / Center Head
    //value = array[signatory_id,unique_case_no,fullname]
    var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
                // $(select2_signatories).select2();
        break;
    case "10"://for upload file
                 var upload_file =`<td>
                                <div class="input-group">
                                    <input type="text" class="form-control" readonly>
                                    <div class="input-group-btn">
                                    <span class="fileUpload btn btn-success">
                                    <span class="upl">Upload file</span>
                                    <input type="file" class="upload up" name="upload_file" accept="application/pdf,application/vnd.ms-excel" disabled/>
                                    </span><!-- btn-orange -->
                                </div><!-- btn -->
                            </td>`;

                $(tr).append(upload_file);

        break;
    case "11"://list of approved TO
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');

        break;
    case "12"://list of approved IT
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "13"://list pf approved OBR
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "14"://list pf approved COTC
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "15"://for Accountant
            var select =`<select class="form-control" >`;
                        select += `<option value=""></option>`; 
                        select +=`</select>`;

            $(tr).append('<td>' + select + '</td>');
        break;      
    case "16"://for Unit Head
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;        
    case "17"://for Budget Officer
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;  
    case "18"://list of approved CA
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "19"://list of approved Liquidation of CA with reimbursement
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "20"://list of RC
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "21"://list of Approved DV for ADA
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "22"://list of SO
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    case "23"://yes or no
        var select =`<select class="form-control" >`;
                    select += `<option value=""></option>`; 
                    select +=`</select>`;

        $(tr).append('<td>' + select + '</td>');
        break;
    }

    append_form_preview_tbody(tr,disable_delete);
}

function append_form_preview_tbody(tr, disable_delete = false) {

    var disable_delete_txt = disable_delete ?  'disabled="disabled"' : '';
    var remove_icon = $('<td><center><button type="button" class="btn bg-primary btn-xs" onclick="edit_field(this);" title="Edit field name"><i class="fa fa-pencil"></i></button> <button type="button" onclick="delete_field(this);" class="btn bg-primary btn-xs" title="Delete button" ' + disable_delete_txt + ' ><i class="fa fa-trash"></i></button></center></td>');
    var form_preview_tbody = $("table#form_preview").find('tbody');
    $(tr).append(remove_icon);
    $(form_preview_tbody).append(tr);

}

var edit_tr;
function delete_field(btn) {
    $(btn).closest('tr').remove();
}
function edit_field(btn) {
    edit_tr = $(btn).closest('tr');
    $("#update_field_name").val($(edit_tr).find('input.fieldname').val());
    $("#update_field_modal").modal('show');
}


function save_field_name() {

    var field_name = $("#update_field_name").val();

    $(edit_tr).find('input.fieldname').val(field_name);

    
    $(edit_tr).find('label.label_fieldname').html(field_name);

    $("#update_field_modal").modal('hide');
}

function reset_fields() {

    if ($("#update_doc_type").val() == '') {
        toastr.warning("Please select a doc type before adding a new field.");
        return false;
    } 

    var id = $("#update_doc_type").val();
    generate_form(id);

}

function save_generated_fields() {

    if ($("#update_doc_type").val() == '') {
        toastr.warning("Please select a doc type before adding a new field.");
        return false;
    } 
    var id = $("#update_doc_type").val();
    var newForm = $('<form></form>');
    $(newForm).append($('<input name="doc_type_id" type="hidden" value="' + id + '" />'));
    $.each($("table#form_preview").find("input[type=hidden]"),function(i,v){
        $(newForm).append($(this));
    });


    var serializedData = $(newForm ).serializeArray();
    $.post(base_url+'Form_generator/save_form_fields',  serializedData,
        function (e) {
            generate_form(e.doc_type_id);
            toastr.success("Form has been successfully updated.");
        }, 'json'
    );



}

</script>