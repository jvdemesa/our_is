<link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/croppie/croppie.css">
<script src="<?php echo base_url(); ?>assets/js/croppie/croppie.min.js"></script>

<script>
var unit_id = "", ads_id;
function getDiv(val,type) {
  
    var unit_options="";
    if(val != 0){
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>General/unit_list",
        dataType: "JSON",
        data:'divunit_id='+val,
        success: function(data){
          if(data != false){
              unit_options +=`<option value='' selected disabled>Select Unit</option>`;
              unit_options = `<option value='0'>Apply to All</option>`;
              $.each(data, function(i, val) {
              unit_options +="<option value='"+val.divunit_id+"' title='"+val.divunit_name+"'>"+val.divunit_abv+"</option>";
              });
          }
          else{
              unit_options +="<option value=''>Please Select Division First</option>";
          }
          if(type == 0 ){
            $("#unit").html(unit_options);
            if(unit_id != ""){
              $(".unit").val(unit_id).change();     
            }
          }else{
            $("#sunit").html(unit_options);
            if(unit_id != ""){
              $(".sunit").val(unit_id).change();     
            }
          }
        }
      });
    }else{
      var unit_options = `<option value='0'>Apply to All</option>`;
      $("#unit").html(unit_options);
    }
  }
function get_ads() {
    var ads_options="";
    var ad_id = $("#ad_id").val();
    var is_region = $("#is_region").val();
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Signatory_matrix/get_ad_signatory",
      dataType: "JSON",
      data:{ad_id:ad_id,is_region:is_region},
      success: function(data){
        if(data != false){
            ads_options +=`<option value='' selected disabled>Select Signatory Label</option>`;
            $.each(data, function(i, val) {
            ads_options +="<option value='"+val.id+"' title='"+val.label+"'>"+val.label+"</option>";
            });
        }
        else{
            ads_options +="<option value=''>Please Select Automated Document First</option>";
        }
        $("#ads_id").html(ads_options);
        if(ads_id != ""){
          $("#ads_id").val(ads_id).change();     
        }
      }
    });
  }

  $(document).ready(function() {
  $("#filter").click(function(e){
    $("#division").val("").trigger("change");
    $("#designation").val("").trigger("change");
    $("#ad_id").val("").trigger("change");
    $("#ads_id").val("").trigger("change");
    $("#signatory").val("").trigger("change");

    table.ajax.reload( null, false );
  }) 
  
  $( "#form1" ).on( "click", "#submit_add", function(e) {
    e.preventDefault();
    if (!$('form')[0].checkValidity()) {
      $('form').find('input[type="submit"]').click();
      $("form")[0].reportValidity();
      return false;
    }else{
      var form_data = new FormData($("form")[0]);
      $.ajax({
        type: "POST",
        url: $('#form1').attr('action'),
        dataType: "JSON",
        data:form_data,
        contentType: false, 
        processData: false, 
        success: function(msg){
          toastr.success(msg);
          table.ajax.reload( null, false );
          $('#modal').modal('hide');
        }
      })
    }
  });
  $("#add_signatory_matrix").click(function() {
      $('#form1')[0].reset();
      $("#sm_id").val("");
      $(".select2").val("").change();
      $("#modal_title_add").text('Add Signatory Flow');
      document.getElementById('form1').action =  '<?php echo base_url()."Signatory_matrix/add"; ?>';
      $('#modal').modal('show');
});

  $( "#viewresult" ).on( "click", ".edit_info", function(e) {
    e.preventDefault();
    var id = this.getAttribute("sm_id");
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Signatory_matrix/get_details",
      dataType: "JSON",
      data:{id:id},
      success: function(data){
        unit_id = data.unit_id;
        ads_id = data.ads_id;
        $("#sm_id").val(data.id);
        $(".division").val(data.div_id).trigger('change');
        $("#designation").val(data.designation_id).trigger('change');
        $("#ad_id").val(data.ad_id).trigger('change');
        $("#is_region").val(data.is_region).trigger('change');
        $("#signatory").val(data.signatory_id).trigger('change');
        $("#duration_from").val(data.duration_from);
        $("#duration_to").val(data.duration_to);
        $('#modal').modal('show');
      }
    });
  });

    // $('#viewresult').DataTable({
    //   responsive: true,
    //   serverside: true,
    //   "aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
    //   "iDisplayLength": 10
    // });

    table = $('#viewresult').DataTable({ 
      "processing": true, //Feature control the processing indicator.
      "serverSide": true, //Feature control DataTables' server-side processing mode.
      "order": [], //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
      select: true,
      "ajax": {
        "url": "<?php echo site_url('Signatory_matrix/datatable_list')?>",
        "type": "POST",
        "data": function ( data ) {
          data.div_id = $("#div_id").val();
          data.designation_id = $("#s_designation").val();
          data.ad_id = $("#s_ad_id").val();
          data.signatory_id = $("#s_signatory").val();
          data.is_region = $("#s_is_region").val();
        },
        "dataSrc": function(json){
          return json.data;
        }
      },
      //Set column definition initialisation properties.
      "columnDefs": [
        { 
          "targets": [ 0 ], //first column / numbering column
          "orderable": false, //set not orderable
        },
      ],
    createdRow: function( row, data, dataIndex ) {
        // Set the data-status attribute, and add a class
        // if(data[5]!='' && data[5]!=null){
        //   var closing_date = new Date(data[5]);
        //   var today = new Date();
        //   var diff = new Date(closing_date - today);
        //   var days = Math.round(diff/1000/60/60/24);
        //     if(days <=0){
        //       //$(row).addClass("label-warning");
        //     }
        // }
    }
    });


    $( "#datepicker" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });
    $( "#bday" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });
});
</script>
