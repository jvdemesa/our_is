<style>
.fileUpload {
    position: relative;
    overflow: hidden;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        Signatory Matrix
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li><a href="#"> Admin</a></li>
        <li class="active">Signatory Matrix</li>
        </ol>
    </section>

    <section class="content">
        <div class="box box-default">
            <div class="box-body">
                <div class="col-xs-12">
                    <div class="col-xs-3">
                        <select class="select2" name="div_id" id="div_id">
                            <option value="" selected disabled>Select Division</option>
                            <option value="">ALL</option>
                            <?php foreach($division as $val){
                                echo "<option value='$val->divunit_id'> $val->divunit_abv - $val->divunit_name</option>";
                            }?>
                        </select>
                    </div>
                    <div class="col-xs-2">
                        <select name="designation" id="s_designation" class="form-control select2" required="required" data-select2-id="4" tabindex="-1" aria-hidden="true">
                          <option value="" selected disabled>Select Employee Type</option>
                          <?php foreach($designation as $val){ ?>
                            <option value="<?= $val->id ?>"><?= $val->designation ?></option>
                          <?php } ?>
                        </select>
                    </div>
                    <div class="col-xs-2">
                        <select name="s_ad_id" id="s_ad_id" class="form-control select2" required="required" onChange="get_ads();">
                          <option value="" selected disabled>Select Document</option>
                          <?php foreach($automated_documents as $val){ ?>
                            <option value="<?= $val->id ?>"><?= $val->automated_documents ?></option>
                          <?php } ?>
                        </select>
                    </div>
                    <div class="col-xs-2">
                      <select name="signatory" id="s_signatory" class="form-control select2">
                        <option value="" selected disabled>Select Designation</option>
                        <option value="0">Not Applicable</option>
                        <?php foreach($designation as $val){ ?>
                          <option value="<?= $val->id ?>"><?= $val->designation ?></option>
                        <?php } ?>
                      </select>
                    </div>
                    <div class="col-xs-2">
                      <select required="required" name="s_is_region" id="s_is_region" class="form-control select2" onchange="get_ads()">
                        <option value="" selected disabled="">Select Apply to</option>
                        <option value="0">ERDB Main</option>
                        <option value="1">Regions</option>
                      </select>
                    </div>

                    <div class="col-xs-1">
                        <button class="btn btn-primary" id="filter">Filter</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                    <h3 class="box-title">Users List</h3>
                        <div class="box-tools">
                            <button class="btn btn-info btn-sm" id="add_signatory_matrix" >
                                <i  class="fa fa-plus fa-1x"> </i> Add Signatory Flow
                            </button>
                        </div>
                    </div>
                    
                    <div class="box-body">
                        <div id="refresh">
                            <div class="table-responsive">
                                <table style="width: 100%;" class="table table-striped table-bordered table-hover" id="viewresult">
                                    <thead>
                                        <tr >
                                        <th width="">ID</th>
                                        <th width="">Division</th>
                                        <th width="">Unit</th>
                                        <th width="">Employee Type</th>
                                        <th width="">Document</th>
                                        <th width="">Signature Label</th>
                                        <th width="">Signatory</th>
                                        <th width="">Duration (if Applicable)</th>
                                        <th width="">Apply To</th>
                                        <th style="width:100px;"><center>Action</center></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php  $this->load->view('Signatory_matrix/index_modal'); ?>
<?php  $this->load->view('Signatory_matrix/index_js'); ?>
