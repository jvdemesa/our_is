<style>
.fileUpload {
    position: relative;
    overflow: hidden;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        Advance Search
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li><a href="#"> Admin</a></li>
        <li class="active">Signatory Matrix</li>
        </ol>
    </section>

    <section class="content">
        <div class="box box-default">
            <div class="panel-body">
                <div class="col-md-12">
                    <form id="adv_search_form">
                    <div class="col-md-2">
                        <label>Document Creator (DIVISION):</label>
                        <select class="select2" name="div_id" id="div_id" onChange="getDiv(this.value);">
                            <option value="" selected disabled>Select Division</option>
                            <option value="">ALL</option>
                            <?php foreach($division as $val){
                                echo "<option value='$val->divunit_id'> $val->divunit_abv - $val->divunit_name</option>";
                            }?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Document Creator (UNIT):</label>
                        <select name="unit_id" id="unit_id" class="form-control select2 unit_id" data-select2-id="4" tabindex="-1" aria-hidden="true">
                          <option value="" selected disabled>Select Unit</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Document Type:</label>
                        <select name="doc_type_id" id="doc_type_id" class="form-control select2">
                          <option value="" selected disabled>Select Document</option>
                          <?php foreach($doc_type as $val){ ?>
                            <option value="<?= $val->id ?>"><?= $val->doc_t ?></option>
                          <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Document Sub-Type:</label>
                      <select name="sub_type" id="sub_type" class="form-control select2 sub_type">
                        <option value="" selected disabled>Select Sub-Type</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <label>Document Details:</label>
                      <input type="text" class="form-control" name="doc_details" id="doc_details">
                    </div>

                    <div class="col-xs-1">
                        <br>
                        <button class="btn btn-primary" id="filter">Filter</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                    <h3 class="box-title">Search List</h3>
                        <div class="box-tools">
                        </div>
                    </div>
                    
                    <div class="box-body">
                        <div id="refresh">
                            <div class="table-responsive">
                                <table style="width: 100%;" class="table table-striped table-bordered table-hover" id="viewresult">
                                    <thead>
                                        <tr >
                                        <th width="">DTSNO</th>
                                        <th width="">Creator</th>
                                        <th width="">Creator Div / Unit</th>
                                        <th width="">Date Created</th>
                                        <th width="">Type / Sub-Type</th>
                                        <th width="">Details</th>
                                        <th width="">Current Location</th>
                                        <th width="" style="width: 50px !important;">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php  $this->load->view('Advance_search/index_modal'); ?>
<?php  $this->load->view('Advance_search/index_js'); ?>
