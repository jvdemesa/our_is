<link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/croppie/croppie.css">
<script src="<?php echo base_url(); ?>assets/js/croppie/croppie.min.js"></script>

<script>
function getDiv(val,type) {
    var unit_options="";
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>General/unit_list",
        dataType: "JSON",
        data:'divunit_id='+val,
        success: function(data){
          if(data != false){
              unit_options +=`<option value='' selected disabled>Select Unit</option>`;
              $.each(data, function(i, val) {
              unit_options +="<option value='"+val.divunit_id+"' title='"+val.divunit_name+"'>"+val.divunit_abv+"</option>";
              });
          }
          else{
              unit_options +="<option value=''>Please Select Division First</option>";
          }
          $("#unit_id").html(unit_options);
        }
      });
  }

$(document).ready(function() {

  $("#doc_type_id").change(function(){
    var doc_type_id = $(this).val();
    $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {doc_type_id:doc_type_id},
      url: base_url+'General/get_sub_type',
      success: function(data){
        options = "";
        if(data){
          options +=`<option value='' selected disabled>Select Sub-Type</option>`;
          $.each(data, function(i, val) {
          options +="<option value='"+val.id+"' title='"+val.doc_t+"'>"+val.doc_t+"</option>";
          });
          $("#sub_type").html(options);
        }
      }
    })
  })    

  $("#filter").click(function(e){
    e.preventDefault();
    table.ajax.reload( null, false );
  }) 

    table = $('#viewresult').DataTable({ 
      "processing": true, //Feature control the processing indicator.
      "serverSide": true, //Feature control DataTables' server-side processing mode.
      "order": [], //Initial no order.
      "deferLoading": 0,
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
      select: true,
      "ajax": {
        "url": "<?php echo site_url('Advance_search/datatable_list')?>",
        "type": "POST",
        "data": function ( data ) {
          data.div_id = $("#div_id").val();
          data.unit_id = $("#unit_id").val();
          data.doc_type_id = $("#doc_type_id").val();
          data.sub_type = $("#sub_type").val();
          data.doc_details = $("#doc_details").val();
        },
        "dataSrc": function(json){
          return json.data;
        }
      },
      //Set column definition initialisation properties.
      "columnDefs": [
        { 
          "targets": [ 0 ], //first column / numbering column
          "orderable": false, //set not orderable
        },
      ],
    createdRow: function( row, data, dataIndex ) {
        // Set the data-status attribute, and add a class
        // if(data[5]!='' && data[5]!=null){
        //   var closing_date = new Date(data[5]);
        //   var today = new Date();
        //   var diff = new Date(closing_date - today);
        //   var days = Math.round(diff/1000/60/60/24);
        //     if(days <=0){
        //       //$(row).addClass("label-warning");
        //     }
        // }
    }
    });


    $( "#datepicker" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });
    $( "#bday" ).datepicker({
    changeYear:true,
    changeMonth: true,
    yearRange: "1980:2015",
    dateFormat: 'yy-mm-dd'
    });
});
</script>
