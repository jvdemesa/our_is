<div class="modal fade" id="modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header modal-header-success">
          <button type="button" class="close" 
             data-dismiss="modal">
                 <span aria-hidden="true">&times;</span>
                 <span class="sr-only">Close</span>
          </button>
          <h4 class="modal-title" id="myModalLabel">
              <p id="modal_title_add"></p>
          </h4>
      </div>
      <form method="POST" id="form1" class="form-horizontal" role="form" action="<?php echo base_url()."Signatory_matrix/add"; ?>">
        <input type="hidden" name="sm_id" id="sm_id">
        <!-- Modal Body -->
        <div class="modal-body">
          <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Division:</label>
            <div class="col-sm-8">
              <select name="division" onChange="getDiv(this.value,0);" class="division select2" required="required">
                <option value="" selected disabled>Division/Center*</option>
                <option value="0" >Apply to ALL</option>
                <?php 
                foreach($division as $divunit_list) 
                { 
                ?>
                <option value="<?php echo $divunit_list->divunit_id; ?>" ><?php echo $divunit_list->divunit_abv; ?></option>
                <?php 
                } 
                ?>
              </select>              
            </div>
          </div>

          <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Unit:</label>
            <div class="col-sm-8">
              <select required="required" name="unit" id="unit" class="form-control input-sm select2 unit">
                <option value="" selected disabled>Select Division First</option>
              </select>
            </div>
          </div>
          
          <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Employee Type / Designation:</label>
            <div class="col-sm-8">
            <select name="designation" id="designation" class="form-control select2" required="required" data-select2-id="4" tabindex="-1" aria-hidden="true">
              <option value="" selected disabled>Select Designation</option>
              <?php foreach($designation as $val){ ?>
                <option value="<?= $val->id ?>"><?= $val->designation ?></option>
              <?php } ?>
            </select>
            </div>
          </div>
          
         <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Automated Documents:</label>
            <div class="col-sm-8">
            <select name="ad_id" id="ad_id" class="form-control select2" required="required" onChange="get_ads();">
              <option value="" selected disabled>Select Document</option>
              <?php foreach($automated_documents as $val){ ?>
                <option value="<?= $val->id ?>"><?= $val->automated_documents ?></option>
              <?php } ?>
            </select>
            </div>
          </div>

          <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Apply To:</label>
            <div class="col-sm-8">
              <select required="required" name="is_region" id="is_region" class="form-control select2" onchange="get_ads()">
                <option value="" selected disabled="">Select Apply to</option>
                <option value="0">ERDB Main</option>
                <option value="1">Regions</option>
              </select>
            </div>
          </div>

         <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Automated Documents Signatory Label:</label>
            <div class="col-sm-8">
            <select name="ads_id" id="ads_id" class="form-control select2" required="required">
              <option value="" selected disabled>Select Automated Document First</option>
            </select>
            </div>
          </div>
          
          <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Signatory:</label>
            <div class="col-sm-8">
              <select name="signatory" id="signatory" class="form-control select2">
                <option value="" selected disabled>Select Designation</option>
                <option value="0">Not Applicable</option>
                <?php foreach($designation as $val){ ?>
                  <option value="<?= $val->id ?>"><?= $val->designation ?></option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Duration from (IF APPLICABLE):</label>
            <div class="col-sm-8">
              <input type="number" name="duration_from" id="duration_from" class="form-control">
            </div>
          </div>

          <div class="form-group" >
            <label for="rc_desc" class="col-sm-4 control-label">Duration To (IF APPLICABLE):</label>
            <div class="col-sm-8">
              <input type="number" name="duration_to" id="duration_to" class="form-control">
            </div>
          </div>

         </div><!-- end modal body -->
            <!--SUBMIT BUTTON -->
          <div class="modal-footer" align="right">
            <div class="form-group">
              <div class="col-sm-12" align="right">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                   Close
                </button>
                <button type="submit" class="btn btn-success" id="submit_add">Save</button>
              </div>
            </div>
           </div>
        </form>
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->
