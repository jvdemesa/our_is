<style>
table#document_list_table.dataTable tbody tr:hover {
  background-color: #ffffe0;
}
 
table#document_list_table.dataTable tbody tr:hover > .sorting_1 {
  background-color: #ffffe0;
}

.center {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%); /* Yep! */
  width: 48%;
  height: 59%;
}

</style>
<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        DTS Dashboard
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        </ol>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <br>   
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3 id="incoming"><?= $incoming ?></h3>
                            <p>Incoming Documents</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-arrow-circle-o-down"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="incoming_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3 id="received"><?= $received ?></h3>
                            <p>Received Documents</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="receive_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3 id="forwarded"><?= $forwarded ?></h3>
                            <p>Forwarded Documents</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-arrow-circle-o-up"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="forwarded_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3 id="for_archived"><?= $for_archived ?></h3>
                            <p>Documents for Archived</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-archive"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="for_archive_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-red">
                        <div class="inner">
                            <h3 id="exigent"><?= $exigent ?></h3>
                            <p>EXIGENT Documents</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-exclamation-circle"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="exigent_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-blue">
                        <div class="inner">
                            <h3 id="ada"><?= $ada ?></h3>
                            <p>LDDAP-ADA</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-file-pdf-o"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="ada_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-yellow">
                        <div class="inner">
                            <h3 id="uvoucher"><?= $uvoucher ?></h3>
                            <p>Unfinished Voucher</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-th-list"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="uvoucher_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>


                <div class="col-lg-3 col-6">
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h3 id="incoming_tev"><?= $incoming_tev ?></h3>
                            <p>Incoming TEV</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-file-pdf-o"></i>
                        </div>
                        <a href="#" class="small-box-footer" id="incoming_tev_list">More info 
                            <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-8 col-md-8">
                    <div class="box box-danger" id="details_box">
                        <div class="box-header  with-border">
                            <h3 class="box-title" id="document_list-title">Exigent Documents</h3>
                        </div>
                        <div class="box-body" id="document_list">
                            <table class="table table-bordered table-striped table-hover" id="document_list_table" style="cursor:pointer">
                                <thead>
                                    <tr>
                                        <td width="10%" id="first_row">Date Forwarded</td>
                                        <td width="10%">DTSNO</td>
                                        <td width="15%">Type</td>
                                        <td width="45%">Details</td>
                                        <td width="20%">Current Location</td>
                                    </tr>
                                </thead>
                                <tbody id="list">
                                    <?php foreach($exigent_list as $val){ ?>
                                    <tr>
                                        <td><?= $val->date_forwarded ?></td>
                                        <td><?= $val->dtsno ?></td>
                                        <td><?= $val->doc_t ?></td>
                                        <td><?= $val->doc_details ?></td>
                                        <td><?= $val->receiver==""?$val->from_unit:$val->to_unit; ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title">My Recent Documents</h3>
                        </div>
                        <div class="box-body" id="recent_documents">
                            <table class="table table-bordered table-striped" id="recent_docs_table">
                                <thead>
                                    <tr>
                                        <td>DTS No.</td>
                                        <td>Date Created</td>
                                        <td>Document Type</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($recent_docs as $val){ 
                                        $type = ($val->sub_type != null)?$val->doc_t." ( ".$val->sub_type." )":$val->doc_t;
                                    ?>
                                    <tr>
                                        <td><?= $val->dtsno ?></td>
                                        <td><?= $val->date_created ?></td>
                                        <td><?= $type ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
</div>
<?php  $this->load->view('dashboard/dashboard_js'); ?>
