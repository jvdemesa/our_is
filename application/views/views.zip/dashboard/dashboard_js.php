<script>
function push_notif(){
  $.ajax({
  type: "POST",
  dataType: "JSON",
  url: base_url+'Dashboard/push_notif',
  success: function(data){
  	$("#incoming").html(data.incoming);
  	$("#received").html(data.received);
  	$("#forwarded").html(data.forwarded);
  	$("#for_archived").html(data.for_archived);
  	$("#exigent").html(data.exigent);
  	$("#ada").html(data.ada);
  	}
  });
}

setInterval(function(){
	push_notif();
}, 100000);
push_notif();

$(document).ready(function() {  
    var table = $('#document_list_table').DataTable({ 
      "order": false, //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 5,
      dom: 'Blfrtip',
    });

    var recent_docs_table = $('#recent_docs_table').DataTable({ 
      "order": [1,'DESC'], //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 10,
      dom: 'Blfrtip',
    });

    $("#incoming_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/incoming_list',
        success: function(data){
          $('#first_row').html("Date Forwarded");
          $('#document_list-title').html("Incoming Documents");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-danger');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.date_forwarded, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })

    $("#receive_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/received_list',
        success: function(data){
          $('#first_row').html("Date Received");
          $('#document_list-title').html("Received Documents");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-info');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.received_time, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })


    $("#forwarded_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/forwarded_list',
        success: function(data){
          $('#first_row').html("Date Forwarded");
          $('#document_list-title').html("Forwarded Documents");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-success');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.date_forwarded, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })

    $("#for_archive_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/for_archive_list',
        success: function(data){
          $('#first_row').html("Date Received");
          $('#document_list-title').html("For Archive Documents");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-warning');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.date_forwarded, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })

    $("#exigent_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/exigent_list',
        success: function(data){
          $('#first_row').html("Date Forwarded");
          $('#document_list-title').html("Exigent Documents");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-danger');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.date_forwarded, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })    

    $("#ada_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/ada_list',
        success: function(data){
          $('#first_row').html("Date Forwarded");
          $('#document_list-title').html("LDDAP-ADA Documents");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-primary');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.date_forwarded, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })

    $("#uvoucher_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/uvoucher_list',
        success: function(data){
          $('#first_row').html("Date Forwarded");
          $('#document_list-title').html("Unfinished Vouchers");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-danger');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.date_forwarded, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })

    $("#incoming_tev_list").click(function(){
      table.clear().draw();
      $.ajax({
        type: "POST",
        dataType: "JSON",
        url: base_url+'Dashboard/incoming_tev_list',
        success: function(data){
          $('#first_row').html("Date Forwarded");
          $('#document_list-title').html("Incoming TEV");
          $('#details_box').removeAttr('class');
          $("#details_box").attr('class', 'box box-primary');
          let tbody = "", current_loc;
          $.each(data, function(key, val) {
            current_loc = val.receiver == ""?val.from_unit:val.to_unit;
            var type = val.sub_type != null?val.doc_t+" ( "+val.sub_type+" )":val.doc_t;
            table.row.add([ val.date_forwarded, 
                            val.dtsno, 
                            type, 
                            val.doc_details, 
                            current_loc, 
                          ]).draw( false );
          });
        }
      });
    })

  table.on('click', 'tbody tr', function() {
    window.location.href = `<?php echo base_url(); ?>Document/${table.row(this).data()[1]}`;
  });

  recent_docs_table.on('click', 'tbody tr', function() {
    window.location.href = `<?php echo base_url(); ?>Document/${recent_docs_table.row(this).data()[0]}`;
  });
  $("#document_list_table tr").css('cursor', 'pointer');
  $("#recent_docs_table tr").css('cursor', 'pointer');
})
</script>