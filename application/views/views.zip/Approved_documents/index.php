<style>
table#document_list_table.dataTable tbody tr:hover {
  background-color: #ffffe0;
}
 
table#document_list_table.dataTable tbody tr:hover > .sorting_1 {
  background-color: #ffffe0;
}
</style>
<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        Approved Documents
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Approved Documents</li>
        </ol>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <br>   
                <div class="col-lg-12 col-md-12">
                    <div class="box box-danger" id="details_box">
                        <div class="box-header  with-border">
                            <h3 class="box-title" id="document_list-title">List</h3>
                        </div>
                        <div class="box-body" id="document_list">
                            <table class="table table-bordered table-striped table-hover" id="document_list_table" style="cursor:pointer">
                                <thead>
                                    <tr>
                                        <td width="10%" id="first_row">Date Forwarded</td>
                                        <td width="10%">DTSNO</td>
                                        <td width="15%">Type</td>
                                        <td width="45%">Details</td>
                                        <td width="20%">Current Location</td>
                                    </tr>
                                </thead>
                                <tbody id="list">
                                    <?php foreach($list as $val){ ?>
                                    <tr>
                                        <td><?= $val->date_forwarded ?></td>
                                        <td><?= $val->dtsno ?></td>
                                        <td><?= $val->doc_t ?></td>
                                        <td><?= $val->doc_details ?></td>
                                        <td><?= $val->receiver==""?$val->from_unit:$val->to_unit; ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
</div>
<?php  $this->load->view('Approved_documents/index_js'); ?>
