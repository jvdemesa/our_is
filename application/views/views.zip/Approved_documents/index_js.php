<script>
function push_notif(){
  $.ajax({
  type: "POST",
  dataType: "JSON",
  url: base_url+'Dashboard/push_notif',
  success: function(data){
  	$("#incoming").html(data.incoming);
  	$("#received").html(data.received);
  	$("#forwarded").html(data.forwarded);
  	$("#for_archived").html(data.for_archived);
  	$("#exigent").html(data.exigent);
  	$("#ada").html(data.ada);
  	}
  });
}

setInterval(function(){
	push_notif();
}, 100000);
push_notif();

$(document).ready(function() {  
    var table = $('#document_list_table').DataTable({ 
      "order": [1,'DESC'], //Initial no order.
      responsive: true,
      "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
      "iDisplayLength": 5,
      dom: 'Blfrtip',
    });

  table.on('click', 'tbody tr', function() {
    window.open(`<?php echo base_url(); ?>Document/${table.row(this).data()[1]}`,
  '_blank');
  });

  $("#document_list_table tr").css('cursor', 'pointer');
})
</script>