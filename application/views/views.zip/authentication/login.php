<!DOCTYPE html>
<html>
<head>
  <style>
  body {
  background-image:url(<?php echo base_url('assets/images/ERDB_Building.jpg'); ?>) !important; 
  background-repeat:no-repeat !important;/*we want to have one single image not a repeated one*/  
  background-size:cover !important;
  overflow-y: hidden !important;
  }
  </style>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>ERDB - DTS | Log in</title>
  <link rel="icon" href="<?php echo base_url('assets/images/ERDB-Logo_nobg.jpg'); ?>">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/toastr/toastr.min.css">
  <script src="<?php echo base_url(); ?>assets/js/toastr/toastr.min.js"></script>

</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo" style="background-color: rgba(0, 184, 0, 0.3);text-shadow: 0 0 5px #F0FFFF;">
      <span><b>Document Management & Tracking System</b></span>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <form  method="post">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" id="username" placeholder="Username">
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" id="password" class="form-control" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
<!--       <div class="form-group has-feedback">
        <input type="text" id="captcha" class="form-control" placeholder="Captcha" required="required">
        <span class="form-control-feedback span-captcha"><img id="captcha_code" src="<?php echo base_url();?>/General/captcha_generator" /></span>
      </div>
      <div>
        <button class="btnRefresh" id="refreshCaptcha">Refresh Captcha</button>
      </div>
 -->      
        <div class="row">
        <div class="col-xs-8">
        </div>
<!--         <div class="col-xs-4">
          <button type="button" id="btnreg" class="btn btn-warning btn-block btn-flat">Register</button>
        </div>
 -->        <!-- /.col -->
        <div class="col-xs-4">
          <button type="button" id="btnlogin" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script type="text/javascript">
  var baseurl = "<?php echo base_url();?>";	
    $(document).ready(function(){
      $('#btnreg').on('click', function(){
        window.location = baseurl+'Registration';
      }); 
      $('#btnlogin').on('click', function(){
        login();		
      });
    <?php if($this->session->flashdata('success_message')) { ?>
        toastr.success("<?php echo $this->session->flashdata('success_message'); ?>");
    <?php }
          if($this->session->flashdata('warning_message')) { ?>
        toastr.warning("<?php echo $this->session->flashdata('warning_message'); ?>");
    <?php } ?>
    });	
    $(document).keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
          $('#btnlogin').addClass("disabled"); 
          login();  
        }

    });   

    function login()
    {
      var username = $('#username').val();
      var password = $('#password').val();        
      var log_type = $('#log_type').val();        
      // var captcha = $('#captcha').val();    
      var message='';    
      if(username==''){
        message +='Username Cannot be Empty.\n';
      }
      if(password==''){
        message +='Password Cannot be Empty.\n';
      }
      // if(captcha==''){
      //   message +='Captcha Cannot be Empty.';
      // }
      if(message==''){
      $(this).addClass("disabled"); 
      $.ajax({
        type: "POST",
        url: baseurl + "Authentication/login",
        data: {
          username: username,
          password: password,
          log_type: log_type,
          // captcha: captcha,
          // lat: lat,
          // long: long
        },
        success: function(e){				
          $('#btnlogin').removeClass("disabled");
          if(e.message != "Completed"){	
            alert(e.message);
          } else{
            window.location = baseurl+e.home_page;
          }
        }				
      });
    }else{
      alert(message);
    }
    }
</script>
</body>
</html>
