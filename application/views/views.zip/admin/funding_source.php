<style>
table#document_list_table.dataTable tbody tr:hover {
  background-color: #ffffe0;
}
 
table#document_list_table.dataTable tbody tr:hover > .sorting_1 {
  background-color: #ffffe0;
}
.fileUpload {
    position: relative;
    overflow: hidden;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}

</style>
<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        <i class="fa fa-money"></i> Funding Source
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        </ol>
    </section>

    <section class="content">
      <div class="row">
        <br>   
        <div class="col-lg-12 col-md-12">
          <div class="box box-default" id="details_box">
            <div class="box-header  with-border">
              <h3 class="box-title" id="document_list-title">List</h3>
              <div class="box-tools">
                  <button class="btn btn-info btn-sm" id="add">
                      <i class="fa fa-plus fa-1x"> </i> Add Funding Source
                  </button>
              </div>
            </div>
            <div class="box-body">
              <table class="table table-responsive table-bordered" id="list">
                <thead>
                  <th width="5%">ID</th>
                  <th width="30%">Funding Source</th>
                  <th width="20%">Code</th>
                  <th width="10%">ORS / BURS</th>
                  <th width="5%">Fund Cluster</th>
                  <th width="10%">MDS</th>
                  <th width="15%">NCA</th>
                  <th width="5%">Action</th>
                </thead>
                <tbody>
                  <?php foreach($list as $val){ ?>
                  <tr>
                    <td><?= $val->id; ?></td>
                    <td><?= $val->funding_source; ?></td>
                    <td><?= $val->code ?></td>
                    <td><?= $val->ors_burs ?></td>
                    <td><?= $val->fund_cluster ?></td>
                    <td><?= $val->mds ?></td>
                    <td><?= $val->nca ?></td>
                    <td>
                    <a class="edit" href="#"  title="edit" id="edit"
                        fs_id="<?= $val->id ?>"
                        funding_source="<?= $val->funding_source ?>"
                        code="<?= $val->code ?>"
                        ors_burs="<?= $val->ors_burs ?>"
                        fund_cluster="<?= $val->fund_cluster ?>"
                        mds="<?= $val->mds ?>"
                        nca="<?= $val->nca ?>"
                    >
                      <i class="fa fa-edit"></i> 
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<?php  $this->load->view('admin/jquery/funding_source'); ?>
<?php  $this->load->view('admin/modal/funding_source'); ?>
