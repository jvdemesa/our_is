
<?php
$id_name = "id";
$table = "automated_documents";
$labels = "Automated Documents";
?>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        <?= $labels; ?>

        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li><a href="#"> Admin</a></li>
        <li class="active"><?= $labels; ?></li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                    <h3 class="box-title">LIST</h3>
                        <div class="box-tools">
                            <button class="btn btn-info" id="add" >
                                <i  class="fa fa-plus fa-1x"> </i> Add
                            </button>
                        </div>
                    </div>
                <div class="box-body table-responsive">
                    <div class="modal fade" id="modal" role="dialog" 
                         aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <button type="button" class="close" 
                                       data-dismiss="modal">
                                           <span aria-hidden="true">&times;</span>
                                           <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title" id="myModalLabel">
                                        <p id="modal_title"></p>
                                    </h4>
                                </div>
                                
                                <!-- Modal Body -->
                                <div class="modal-body">
                                    
                                  <form method="POST" id="form1" class="form-horizontal" role="form">
                                    <input type="hidden" name="id" id="id">
                                    <input type="hidden" name="table" id="table" value="<?= $table; ?>">
                                    <input type="hidden" name="id_name" id="id_name" value="<?= $id_name; ?>">
                                     <table class="table table-bordered table-hover">
                                      <tr>
                                        <td>
                                          Status
                                        </td>
                                        <td>
                                          <select name="status" class="form-control select2" id="status" style="width: 100%">
                                            <option value="0">ENABLED</option>
                                            <option value="1">DISABLED</option>
                                          </select>
                                        </td>
                                      </tr>
                                       <tr>
                                            <td><?= $labels; ?></td>
                                            <td><input type="text" name="dbval" id="dbval" class="form-control uppercase" required="required"/></td>
                                        </tr>
                                      <tr>
                                            <td>PDF Generator Link address</td>
                                            <td><input type="text" name="pdf_link" id="pdf_link" class="form-control" required="required"/></td>
                                        </tr>
                                    </table>
                                      <!--SUBMIT BUTTON -->
                                    <div class="modal-footer" align="right">
                                      <div class="form-group">
                                        <div class="col-sm-12" align="right">
                                          <button type="button" class="btn btn-default" data-dismiss="modal">
                                             Close
                                          </button>
                                          <button type="submit" class="btn btn-success btnSubmit" id="submit_add">SAVE</button>
                                        </div>
                                      </div>
                                     </div>
                                    </form>
                                </div><!--end Modal body-->
                            </div><!--end Modal content-->
                        </div><!--end Modal dialog-->
                    </div><!--end modal receive-->
                <hr />
                <?php echo $this->session->flashdata('message'); ?>
                   <table class="table table-striped table-bordered table-hover" id="viewresult">
                        <thead>
                            <tr >
                              <th width="20%"><?= $labels; ?> ID</th>
                              <th width="30%"><?= $labels; ?></th>
                              <th width="10%">PDF link</th>
                              <th width="10%">Status</th>
                              <th width="20%">action</th>
                            </tr>
                        </thead>
                        <?php 
                        if($list != false){
                            foreach($list as $value){ 
                        ?>
                        <tr>
                            <td><?php echo $value->{$id_name}; ?></td>
                            <td><?php echo $value->{$table}; ?></td>
                            <td><?php echo $value->pdf_link; ?></td>
                            <td><?php echo ($value->status=='0')?'ENABLED':'DISABLED'; ?></td>
                            <td>            
                              <a class="edit_modal" href="#"  title="edit"
                              id="<?php echo $value->{$id_name}; ?>" 
                              dbval="<?php echo $value->{$table}; ?>" 
                              pdf_link="<?php echo $value->pdf_link; ?>" 
                              status="<?php echo $value->status; ?>" 
                              >
                                   <i class="fa fa-edit"></i> 
                               </a> |
                              <a class="delete_modal" href="#" title="delete" 
                              id="<?php echo $value->{$id_name}; ?>" 
                              dbval="<?php echo $value->{$table}; ?>"
                              pdf_link="<?php echo $value->pdf_link; ?>" 
                              status="<?php echo $value->status; ?>" 
                              >
                                   <i class="fa fa-remove"></i> 
                               </a>  |
                              <a class="add_doc_type" href="javascript:void(0)" 
                              title="Add signatory" 
                              ad_id="<?php echo $value->{$id_name}; ?>" 
                              document_name="<?php echo $value->{$table}; ?>">
                                <i class="fa fa-list-alt fa-lg"></i>
                              </a>                            </td>
                        </tr>
                        <?php 
                            }
                        }
                        ?>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php  $this->load->view('admin/modal/ad_modal'); ?>
<?php  $this->load->view('admin/jquery/ad_js'); ?>
