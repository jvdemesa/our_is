<style>
table#document_list_table.dataTable tbody tr:hover {
  background-color: #ffffe0;
}
 
table#document_list_table.dataTable tbody tr:hover > .sorting_1 {
  background-color: #ffffe0;
}
.fileUpload {
    position: relative;
    overflow: hidden;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}

</style>
<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        <i class="fa fa-user-circle"></i> Signatories
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        </ol>
    </section>

    <section class="content">
      <div class="row">
        <br>   
        <div class="col-lg-12 col-md-12">
          <div class="box box-default" id="details_box">
            <div class="box-header  with-border">
              <h3 class="box-title" id="document_list-title">List</h3>
              <div class="box-tools">
                  <button class="btn btn-info btn-sm" id="add_signatory">
                      <i class="fa fa-plus fa-1x"> </i> Add Signatory
                  </button>
              </div>
            </div>
            <div class="box-body">
              <table class="table table-responsive table-bordered" id="list">
                <thead>
                  <th width="15%">Signatory</th>
                  <th width="10%">Designation</th>
                  <th width="15%">Division</th>
                  <th width="15%">Unit</th>
                  <th width="10%">Signatory Status</th>
                  <th width="10%">highest_salutation</th>
                  <th width="10%">Initial</th>
                  <th width="10%">Active status</th>
                  <th width="5%">Action</th>
                </thead>
                <tbody>
                  <?php foreach($list as $val){ 

                    ?>
                  <tr class="<?= $val->is_active == 0?"danger":""; ?>">
                    <td><?= $val->fullname; ?></td>
                    <td><?= $val->designation; ?></td>
                    <td><?= $val->div_abv." - ".$val->div_name; ?></td>
                    <td><?= $val->unit_name; ?></td>
                    <td><?= $val->signatory_status; ?></td>
                    <td><?= $val->highest_salutation; ?></td>
                    <td><center>
                      <?php if($val->initial!=""){ ?>
                      <i class="fa fa-check"></i>
                      <?php } ?>
                      </center>
                    </td>
                    <td><?= $val->is_active==1?'Active':'In-Active'; ?></td>
                    <td>
                    <a class="edit" href="#"  title="edit" id="edit"
                        signatory_id="<?= $val->id ?>"
                        designation="<?= $val->designation_id ?>"
                        signatory="<?= $val->uid ?>"
                        division="<?= $val->division ?>"
                        unit="<?= $val->unit ?>"
                        signatory_status="<?= $val->signatory_status ?>"
                        highest_salutation="<?= $val->highest_salutation ?>"
                        is_active="<?= $val->is_active ?>"
                    >
                      <button class="btn btn-info btn-xs"><i class="fa fa-edit"></i></button> | 
                      <a href="#!" class="delete"  uname="<?= $val->fullname; ?>" designation="<?= $val->designation; ?>" signatory_id="<?= $val->id ?>"><button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button></a>
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<?php  $this->load->view('admin/jquery/signatories'); ?>
<?php  $this->load->view('admin/modal/signatories'); ?>
