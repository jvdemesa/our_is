<style>
table#document_list_table.dataTable tbody tr:hover {
  background-color: #ffffe0;
}
 
table#document_list_table.dataTable tbody tr:hover > .sorting_1 {
  background-color: #ffffe0;
}
.fileUpload {
    position: relative;
    overflow: hidden;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}

</style>
<div class="content-wrapper" style="min-height: 414px;">

    <section class="content-header">
        <h1 class="page-header">
        <i class="fa fa-building"></i> Division / Unit
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li class="active">Dashboard</li>
        </ol>
    </section>

    <section class="content">
      <div class="row">
        <br>   
        <div class="col-lg-12 col-md-12">
          <div class="box box-default" id="details_box">
            <div class="box-header  with-border">
              <h3 class="box-title" id="document_list-title">List</h3>
              <div class="box-tools">
                  <button class="btn btn-info btn-sm" id="add">
                      <i class="fa fa-plus fa-1x"> </i> Add Divunit
                  </button>
              </div>
            </div>
            <div class="box-body">
              <table class="table table-responsive table-bordered" id="list">
                <thead>
                  <th width="5%">ID</th>
                  <th width="10%">Abbreviation</th>
                  <th width="40%">Description</th>
                  <th width="25%">Parent</th>
                  <th width="5%">Is OC</th>
                  <th width="5%">Is Region</th>
                  <th width="5%">Status</th>
                  <th width="5%">Action</th>
                </thead>
                <tbody>
                  <?php foreach($list as $val){ ?>
                  <tr>
                    <td><?= $val->divunit_id; ?></td>
                    <td><?= $val->divunit_abv; ?></td>
                    <td><?= $val->divunit_name ?></td>
                    <td><?= $val->parent_name!=""?$val->divunit_abv.' - '.$val->parent_name:""; ?></td>
                    <td><?= $val->is_oc; ?></td>
                    <td><?= $val->is_region; ?></td>
                    <td><?= $val->status==0?'Active':'In-Active'; ?></td>
                    <td>
                    <a class="edit" href="#"  title="edit" id="edit"
                        divunit_id="<?= $val->divunit_id ?>"
                        divunit_abv="<?= $val->divunit_abv ?>"
                        divunit_name="<?= $val->divunit_name ?>"
                        is_oc="<?= $val->is_oc ?>"
                        is_region="<?= $val->is_region ?>"
                        status="<?= $val->status ?>"
                        unit_parent="<?= $val->unit_parent ?>"
                    >
                      <i class="fa fa-edit"></i> 
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<?php  $this->load->view('admin/jquery/divunit'); ?>
<?php  $this->load->view('admin/modal/divunit'); ?>
