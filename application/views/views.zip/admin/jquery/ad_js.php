<script>
$(document).ready(function() {

	var table =  $('#doc_type_table').DataTable({
    responsive: true,
    "aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
    "iDisplayLength": 10,
     "ordering": false,
     'sorting': false,
      "aaSorting": []
    });

	$("#doc_type_id").select2({
	  ajax: { 
	   url: "<?php echo base_url(); ?>Admin/get_required_doc_type",
	   type: "post",
	   dataType: 'json',
	   delay: 250,
	   data: function (params) {
	    return {
	      search: params.term, // search term
	      ad_id: $('#ad_id').val()
	    };
	   },
	processResults: function (data) {
	            return {
	                results: $.map(data, function (item) {
	                    return {
	                        text: item.doc_t,
	                        id: item.id
	                    }
	                })
	            };
	        }
	    }
	});
  $("#add").click(function(){
      $('#form1')[0].reset();
      $("#id").val('');
      //set selected value for select2
      $('#status').val('0');
      //trigger change for select2
      $('#status').select2().trigger('status');
      document.getElementById('form1').action =  '<?php echo base_url(); ?>admin/add_ad';
      $("#modal_title").text('Add Automated Document');
      $("#modal").modal("show");
  })

  $("#submit_add").click(function (e) {
    $('input[type=text]').val (function () {
      return this.value.toUpperCase();
    })
    $('input[type=text], textarea').val (function () {
      return this.value.toUpperCase();
    })   
    $("#form1").submit();
  });

    $('#viewresult').on('click','.add_doc_type', function(){
      var ad_id = this.getAttribute("ad_id");
      var document_name = this.getAttribute("document_name");
      $('#modal_title_required_docs').html('Add Required to '+document_name);
      $('#ad_id').val(ad_id);
      view_doc_type(ad_id);
      $('#doc_type_modal').modal('show');
    })

$('#add_required_doc_type').click(function(e){
  e.preventDefault();
  var doc_type_id = $('#doc_type_id').val();
  var ad_id = $('#ad_id').val();
  if(doc_type_id!=null){
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Admin/add_required_doc_type",
      dataType: "JSON",
      data:{doc_type_id:doc_type_id,ad_id:ad_id },
      success: function(data){
        view_doc_type(data);
        $('#alert-exempted').show().html('Required Document to has been added.').fadeOut().fadeIn().fadeOut().fadeOut().fadeIn().fadeOut();
        $('#doc_type_id').val('').change();
      }
    });
  }else{
    alert('Please select link');
  }
});

  $('#doc_type_table').on('click','.delete_doc_type', function(){
    var doc_name = this.getAttribute("doc_name");
    if (confirm(`Are you sure you want to remove ${doc_name} from the list?`)) {
    var doc_type_id = this.getAttribute("doc_type_id");
    var ad_id = $('#ad_id').val();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>Admin/delete_required_doc",
        dataType: "JSON",
        data:{ad_id:ad_id,doc_type_id:doc_type_id},
        success: function(data){
          view_doc_type(ad_id);
          $('#alert-exempted').show().html('Document type has been removed!').fadeOut().fadeIn().fadeOut().fadeOut().fadeIn().fadeOut();
        }
      });
    }
  })


function view_doc_type(ad_id){
  $.ajax({
  type: "POST",
  url: "<?php echo base_url(); ?>Admin/required_ad_to_list",
  dataType: "JSON",
  data:{ad_id:ad_id },
  success: function(data){ 
  table.clear().draw();
  $.each(data, function(key, val){
      var rowNode = table.row.add([`${val.doc_t}`, 
                    `<a class="delete_doc_type" 
                      href="#" 
                      title="Remove Doc Type"
                      doc_name="${val.doc_t}"
                      doc_type_id="${val.doc_type_id}">
                      <i class="fa fa-trash"></i> 
                    </a>`
                    ]).draw().node();
        })
      }
    });
}

})
</script>