<script>

$(document).ready(function() {
	$('#list').DataTable({
		responsive: true,
		"aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
		"iDisplayLength": 10
	});

  $("#add").click(function(){
    $("#rc_id").val("");
    $("#description").val("");
    $("#code").val("");
    $("#is_disabled").val("0").change();    
    $('#modal_add').modal('show');
  })

  $('#list').on("click",".edit",function(){
    $("#rc_id").val(this.getAttribute('rc_id'));
    $("#description").val(this.getAttribute('description'));
    $("#code").val(this.getAttribute('code'));
    $("#is_disabled").val(this.getAttribute('is_disabled')).change();   
    $("#modal_add").modal("show");
  })

  $("#btnSubmit").click(function (e) {
    if($("#form_add")[0].checkValidity()!=false){
      e.preventDefault();
    var form_data = new FormData($('#form_add')[0]);
      $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Admin/add_rc",
          dataType: "JSON",
          data:form_data,
          contentType: false, 
          processData: false, 
          success: function(data){
            if(data){
              window.location.replace("<?php echo base_url(); ?>Admin/rc");
            }else{
              //toastr.warning("Initial is required!");
            }
          }
      });
    }
  });
});
</script>