<script>

$(document).ready(function() {
	$('#list').DataTable({
		responsive: true,
		"aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
		"iDisplayLength": 10
	});

  $("#add").click(function(){
    $("#divunit_id").val("");
    $("#divunit_abv").val("");
    $("#divunit_name").val("");
    $("#unit_parent").val("0").change();
    $("#is_oc").val("0").change();
    $("#is_region").val("0").change();
    $("#status").val("0").change();    
    $('#modal_add').modal('show');
  })

  $('#list').on("click",".edit",function(){
    $("#divunit_id").val(this.getAttribute('divunit_id'));
    $("#divunit_abv").val(this.getAttribute('divunit_abv'));
    $("#divunit_name").val(this.getAttribute('divunit_name'));
    $("#unit_parent").val(this.getAttribute('unit_parent')).change();
    $("#is_oc").val(this.getAttribute('is_oc')).change();
    $("#is_region").val(this.getAttribute('is_region')).change();
    $("#status").val(this.getAttribute('status')).change();    
    $("#modal_add").modal("show");
  })

  $("#btnSubmit").click(function (e) {
    if($("#form_add")[0].checkValidity()!=false){
      e.preventDefault();
    var form_data = new FormData($('#form_add')[0]);
      $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Admin/add_divunit",
          dataType: "JSON",
          data:form_data,
          contentType: false, 
          processData: false, 
          success: function(data){
            if(data){
              window.location.replace("<?php echo base_url(); ?>Admin/divunit");
            }else{
              //toastr.warning("Initial is required!");
            }
          }
      });
    }
  });
});
</script>