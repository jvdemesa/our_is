<script>

$(document).ready(function() {
	$('#list').DataTable({
		responsive: true,
		"aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
		"iDisplayLength": 10
	});

  $("#add").click(function(){
    $("#fs_id").val("");
    $("#funding_source").val("");
    $("#code").val("");
    $("#ors_burs").val("").change();
    $("#fund_cluster").val("").change();
    $("#mds").val("");
    $("#nca").val("");
    $('#modal_add').modal('show');
  })

  $('#list').on("click",".edit",function(){
    $("#fs_id").val(this.getAttribute("fs_id"));
    $("#funding_source").val(this.getAttribute("funding_source"));
    $("#code").val(this.getAttribute("code"));
    $("#ors_burs").val(this.getAttribute("ors_burs")).change();
    $("#fund_cluster").val(this.getAttribute("fund_cluster")).change();
    $("#mds").val(this.getAttribute("mds"));
    $("#nca").val(this.getAttribute("nca"));
    $("#modal_add").modal("show");
  })

  $("#btnSubmit").click(function (e) {
    if($("#form_add")[0].checkValidity()!=false){
      e.preventDefault();
    var form_data = new FormData($('#form_add')[0]);
      $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Admin/add_funding_source",
          dataType: "JSON",
          data:form_data,
          contentType: false, 
          processData: false, 
          success: function(data){
            if(data){
              window.location.replace("<?php echo base_url(); ?>Admin/funding_source");
            }else{
              //toastr.warning("Initial is required!");
            }
          }
      });
    }
  });
});
</script>