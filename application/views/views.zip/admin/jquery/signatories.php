<script>
var unit_id = ""; 
function getDiv(div_id) {
  $("#divid").prop("disabled",true);
    var unit_options = "";
    $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>General/unit_list",
    dataType: "JSON",
    data:{divunit_id:div_id},
    success: function(data){
      var selected="";
        if(data != false){
            $.each(data, function(i, val) {
            unit_options +=`<option value='${val.divunit_id}' title='${val.divunit_name}' ${selected}>${val.divunit_abv} - ${val.divunit_name}</option>`;
            });
        }
        else{
          unit_options +=`<option value=''>Please Select Division First</option>`;
          }
          $("#unitid").html(unit_options);
          $("#divid").prop("disabled",false);
          if(unit_id != ""){
            $("#unitid").val(unit_id).change();   
          }
      }
    });
}

$(document).ready(function() {
  $("#division").change(function(){
    getDiv($(this).val());
  })

	$('#list').DataTable({
		responsive: true,
		"aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
		"iDisplayLength": 10
	});

  $("#add_signatory").click(function(){
    $("#signatory_id").val("");
    $("#is_active").attr("required", true);
    $('#modal_add').modal('show');
  })

  $('#list').on("click",".edit",function(){
    var highest_salutation = this.getAttribute('highest_salutation').split(',');
    $("#signatory_id").val(this.getAttribute('signatory_id'));
    $("#signatory").val(this.getAttribute('signatory')).change();
    $("#designation").val(this.getAttribute('designation')).change();
    unit_id = this.getAttribute('unit');
    $("#division").val(this.getAttribute('division')).change();
    $("#status").val(this.getAttribute('signatory_status')).change();
    $("#highest_salutation").val(highest_salutation).change();
    $("#is_active").val(this.getAttribute('is_active')).change();
    $("#is_active").attr("required", false);
    $('#modal_add').modal('show');
  })

  $("#btnSubmit").click(function (e) {
    if($("#form_add")[0].checkValidity()!=false){
      e.preventDefault();
    var form_data = new FormData($('#form_add')[0]);
      $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Admin/add_signatories",
          dataType: "JSON",
          data:form_data,
          contentType: false, 
          processData: false, 
          success: function(data){
            if(data){
              window.location.replace("<?php echo base_url(); ?>Admin/signatories");
            }else{
              toastr.warning("Initial is required!");
            }
          }
      });
    }
  });

  $("#list").on("click",'.delete',function(){
    var uname = this.getAttribute("uname");
    var designation = this.getAttribute("designation");
    var signatory_id = this.getAttribute("signatory_id");
    if ( confirm('Are you sure you want delete ' + uname + ' as '+designation+'?') ) {
      $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>admin/delete_json",
        dataType: "JSON",
        data:{id:signatory_id,table:"signatories",id_name:"id",dbval:uname},
        success: function(data){
          location.reload();
        }
      });
    }
  })

});

$(document).on('change','.up', function(){
  myfile= $( this ).val();
  var ext = myfile.split('.').pop();
  if(ext=="png" || ext=="jpg" || ext=="jpeg" || ext=="gif" ){
    var names = [];
    var length = $(this).get(0).files.length;
    var file = event.target.files[0];
    if(file.size<=50*1024*1024) {
      for (var i = 0; i < $(this).get(0).files.length; ++i) {
        names.push($(this).get(0).files[i].name);
      }
        // $("input[name=file]").val(names);
      if(length>2){
        var fileName = names.join(', ');
        $(this).closest('.form-group').find('.form-control').attr("value",length+" files selected");
      }
      else{
        $(this).closest('.form-group').find('.form-control').attr("value",names);
      }
    }else{
      $( this ).val('');
      $(this).closest('.form-group').find('.form-control').attr("value",'');
      alert('Max file size is 50mb!')
    }
  }else{
    $(this).closest('.form-group').find('.form-control').attr("value",'');
    $( this ).val('');
    alert(ext + ' Not Allowed!')
  }
});
</script>