<style>
.select2-selection--single {
  height: 100% !important;
}
.select2-selection__rendered{
  word-wrap: break-word !important;
  text-overflow: inherit !important;
  white-space: normal !important;
}
</style>
<div class="modal fade" id="modal_add" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="close" 
           data-dismiss="modal">
               <span aria-hidden="true">&times;</span>
               <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">
            <p>ADD SIGNATORIES</p>
        </h4>
      </div>
          <!-- Modal Body -->
      <form id="form_add">
        <input type="hidden" name="signatory_id" id="signatory_id">
      <div class="modal-body"> 
      <table class="table table-striped">
        <tr>
          <td>Signatory:</td>
          <td>
            <select class="select2 form-control" name="signatory" id="signatory">
              <option selected disabled>Select Signatory</option>
              <?php foreach($users_list as $val){ ?>
                <option value="<?= $val->uid ?>"><?= $val->lname.", ".$val->fname." ".$val->mname ?></option>
              <?php } ?>
            </select>
          </td>
        </tr>
        <tr>
          <td>Designation:</td>
          <td>
            <select name="designation" id="designation" class="form-control select2" required="required" data-select2-id="4" tabindex="-1" aria-hidden="true">
              <option value="" selected disabled>Select Designation</option>
              <?php foreach($designation as $val){ ?>
                <option value="<?= $val->id ?>"><?= $val->designation ?></option>
              <?php } ?>
            </select>
          </td>
        </tr>
        <tr>
          <td>Division:</td>
          <td>
            <select class="select2 form-control" name="division" id="division">
              <option selected disabled>Select Division</option>
              <?php foreach($division_list as $val){ ?>
                <option value="<?= $val->divunit_id ?>"><?= $val->divunit_abv." - ".$val->divunit_name ?></option>
              <?php } ?>
            </select>
          </td>
        </tr>
        <tr>
          <td>Unit:</td>
          <td>
            <select class="select2 form-control" name="unit" id="unitid">
              <option selected disabled>Select Divison First</option>
            </select>
          </td>
        </tr>
        <tr>
          <td>Status:</td>
          <td>
            <select name="status" id="status" class="form-control select2" required="required">
              <option value="OIC"> OIC </option>
              <option value="ACTING"> ACTING </option>                 
              <option value="PERMANENT"> PERMANENT </option>                 
              <option value="IN-CHARGE"> IN-CHARGE </option>                 
            </select>
          </td>
        </tr>
        <tr>
          <td>Highest Salutation:</td>
          <td>
            <select name="highest_salutation" id="highest_salutation" class="form-control select2">
              <option value="" >None</option>
              <option value="Ph.D." >Doctorate, PhD</option>
              <option value="CESO I" >CESO I</option>
              <option value="CESO II" >CESO II</option>
              <option value="CESO III" >CESO III</option>
              <option value="CESO IV" >CESO IV</option>
              <option value="LL.D." >Doctor of Laws, LL.D.</option>
            </select>
          </td>
        </tr>
        <tr>
          <td>Active Status:</td>
          <td>
            <select name="is_active" id="is_active" class="form-control select2">
              <option value="1" >Enabled</option>
              <option value="0" >Disabled</option>
            </select>
          </td>
        </tr>
<!--         <tr>
          <td>Initial:</td>
          <td>
            <div class="box-body" id="file">
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Attach File</label>    
                    <div class="input-group col-sm-10">
                        <div class="form-group">
                        <div class="input-group">
                          <input type="text" class="form-control" readonly>
                        <div class="input-group-btn">
                          <span class="fileUpload btn btn-success">
                              <span class="upl" id="upload">Upload file</span>
                              <input type="file" class="upload up" id="up" name="initial" accept="image/png, image/gif, image/jpeg" />
                            </span>
                         </div>
                         </div>
                         </div>
                    </div>
                </div>
            </div>
          </td>
        </tr>
 -->      </table>          
          <!--SUBMIT BUTTON -->
        <div class="modal-footer" align="right">
          <div class="form-group">
            <div class="col-sm-12" align="right">
              <button type="button" class="btn btn-default" data-dismiss="modal">
                 Close
              </button>
              <button type="submit" class="btn btn-success btnSubmit" id="btnSubmit">SAVE</button>
            </div>
          </div>
        </div>
      </div><!--end Modal body-->
      </form>
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->