<div class="modal fade" id="modal_add" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header  bg bg-green">
        <button type="button" class="close" 
           data-dismiss="modal">
               <span aria-hidden="true">&times;</span>
               <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">
            <p>Add Division / Unit</p>
        </h4>
      </div>
          <!-- Modal Body -->
      <form id="form_add">
        <input type="hidden" name="divunit_id" id="divunit_id">
      <div class="modal-body"> 
        <label>Abbreviation:</label>
          <input type="text" class="form-control" name="divunit_abv" id="divunit_abv">
        <label>Description:</label>
          <input type="text" class="form-control" name="divunit_name" id="divunit_name">
        <label>Parent:</label>
          <select class="select2 form-control" name="unit_parent" id="unit_parent">
            <option value="0">No Parent (Division)</option>
            <?php foreach($division_list as $val){ ?>
              <option value="<?= $val->divunit_id ?>"><?= $val->divunit_abv." - ".$val->divunit_name ?></option>
            <?php } ?>
          </select>
        <label>Is Oc?:</label>
          <select class="select2 form-control" name="is_oc" id="is_oc">
            <option value="0">No</option>
            <option value="1">Yes</option>
          </select>
        <label>Is Regions?:</label>
          <select class="select2 form-control" name="is_region" id="is_region">
            <option value="0">No</option>
            <option value="1">Yes</option>
          </select>
        <label>Status:</label>
          <select class="select2 form-control" name="status" id="status" style="width:'100%'">
            <option value="0">Active</option>
            <option value="1">In-Active</option>
          </select>
          <!--SUBMIT BUTTON -->
        <div class="modal-footer" align="right">
          <div class="form-group">
            <div class="col-sm-12" align="right">
              <button type="button" class="btn btn-default" data-dismiss="modal">
                 Close
              </button>
              <button type="submit" class="btn btn-success btnSubmit" id="btnSubmit">SAVE</button>
            </div>
          </div>
        </div>
      </div><!--end Modal body-->
      </form>
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->