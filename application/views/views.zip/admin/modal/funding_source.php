<div class="modal fade" id="modal_add" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header  bg bg-green">
        <button type="button" class="close" 
           data-dismiss="modal">
               <span aria-hidden="true">&times;</span>
               <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">
            <p>Add Funding Source</p>
        </h4>
      </div>
          <!-- Modal Body -->
      <form id="form_add">
        <input type="hidden" name="fs_id" id="fs_id">
      <div class="modal-body"> 
        <label>Funding Source:</label>
          <input type="text" class="form-control" name="funding_source" id="funding_source" required="required">
        <label>Code:</label>
          <input type="text" class="form-control" name="code" id="code" required="required">
        <label>ORS / BURS:</label>
        <select name="ors_burs" id="ors_burs" class="form-control" required="required">
          <option selected disabled value="">Select ORS or BURS</option>
          <option value="ORS">ORS</option>
          <option value="BURS">BURS</option>
        </select>
        <label>Fund Cluster:</label>
        <select name="fund_cluster" id="fund_cluster" class="form-control" required="required">
          <option selected disabled value="">Select Fund Cluster</option>
          <option value="01">01</option>
          <option value="02">02</option>
          <option value="07">07</option>
        </select>
        <label>MDS:</label>
          <input type="text" class="form-control" name="mds" id="mds" required="required">
        <label>NCA:</label>
          <input type="text" class="form-control" name="nca" id="nca" required="required">
          <!--SUBMIT BUTTON -->
        <div class="modal-footer" align="right">
          <div class="form-group">
            <div class="col-sm-12" align="right">
              <button type="button" class="btn btn-default" data-dismiss="modal">
                 Close
              </button>
              <button type="submit" class="btn btn-success btnSubmit" id="btnSubmit">SAVE</button>
            </div>
          </div>
        </div>
      </div><!--end Modal body-->
      </form>
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->