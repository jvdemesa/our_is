<div class="modal fade" id="modal_add" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header  bg bg-green">
        <button type="button" class="close" 
           data-dismiss="modal">
               <span aria-hidden="true">&times;</span>
               <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">
            <p>Add Responsibility Center</p>
        </h4>
      </div>
          <!-- Modal Body -->
      <form id="form_add">
        <input type="hidden" name="rc_id" id="rc_id">
      <div class="modal-body"> 
        <label>Responsibility Center:</label>
          <input type="text" class="form-control" name="description" id="description">
        <label>RC Code:</label>
          <input type="text" class="form-control" name="code" id="code">
        <label>Status:</label>
          <select class="select2 form-control" name="is_disabled" id="is_disabled" style="width:'100%'">
            <option value="0">Active</option>
            <option value="1">In-Active</option>
          </select>
          <!--SUBMIT BUTTON -->
        <div class="modal-footer" align="right">
          <div class="form-group">
            <div class="col-sm-12" align="right">
              <button type="button" class="btn btn-default" data-dismiss="modal">
                 Close
              </button>
              <button type="submit" class="btn btn-success btnSubmit" id="btnSubmit">SAVE</button>
            </div>
          </div>
        </div>
      </div><!--end Modal body-->
      </form>
    </div><!--end Modal content-->
  </div><!--end Modal dialog-->
</div><!--end modal receive-->