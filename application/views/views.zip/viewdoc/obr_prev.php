      <?php
      if($first_track->type == "51"){ ?>
      <div class="col-md-12">
        <div class="box box-default">
          <div class="box-header with-border">
            <h3 class="box-title">OBR Details</h3>
            <a href="#" id="add_obr" dtsno="<?= $dtsno ?>"  class="add_obr">
                <span class="label label-primary pull-right" style="font-size:100% !important">
                    ADD <i class="fa fa-plus"></i>
                </span>
            </a>
          </div>
            <table class="table table-bordered" id="obr_table">
              <thead>
                <th>RC Code</th>
                <th>RC Description</th>
                <th>MFO/PAP</th>
                <th>UACS Code</th>
                <th>UACS Description</th>
                <th>Amount</th>
                <th width="80px">Action</th>
              </thead>
              <tbody id="obr_tbody">
                <?php 
                foreach($obr_data as $val){
                ?>
                <tr>
                  <td><?= $val->rc_code ?></td>
                  <td><?= $val->rc_desc ?></td>
                  <td><?= $val->mfo ?></td>
                  <td><?= $val->uacs_code ?></td>
                  <td><?= $val->uacs_desc ?></td>
                  <td><?= $val->amount ?></td>
                  <td>
                    <a href="#!" class="delete_obr" 
                    obr_id="<?= $val->id ?>"
                    rc_code="<?= $val->rc_code ?>"
                    rc_desc="<?= $val->rc_desc ?>"
                    mfo="<?= $val->mfo ?>"
                    uacs_code="<?= $val->uacs_code ?>"
                    uacs_desc="<?= $val->uacs_desc ?>"
                    amount="<?= $val->amount ?>"
                    >
                      <span class="label label-danger pull-right" style="font-size:100% !important">
                      <i class="fa fa-trash"></i></span>
                    </a> 

                    <a href="#!" class="edit_obr" 
                    obr_id="<?= $val->id ?>"
                    rc_code="<?= $val->rc_code ?>"
                    rc_desc="<?= $val->rc_desc ?>"
                    mfo="<?= $val->mfo ?>"
                    uacs_code="<?= $val->uacs_code ?>"
                    uacs_desc="<?= $val->uacs_desc ?>"
                    amount="<?= $val->amount ?>"
                    >
                      <span class="label label-warning pull-right" style="font-size:100% !important">
                      <i class="fa fa-edit"></i></span>
                    </a> 
                  </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          <div class="box-body">
          </div>
        </div>
      </div>        
      <?php
      }
      ?>