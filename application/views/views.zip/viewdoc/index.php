<style>
/* Center the loader */
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 }
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom {
  from{ bottom:-100px; opacity:0 }
  to{ bottom:0; opacity:1 }
}

.btn-header{
  padding: 0px;
}
.select2-container {
    width: 100% !important;
}
.active{
  color:#337ab7;
}
.nm{
  margin-top: 0px !important;
  margin-bottom: 0px !important;
  border-top: 1px solid #000;
}
@media (min-width: 768px) {
  .modal-xl {
    width: 90%;
   max-width:1200px;
  }
}
.disable_edit{
   pointer-events: none;
}
.disable_receive{
   pointer-events: none;
}
.tr_red{
  background-color: #D70000 !important;
}
.tr_deleted{
  background-color: #eb7434 !important;
  color: white;
}
.border_btm{
  border-bottom: 1px solid black !important;
}
.select[readonly].select2-hidden-accessible + .select2-container {
        pointer-events: none;
        touch-action: none;
}

.select[readonly].select2-hidden-accessible + .select2-container .select2-selection {
    background: #eee;
    box-shadow: none;
}

.select[readonly].select2-hidden-accessible + .select2-container .select2-selection__arrow, select[readonly].select2-hidden-accessible + .select2-container .select2-selection__clear {
    display: none;
}

.select2-selection--single {
  height: 100% !important;
}
.select2-selection__rendered{
  word-wrap: break-word !important;
  text-overflow: inherit !important;
  white-space: normal !important;
}

</style>
<?php
$originator_unit = $first_track->unit;
$originator_div = $first_track->division;

$disable_edit = '';
//loop for copy no
for($i=0; $i<$tracks_count;$i++){ 
$from_unit_id = $tracks[$i][0]->from_unit_id;
$to_unit_id = $tracks[$i][0]->to_unit_id;
$receiver = $tracks[$i][0]->receiver;
  if($receiver != ""){
    if($to_unit_id !=  $userdata->unit_id){
      $disable_edit = 'disabled hideme';
    }
  }else{
    if($from_unit_id != $userdata->unit_id){
      $disable_edit = 'disabled hideme';
    }
  }
  //if already signed by aa or dir disabled edit
if(($is_signed_aa == 1 || $is_signed_dir == 1 || $first_track->is_approved == 1) && $userdata->designation != "5"){ 
  $disable_edit = 'disabled hideme';
}
  //disable receive button if receiver field is not empty and to_unit = your unit
  $receiveBtn_disabled = ($tracks[$i][0]->receiver == "" && $tracks[$i][0]->to_unit_id == $userdata->unit)?"":"disabled";
  //disable forward / makecopy / archive button if receiver field is empty, to_unit = your unit and action_done is empty
  $fmaBtn_disabled = ($tracks[$i][0]->receiver != "" && $tracks[$i][0]->to_unit_id == $userdata->unit && $tracks[$i][0]->action_done == "")?"":"disabled";
  //if TO is canceled hide all buttons
  if($first_track->status == 1){
    $fmaBtn_disabled = "hidden disabled";
     $receiveBtn_disabled = "hidden disabled";
  }

  if($cs_detail!=null){
  $fmaBtn_disable2 = ((($cs_detail->is_for_signature == '0') || ($cs_detail->is_for_signature == '1' && $cs_detail->is_signed == '1') ))?"":"disabled";
  $sign_button = ($cs_detail->is_for_signature == '1' && $cs_detail->is_signed == '0' && $cs_detail->uid == $userdata->uid)?"":"hidden disabled";
    $cancel_hide = "";
  }else{
    $fmaBtn_disable2 = "";
    $cancel_hide = "hidden";
    $sign_button = "hidden disabled";
  }

  if($cs_detail2!=null){
  $cancel_hide = ($cs_detail2->is_for_signature == '1' && $cs_detail2->is_signed == '0' && ($to_unit_id ==  $userdata->unit_id || $cs_detail2->uid == $userdata->uid))?"":"hidden";
    $for_signature_disabled2 = ($cs_detail2->is_for_signature == '0')?"":"disabled hidden";
  }else{
    $for_signature_disabled2 = "disabled";
    $cancel_hide = "hidden";
  }
  //Disable for signature button
  $for_signature_disabled = ($tracks[$i][0]->receiver != "" && $tracks[$i][0]->to_unit_id == $userdata->unit && $tracks[$i][0]->action_done == "")?"":"disabled hidden";
  $signatureBtn='';
}
//disable receive if sub type is Travel Expense Reimbursement and no iot and obr has been created
$disable_receive = (((!isset($iot) || !isset($obr) || !isset($travel_report)) || (!$iot || !$obr || !$travel_report)) &&  in_array($first_track->sub_type,['106','77']))?"disabled":"";
$disable_receive = "";
//set printall to hidden for all documents
$hide_print_all = "hideme";
//if tev, tev-driver, casha adv
if(in_array($first_track->type,[107,2])){
  //remove hideme on print all for coucher and liquidation of CA
  $hide_print_all = "";
  //hide print all and disable receive button if all required doc is not yet created
  if(!isset($iot) || !$iot){
    if(in_array($first_track->type,[107])){
      $disable_receive = "disabled";
      $hide_print_all = "hideme";
    }
    if(in_array($first_track->sub_type,[106,77,80])){
      $disable_receive = "disabled";
      $hide_print_all = "hideme";
    }
  }
  if(!isset($obr) || !$obr){
    if(in_array($first_track->sub_type,[106,77,80,116])){
      $disable_receive = "disabled";
      $hide_print_all = "hideme";
    }
  }
  if(!isset($travel_report) || !$travel_report){
    if(in_array($first_track->sub_type,[106,77])){
      $disable_receive = "disabled";
      $hide_print_all = "hideme";
    }
    if(in_array($first_track->type,[107])){
      $disable_receive = "disabled";
      $hide_print_all = "hideme";
    }
  }
}
// if(in_array($first_track->sub_type,[106,77])){
//   if((!isset($iot) || !isset($obr) || !isset($travel_report)) || (!$iot || !$obr || !$travel_report)){
//     $disable_receive = "disabled";
//     $hide_print_all = "hideme";
//   }else{
//     $hide_print_all = "";
//   }
// }
// if(in_array($first_track->sub_type,[80])){
//   if((!isset($iot) || !isset($obr)) || (!$iot || !$obr)){
//     $disable_receive = "disabled";
//     $hide_print_all = "hideme";
//   }else{
//     $hide_print_all = "";
//   }
// }
// if(in_array($first_track->type,[107])){
//   if((!isset($iot) || !isset($travel_report)) || (!$iot || !$travel_report)){
//     $disable_receive = "disabled";
//     $hide_print_all = "hideme";
//   }else{
//     $hide_print_all = "";
//   }
// }

?>
<div id="loader" style="display:none;"></div>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      View Document (DTSNO <span class="text-primary"><?= $dtsno ?></span>)
      <?php if(in_array($first_track->type,[5,2,115,107])){
        if($first_track->is_approved==1 && $first_track->status == 0){
          echo "- <span class='text-green'>APPROVED</span>";
        }else if($first_track->is_approved!=1 && $first_track->status == 0){
          echo "- <span class='text-warning'>PENDING APPROVAL</span>";
        }else if($first_track->status == 1){
          echo "- <span class='text-danger'>CANCELED</span>";
        }
      } ?>
    </h1>
    <ol class="breadcrumb">
      <li class="active">Viewdoc</li>
    </ol>
  </section>
  <form id="form_download_all" method="POST" action="" target="_blank">
    <input type="hidden" name="dtsno" value="<?= $dtsno; ?>">
  </form>
  <form id="form_download_all_linked" method="POST" action="" target="_blank">
    <input type="hidden" name="dtsno" id="linked_dtsno" value="">
  </form>
  <form id="form_to_pdf" method="POST" action="" target="_blank">
    <input type="hidden" name="img" id="to_img">
    <input type="hidden" name="dtsno" id="to_dtsno" value="">
    <input type="hidden" name="todo" id="to_todo">
  </form>

  <form id="form_submit" method="POST" action="" target="_blank">
    <input type="hidden" name="img" id="img">
    <input type="hidden" name="dtsno" value="<?= $dtsno; ?>">
    <input type="hidden" name="todo" id="todo">
  </form>
  <section class="content">
    <div class="row">
      <div class="col-md-6">
        <div class="box box-default">
          <div class="box-header with-border" id="main_details_header">
            <i class="fa fa-info-circle"></i>
            <h3 class="box-title">Document Details</h3>
            <span class="main_details_header">
            <?php if($audit_trail){ ?>
              <a href="#" id="view_audit_trail" dtsno="<?= $dtsno ?>"  class="view_audit_trail btn btn-header pull-right" title="View Audit Trail"  data-toggle="tooltip" data-placement="left">
                  <span class="label bg bg-purple" style="font-size:100% !important">
                       <i class="fa fa-list"></i>
                  </span>
              </a>
            <?php } ?>
            <?php //for voucher accounting entry
            if($userdata->unit_id == "21" && in_array($first_track->type, [2])){
            ?>
              <a href="#" id="acc_ent" dtsno="<?= $dtsno ?>"  class="acc_ent btn btn-header pull-right" title="Add Accounting Entry" data-toggle="tooltip" data-placement="left">
                  <span class="label label-info pull-right" style="font-size:100% !important">
                       <i class="fa fa-plus-circle"></i>
                  </span>
              </a>
            <?php } ?>
           <?php //user entry (for creator of doc anf doc type: liquidation of ca)
            if($first_track->unit == $userdata->unit_id && in_array($first_track->type, [107]) && $is_signed_aa == 0){
            ?>
              <a href="#" id="user_ent" dtsno="<?= $dtsno ?>"  class="user_ent  btn btn-header pull-right" title="Add Accounting Entry" data-toggle="tooltip" data-placement="left">
                  <span class="label label-info pull-right" style="font-size:100% !important">
                       <i class="fa fa-plus-circle"></i>
                  </span>
              </a>
            <?php } ?>
            <?php //for liquidation of ca accounting entry
            if($userdata->unit_id == "21" && in_array($first_track->type, [107])){
            ?>
              <a href="#" id="acc_ent_liq" dtsno="<?= $dtsno ?>"  class="acc_ent_liq btn btn-header pull-right" title="Add Accounting Entry" data-toggle="tooltip" data-placement="left">
                  <span class="label label-info pull-right" style="font-size:100% !important">
                       <i class="fa fa-plus-circle"></i>
                  </span>
              </a>
            <?php } ?>
            <?php 
            //available only to accountant account
              if($userdata->designation == 5){ ?>
                <a href="#" id="edit_details" dtsno="<?= $dtsno ?>"  class="edit_details btn btn-header pull-right" title="Update Detail" data-toggle="tooltip" data-placement="left">
                    <span class="label label-warning pull-right" style="font-size:100% !important">
                         <i class="fa fa-edit"></i>
                    </span>
                </a>
            <?php 
            }else{
            //if current addressee is in the originator of the document and not yet signed by the accountant
            if($is_signed_aa == 0){ ?>
              <a href="#" id="edit_details" dtsno="<?= $dtsno ?>"  class="edit_details btn btn-header pull-right <?= $disable_edit ?>" title="Update Detail" data-toggle="tooltip" data-placement="left">
                  <span class="label label-warning pull-right" style="font-size:100% !important">
                       <i class="fa fa-edit"></i>
                  </span>
              </a>
            <?php }
            }//end else ?>
            <?php if(in_array($first_track->type,[2,5,117,115,107])){ ?>
            <?php if($first_track->type == 5 && $first_track->status == 0 && $already_linked == false){ ?>
              <?php if($payee->uid == $userdata->uid) { ?>
              <a href="#" id="cancel_to" dtsno="<?= $dtsno ?>"  class="cancel_to btn btn-header pull-right" title="Cancel Travel Order"  data-toggle="tooltip" data-placement="left">
                  <span class="label bg bg-red" style="font-size:100% !important">
                       <i class="fa fa-times"></i>
                  </span>
              </a>
              <?php } ?>
            <?php } ?>
            <a href="#" class="print btn btn-header pull-right " dtsno="<?= $dtsno ?>" type="<?= $first_track->type ?>" title="Print" data-toggle="tooltip" data-placement="left">
                <span class="label label-success pull-right" style="font-size:100% !important">
                     <i class="fa fa-print"></i>
                </span>
            </a>
            <a href="#" class="print_all btn btn-header pull-right <?= $hide_print_all ?>" dtsno="<?= $dtsno ?>" type="<?= $first_track->type ?>" title="Print all" data-toggle="tooltip" data-placement="left">
                <span class="label label-danger pull-right" style="font-size:100% !important">
                     <i class="fa fa-download"></i>
                </span>
            </a>
            <a href="#" id="download" dtsno="<?= $dtsno ?>" type="<?= $first_track->type ?>" class="btn btn-header pull-right " title="Download PDF" data-toggle="tooltip" data-placement="left">
              <span class="label label-primary pull-right" style="font-size:100% !important" >
                   <i class="fa fa-download"></i>
              </span>
            </a>
              <a href="#" id="sign_docs" class="sign_docs btn btn-header pull-right <?= $sign_button; ?>" data-toggle="tooltip" data-placement="left">
              <span class="label bg bg-yellow" style="font-size:100% !important">
                  Sign <i class="fa fa-check"></i>
              </span>
            </a>
            <?php if($first_track->is_approved == 1 && $first_track->is_permanent == 0 && $acc_unit_id == $userdata->unit_id){ ?>
            <a href="#" id="generate_permanent_pdf" class="generate_permanent_pdf btn btn-header pull-right" data-toggle="tooltip" data-placement="left">
              <span class="label bg bg-orange" style="font-size:100% !important">
                  PDF <i class="fa fa-file-pdf-o"></i>
              </span>
            </a>
          <?php } ?>
          <?php }//end in_array($first_track->type,[2,5,117,115,107]) ?>
          <?php 
          //for special order
          if($first_track->type == 23 && $first_track->is_approved == 0 && ($userdata->unit_id == 14 || in_array("1",$userdata->access))){ 
            if($so[0]->is_with_claim == "YES"){
            ?>
            <a href="#" id="approve_so" class="approve_so btn btn-header pull-right" data-toggle="tooltip" data-placement="left">
              <span class="label bg bg-green" style="font-size:100% !important">
                  Approve <i class="fa fa-thumbs-up"></i>
              </span>
            </a>
          <?php 
            }
          } ?>
          </span>
          </div>

          <div class="box-body">
            <img src="<?php echo base_url();?>General/generate_barcode/<?= $dtsno ?>">
            <dl class="dl-horizontal">
              <dt>Document Type</dt>
              <dd><?= $first_track->doc_t ?></dd>
              <dt>Date Created</dt>
              <dd><?= date("F d, Y", strtotime($first_track->date_created)); ?></dd>
              <dt>Sub-Type</dt>
              <dd><?= $first_track->sub_type_name ?></dd>
            </dl>
            <div id="document_details">
              <?= $first_track->doc_details ?>
            </div>
            <hr>
            <div id="attachment_div">
              <h4><i class="fa fa-paperclip"></i> Attached Document</h4>

              <?php if($first_track->attachment_filename!=""){//if with attachment ?>
                <span id="general_file">Attached File:
                  <a class="edit_upload btn btn-header pull-right" file_id="0">
                    <span class="label label-warning pull-right" style="font-size:85% !important">Edit<i class="fa fa-edit"></i></span>
                  </a>

                <a href="<?= base_url().$first_track->attachment_path.'/'.$first_track->attachment_filename;  ?>" target='_blank'>
                  <span class="input-group-addon active" style="text-align: left !important;"><i class="fa fa-download"></i>  
                    <?= $first_track->attachment_filename ?>
                  </span>
                </a>
                </span>

              <?php }else{//if without attachement ?>
                <span id="general_file">Attached File:
                  <a class="edit_upload btn btn-header pull-right" file_id="0">
                    <span class="label label-warning pull-right" style="font-size:85% !important">Edit<i class="fa fa-edit"></i></span>
                  </a>

                <a href="#!">
                  <span class="input-group-addon" style="text-align: left !important;"><i class="fa fa-download"></i> 
                    NO ATTACHMENT
                  </span>
                </a>
              </span>

              <?php } ?>
              <?php 
              foreach($attached_files as $val){
                if($val->file!="/"){
                    echo '<span id="file'.$val->id.'">'.$val->fieldname.':';
                  if($is_signed_aa == 0 && $is_signed_dir == 0 && $first_track->is_approved == 0){

                    echo '<a href="#" id="edit_upload" fieldname="'.$val->fieldname.'"  file_id="'.$val->id.'" old_file="'.$val->file.'" class="edit_upload btn btn-header pull-right '.$disable_edit.'">
                      <span class="label label-warning pull-right" style="font-size:85% !important">
                            Edit <i class="fa fa-edit"></i>
                        </span>
                    </a>';
                    }
                    echo '<a href="'.base_url().$val->file.'" target="_blank">
                      <span class="input-group-addon active" style="text-align: left !important;"><i class="fa fa-download"></i> 
                        '.$val->filename.'
                      </span>
                    </a>
                    </span>';
                }else{

                    echo "<span id=file{$val->id}>{$val->fieldname}:";
                  if($is_signed_aa == 0 && $is_signed_dir == 0  && $first_track->is_approved == 0){
                    echo "<a href='#'' id='edit_upload' fieldname='{$val->fieldname}'  file_id='{$val->id}' class='edit_upload'>
                      <span class='label label-danger pull-right' style='font-size:100% !important'>
                            Upload <i class='fa fa-upload'></i>
                        </span>
                    </a>";
                  }
                  echo "<a>
                  <span class='input-group-addon' style='text-align: left !important;''><i class='fa fa-times'></i> 
                      NO ATTACHED FILE
                    </span>
                  </a>
                  </span>";
                }
              } ?>
            </div>
          </div>
        </div>
      </div>


      <div class="col-md-6">
        <div class="box box-default">
          <div class="box-header with-border">
            <i class="fa fa-link"></i>
            <h3 class="box-title">Linked Documents</h3>
          </div>

          <div class="box-body">
            <table class="table table-bordered">
              <thead>
                <th>DTS No:</th>
                <th>Document Type:</th>
                <th width="30%">Details:</th>
                <th width="20%">action:</th>
              </thead>
              <tbody id="linked_doc_tbody">
                <?php 
                  if($linked_doc){ 
                    foreach($linked_doc as $val){
                      if($val->is_deleted == 0){
                        ?>
                <tr>
                  <td><?= $val->linked_dtsno ?></td>
                  <td><?= $val->doc_type."-".$val->sub_type_name ?></td>
                  <td><?= mb_strimwidth($val->doc_details, 0, 150, "..."); ?></td>
                  <td align="center">
                    <a href="#!" class="print_linked_docs" to_todo="0" dtsno="<?= $val->linked_dtsno ?>" doc_type_id="<?= $val->type ?>"  sub_type_id="<?= $val->sub_type ?>" title="View PDF"  data-toggle="tooltip" data-placement="left">
                      <span class="label label-success" style="font-size:100% !important">
                      <i class="fa fa-file-pdf-o"></i></span>
                    </a> 
                    <a href="#" dtsno="<?= $val->linked_dtsno ?>" to_todo="1" type="5" class="print_linked_docs" doc_type_id="<?= $val->type ?>"  sub_type_id="<?= $val->sub_type ?>" title="Download PDF"  data-toggle="tooltip" data-placement="left">
                      <span class="label label-primary" style="font-size:100% !important" ><i class="fa fa-download"></i></span>
                    </a>
                    <a href="<?php echo base_url(); ?>Document/<?= $val->linked_dtsno ?>" target="_blank" title="View Document" data-toggle="tooltip" data-placement="left">
                      <span class="label label-info" style="font-size:100% !important">
                      <i class="fa fa-eye"></i></span>
                    </a> <hr style="margin-top:8px !important; margin-bottom: 8px !important;">
                    <?php 
                    //edit for originator only
                    if($is_signed_aa == 0 && $is_signed_dir == 0  && $first_track->is_approved == 0){
                    ?> 
                    <a href="#" class="edit_linked_doc btn btn-header <?= $disable_edit ?>" 
                      id="<?= $val->id ?>" 
                      type="<?= $val->type ?>" 
                      fieldname="<?= $val->doc_type ?>" 
                      linked_dtsno="<?= $val->linked_dtsno ?>" 
                      employee_id="<?= $employee_id?$employee_id:""; ?>" 
                      title="EDIT" data-toggle="tooltip" data-placement="left">
                      <span class="label label-warning pull-right" style="font-size:100% !important">
                      <i class="fa fa-edit"></i></span>
                    </a>
                    <?php } 
                    //show only for document creator and AB if doc type is ADA (117)
                    if(($first_track->unit == $userdata->unit_id) || ($userdata->unit_id == $ab_unit_id && $first_track->type == 117)){
                    ?>
                    <a href="#" class="delete_linked_doc btn btn-header <?= $disable_edit ?>" 
                      id="<?= $val->id ?>" 
                      type="<?= $val->type ?>" 
                      fieldname="<?= $val->doc_type ?>" 
                      linked_dtsno="<?= $val->linked_dtsno ?>" 
                      employee_id="<?= $employee_id?$employee_id:""; ?>" 
                      title="Remove Linked Document" data-toggle="tooltip" data-placement="left">
                      <span class="label label-danger pull-right" style="font-size:100% !important">
                      <i class="fa fa-trash"></i></span>
                    </a>
                  <?php } ?>
                  </td>
                </tr>
                <?php 
                      }else{
                        ?>
                <tr class="tr_deleted">
                  <td><?= $val->linked_dtsno ?></td>
                  <td><?= $val->doc_type."-".$val->sub_type_name ?></td>
                  <td><?= mb_strimwidth($val->doc_details, 0, 150, "..."); ?></td>
                  <td width="150px" align="center">
                    <label>Deletion Reason</label><br>
                    <?= $val->delete_reason ?>
                    <label>Deleted By</label><br>
                    <?= $val->deleted_by ?>
                  </td>
                </tr>
                <?php
                      }
                    }
                  } 
                ?>
              </tbody>
            </table>
            <?php 
            if(in_array($first_track->type,[2,107])){ ?>
            <hr>
            <span><h4>Other Required Documents

              <a href="#!" id="checklist" class="btn btn-header pull-right" title="Add Remarks" data-toggle="tooltip" data-placement="left">
                <span class="label label-warning pull-right" style="font-size:100% !important">
                <i class="fa fa-comment"></i></span>
              </a>  
            </h4></span>
            <?php
            $iot_tr = $iot?"":"tr_red";
            $obr_tr = $obr?"":"tr_red";
            $travel_report_tr = $travel_report?"":"tr_red";
            ?>
            <table class="table table-bordered" id="other_req_tb" width="100%">
              <thead>
                <th width="35%">Document Type</th>
                <th width="45%">Details</th>
                <th width="20%">Action</th>
              </thead>
              <tbody>
                <?php 
                if($ad_id){
                  foreach($ad_id as $val){
                  if($val->ad_id == 4){ 
                  ?>
                     <tr class="<?= $iot_tr ?>" id="iot_tr">
                      <td width="35%">Itinerary of Travel</td>
                      <td width="45%" id="iot_detail">
                        <?php 
                        if($iot){
                          echo $iot[0]->travel_duration;
                        } ?>                    
                      </td>
                      <td width="20%" id="iot_action">
                        <?php 
                        if($iot){
                        ?>
                        <a href="#!" id="view_iot" class="print"  type="iot">
                          <span class="label label-success pull-right" style="font-size:100% !important">Pdf
                          <i class="fa fa-file-pdf-o"></i></span>
                        </a>  
                        <a href="#" id="download" dtsno="<?= $dtsno ?>" type="iot" class="btn btn-header pull-right ">
                          <span class="label label-primary pull-right" style="font-size:100% !important" >
                              Download <i class="fa fa-download"></i>
                          </span>
                        </a>
                        <?php
                        //if not yet signed by aa or dir
                        if(($is_signed_aa == 0 && $is_signed_dir == 0) || $userdata->designation == "5"  && $first_track->is_permanent == 0){
                        ?>
                        <a href="#!" id="edit_iot" class="btn btn-header pull-right <?= $disable_edit ?>">
                          <span class="label label-warning pull-right" style="font-size:85% !important">Edit
                          <i class="fa fa-edit"></i></span>
                        </a>  
                        <?php 
                          }//end not yet signed by aa or dir
                        }else{ ?>
                        <?php
                        //if for originator only
                        if($first_track->unit == $userdata->unit_id ){
                        ?>                     
                        <a href="#" id="create_iot">
                          <span class="label label-success pull-right <?= $disable_edit ?>" style="font-size:100% !important">Create
                          <i class="fa fa-plus"></i></span>
                        </a>  
                      <?php 
                        }
                      } ?>
                      </td>
                    </tr>
                  <?php } ?>
                <?php if($val->ad_id == 5){ ?>
                    <tr class="<?= $iot_tr ?>" id="cotc_tr">
                      <td>CERTIFICATION OF TRAVEL COMPLETED</td>
                      <td id="cotc_detail"><?= $iot?$iot[0]->official_station:""; ?></td>
                      <td id="cotc_action">
                        <?php 
                        if($iot){
                        ?>
                        <a href="#!" id="view_cotc" class="print" type="cotc">
                          <span class="label label-success pull-right" style="font-size:100% !important">Pdf
                          <i class="fa fa-file-pdf-o"></i></span>
                        </a> 
                        <a href="#" id="download" dtsno="<?= $dtsno ?>" type="cotc" class="btn btn-header pull-right ">
                          <span class="label label-primary pull-right" style="font-size:100% !important" >
                              Download <i class="fa fa-download"></i>
                          </span>
                        </a>
                        <?php } ?>
                      </td>
                    </tr>
                  <?php }; ?>
                  <?php if($val->ad_id == 3){ ?>
                    <tr class="<?= $obr_tr ?>" id="obr_tr">
                      <td>OBR</td>
                      <td id="obr_detail"><?= $obr?$obr[0]->particulars:""; ?></td>
                      <td id="obr_action">
                        <?php 
                        if($obr){
                        ?>
                        <a href="#!" id="view_obr" class="print" type="obr">
                          <span class="label label-success pull-right" style="font-size:100% !important">Pdf
                          <i class="fa fa-file-pdf-o"></i></span>
                        </a>
                        <a href="#" id="download" dtsno="<?= $dtsno ?>" type="obr" class="btn btn-header pull-right ">
                          <span class="label label-primary pull-right" style="font-size:100% !important" >
                              Download <i class="fa fa-download"></i>
                          </span>
                        </a>
                        <?php
                        //if for originator only
                        if(($is_signed_aa == 0 && $is_signed_dir == 0  && $first_track->is_approved == 0) || $userdata->designation == 5){
                        ?>
                        <a href="#!" id="edit_obr" class="btn btn-header pull-right <?= $disable_edit ?>">
                          <span class="label label-warning pull-right" style="font-size:85% !important">Edit
                          <i class="fa fa-edit"></i></span>
                        </a>  
                        <?php 
                          }
                        }else{ ?>
                        <?php
                        //if for originator only
                        if($first_track->unit == $userdata->unit_id && $is_signed_aa == 0 && $is_signed_dir == 0  && $first_track->is_approved == 0){
                        ?>                     
                          <a href="#" id="create_obr">
                            <span class="label label-success pull-right <?= $disable_edit ?>" style="font-size:100% !important">Create
                            <i class="fa fa-plus"></i></span>
                          </a>  
                      <?php 
                          }
                        } ?> 
                      </td>
                    </tr>
                  <?php } ?>
                  <?php if($val->ad_id == 6){ ?>
                    <tr class="<?= $travel_report_tr ?>" id="travel_report_tr">
                      <td>Travel Report</td>
                      <td id="travel_report_detail"><?= $travel_report?$travel_report[0]->purpose:""; ?></td>
                      <td id="travel_report_action">
                        <?php 
                        if($travel_report){
                        ?>
                        <a href="#!" id="" class="print" type="travel_report">
                          <span class="label label-success pull-right" style="font-size:100% !important">Pdf
                          <i class="fa fa-file-pdf-o"></i></span>
                        </a>
                        <a href="#" id="download" dtsno="<?= $dtsno ?>" type="travel_report" class="btn btn-header pull-right ">
                          <span class="label label-primary pull-right" style="font-size:100% !important" >
                              Download <i class="fa fa-download"></i>
                          </span>
                        </a>
                        <?php
                        //if for originator only
                        if(($is_signed_aa == 0 && $is_signed_dir == 0  && $first_track->is_approved == 0) || $userdata->designation == 5){
                        ?>
                        <a href="#!" id="view_travel_report" class="btn btn-header pull-right <?= $disable_edit ?>">
                          <span class="label label-warning pull-right" style="font-size:85% !important">Edit
                          <i class="fa fa-edit"></i></span>
                        </a>  
                        <?php 
                          }
                        }else{ ?>
                        <?php
                        //if for originator only
                        if($first_track->unit == $userdata->unit_id && $is_signed_aa == 0 && $is_signed_dir == 0  && $first_track->is_approved == 0){
                        ?>                     
                          <a href="#" class="add_travel_report">
                            <span class="label label-success pull-right <?= $disable_edit ?>" style="font-size:100% !important">Create
                            <i class="fa fa-plus"></i></span>
                          </a>
                      <?php   } 
                            }
                          }
                         ?> 
                      </td>
                    </tr>
                      <?php if($val->ad_id == 7 && $obr){ 
                        ?>

                        <?php if($ors_burs){ ?>
                          <tr id="ors_tr">
                            <td><?= $obr[0]->ors_burs ?></td>
                            <td id="ors_detail">
                              <?= "Date:".$ors_burs[0]->date."<br>".$obr[0]->ors_burs." No.:".$ors_burs[0]->ors_burs_no ?>
                              <?php
                              if($ors_burs[0]->yoi!=""){
                                echo "<br>Year of Implementation: {$ors_burs[0]->yoi}";
                              }
                              ?>
                            </td>
                            <td id="ors_action">   
                            <a href="#!" id="" class="print" type="ors_burs" ors_burs="<?= $obr[0]->ors_burs ?>">
                              <span class="label label-success pull-right" style="font-size:100% !important">Pdf
                              <i class="fa fa-file-pdf-o"></i></span>
                            </a>
                            <a href="#" id="download" type="ors_burs" ors_burs="<?= $obr[0]->ors_burs ?>" class="btn btn-header pull-right " >
                              <span class="label label-primary pull-right" style="font-size:100% !important" >
                                  Download <i class="fa fa-download"></i>
                              </span>
                            </a>
                              <?php
                              //if for originator only
                              if($userdata->unit_id == $ab_unit_id && $is_signed_aa == 0 && $is_signed_dir == 0  && $first_track->is_approved == 0){
                              ?>                     
                              <a href="#!" id="edit_ors_burs" 
                              class="btn btn-header pull-right" 
                              allotment_class="<?= $ors_burs[0]->allotment_class ?>" 
                              ors_burs_id="<?= $ors_burs[0]->id ?>" 
                              ors_burs_date="<?= $ors_burs[0]->date ?>" 
                              ors_burs_no="<?= $ors_burs[0]->ors_burs_no ?>" 
                              yoi="<?= $ors_burs[0]->yoi ?>" 
                              payable="<?= $ors_burs[0]->payable ?>" 
                              payment="<?= $ors_burs[0]->payment ?>" 
                              nyd="<?= $ors_burs[0]->nyd ?>" 
                              ors_burs="<?= $obr[0]->ors_burs ?>">
                                <span class="label label-warning pull-right" style="font-size:85% !important">Edit
                                <i class="fa fa-edit"></i></span>
                              </a> 
                              <?php } ?> 
                            </td>
                          </tr>
                        <?php }else{ 
                          ?>
                          <tr class="tr_red" id="ors_tr">
                            <td><?= $obr[0]->ors_burs ?></td>
                            <td id="ors_detail"></td>
                            <td id="ors_action">
                              <?php if($userdata->unit_id == $ab_unit_id && $fmaBtn_disabled != "disabled"){ ?>
                              <a href="#" class="add_ors" id="add_ors" ors_burs="<?= $obr[0]->ors_burs ?>">
                                <span class="label label-success pull-right" style="font-size:100% !important">Create
                                <i class="fa fa-plus"></i></span>
                              </a> 
                              <?php 
                        //disable fma button if ors not yet created for ab only
                        $fmaBtn_disabled = "disabled";
                        $for_signature_disabled = "disabled";
                            } ?> 
                            </td>
                          </tr>
                <?php }//end else 
                    }//end if($val->ad_id == 7)
                  }//end foreach($ad_id as $val)
                }//end if($ad_id)
                ?>
              </tbody>
            </table>
            <?php } ?>
          </div>
        </div>
      </div>

      <?php 
      $ii = 1;
      for($i=0; $i<$tracks_count;$i++){ 
      ?>
        
      <div class="col-md-12">
        <div class="box box-info">
          <div class="box-header with-border">
            <i class="fa fa-exchange"></i>
            <h3 class="box-title">Document Track <?= $ii++ ?></h3>
            
            <a href="#" class="btn btn-header <?= $fmaBtn_disabled." ".$fmaBtn_disable2 ?> pull-right archiveBtn fma" tracker_id="<?= $tracks[$i][0]->tracker_id ?>" copy_no="<?= $tracks[$i][0]->copy_no ?>" title="Archive Document"  data-toggle="tooltip" data-placement="left">
                <span class="label label-warning " style="font-size:100% !important">
                    Archive <i class="fa fa-archive"></i>
                </span>
            </a> 

            <a href="#" class="btn btn-header <?= $fmaBtn_disabled." ".$fmaBtn_disable2  ?> pull-right makecopyBtn fma" tracker_id="<?= $tracks[$i][0]->tracker_id ?>" copy_no="<?= $tracks[$i][0]->copy_no ?>" title="Make Copy"  data-toggle="tooltip" data-placement="left">
                <span class="label label-info " style="font-size:100% !important">
                    Make Copy <i class="fa fa-copy"></i>
                </span>
            </a> 

            <a href="#" class="btn btn-header <?= $fmaBtn_disabled." ".$fmaBtn_disable2  ?> pull-right forwardBtn fma" tracker_id="<?= $tracks[$i][0]->tracker_id ?>" is_disabled="<?= $fmaBtn_disabled." ".$fmaBtn_disable2  ?>" copy_no="<?= $tracks[$i][0]->copy_no ?>" id="forwardBtn" title="Forward Document" data-toggle="tooltip" data-placement="left">
                <span class="label label-success " style="font-size:100% !important">
                    Forward <i class="fa fa-forward"></i>
                </span>
            </a> 
            <?php if($first_track->type != 117){ ?>
            <a href="#" class="btn btn-header <?= $for_signature_disabled." ".$for_signature_disabled2 ?> pull-right signatureBtn fma" dtsno="<?= $dtsno ?>" title="Submit for E-Signature" data-toggle="tooltip" data-placement="left">
                <span class="label btn bg-purple margin" style="font-size:100% !important">
                    For E-Signature / E-Initial <i class="fa fa-address-card-o"></i>
                </span>
            </a> 
          <?php } ?>
            <a href="#" class="btn btn-header <?= $cancel_hide ?> pull-right cancel_signatureBtn" dtsno="<?= $dtsno ?>" title="Cancel For E-Signature"  data-toggle="tooltip" data-placement="left">
                <span class="label btn bg-red margin" style="font-size:100% !important">
                    Cancel E-Signature / E-Initial <i class="fa fa-times"></i>
                </span>
            </a> 

            <a href="#" class="btn btn-header <?= $disable_receive ?> <?= $receiveBtn_disabled ?> pull-right receiveBtn" tracker_id="<?= $tracks[$i][0]->tracker_id ?>" copy_no="<?= $tracks[$i][0]->copy_no ?>" title="Receive Document" data-toggle="tooltip" data-placement="left">
                <span class="label label-primary " style="font-size:100% !important">
                    Receive <i class="fa fa-inbox"></i>
                </span>
            </a>

          </div>

          <div class="box-body overflow-auto">
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                      <th width="10%">Date Forwarded</th>
                      <th width="10%">Forwarded By</th>
                      <th width="15%">Action Requested</th>
                      <th width="10%">Forwarded To</th>
                      <th width="10%">Received Time</th>
                      <th width="10%">Received By</th>
                      <th width="15%">Action Done</th>
                      <th width="5%">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($tracks[$i] as $val){ 
                  $received_time = $val->received_time == "0000-00-00 00:00:00" ? "":$val->received_time;
                  ?>
                  <tr>
                    <td><?= $val->date_forwarded ?></td>
                    <td><?= $val->from_user . " | " . $val->from_division . " - ". $val->from_unit ?></td>
                    <td><?= $val->action?></td>
                    <td><?= $val->to_division . ' - '. $val->to_unit?></td>
                    <td><?= $received_time ?></td>
                    <td><?= $val->received_by ?></td>
                    <td><?= $val->action_done?></td>
                    <td align="center">
                    <?php if( $val->from_unit_id == $userdata->unit_id && $val->receiver == ""){ ?>            
                      <a href="#" class="btn btn-header edit_track"
                      tracker_id = "<?= $val->tracker_id ?>"
                      to_div_id = "<?= $val->to_div_id ?>"
                      to_unit_id = "<?= $val->to_unit_id ?>"
                      action_req = "<?= $val->action ?>"
                      >
                        <span class="label label-primary">
                          <i class="fa fa-edit"></i> Edit
                        </span>
                      </a>
                    <?php } ?>
                    </td>
                  </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    <?php } ?>
    </div>
  </section>            
</div>

<?php  $this->load->view('viewdoc/modal'); ?>
<?php  $this->load->view('viewdoc/viewdoc_js'); ?>
