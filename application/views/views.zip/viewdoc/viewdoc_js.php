<script src="<?php echo base_url(); ?>assets/js/JsBarcode.all.min.js"></script>
<script>
const dtsno = "<?= $dtsno ?>";
const doc_type_id = "<?= $first_track->type ?>";
const sub_type_id = "<?= $first_track->sub_type ?>";
const logged_user_designation = "<?= $userdata->designation ?>";
const is_signed_by_logged_user = "<?= (isset($cs_detail->is_signed))?$cs_detail->is_signed:"0" ?>";
var already_signed = "<?= $already_signed ?>";
var is_permanent = "<?= $first_track->is_permanent ?>";
var iot_date_from ="", iot_date_to="";
var unit_id = "";
function getDiv(e) {
    var unit_options = "";
	  $("#div_id_fwd").prop("disabled",true);
	  $(".unitid").prop("disabled",true);
    $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>General/unit_list",
    dataType: "JSON",
    data:{divunit_id:e.value},
    success: function(data){
        if(data != false){
            $.each(data, function(i, val) {
            	var selected = val.divunit_id == unit_id?"selected":"";
            unit_options +=`<option ${selected} value='${val.divunit_id}' title='${val.divunit_name}'>${val.divunit_abv} - ${val.divunit_name}</option>`;
            });
        }
        else{
            unit_options +=`<option value='' selected disabled>Please Select Division First</option>`;
            }
            $(".unitid").html(unit_options);
					  $("#div_id_fwd").prop("disabled",false);
					  $(".unitid").prop("disabled",false);
    }
    });
}

function generate_permanent_pdf(){
	var type = doc_type_id;
	var canvas = document.createElement("canvas");
	JsBarcode(canvas, dtsno, {format: "CODE128",width: 1,
                height: 25,fontSize: 15});
	var img = canvas.toDataURL("image/png");

	$("#todo").val(3)
    $('#dts_body').addClass('disable_page');
    $('#loader').show();
	setTimeout(function(){ 
		if(type == 5){
			$.ajax({
				type: "POST",
				dataType: "JSON",
				async: false,
				data: {todo:3,img:img,dtsno:dtsno},
				url: base_url+'Pdf_generator/travel_order',
				success: function(data){
				},
				complete : function(){
	          $('#dts_body').removeClass('disable_page');
			    document.getElementById("loader").style.display = "none";
          window.location.replace("<?php echo base_url(); ?>Document/"+dtsno);
			}
			})
		}		
		if(type == 2 ||  type == 107||  type == 115 || type == 117){
			if(type == 117){//dv
				$.ajax({
					type: "POST",
					dataType: "JSON",
					async: false,
					data: {todo:3,img:img,dtsno:dtsno},
					url: base_url+'Pdf_generator/ada',
					success: function(data){
					}
				})
			}
			if(type == 2){//dv
				$.ajax({
					type: "POST",
					dataType: "JSON",
					async: false,
					data: {todo:3,img:img,dtsno:dtsno},
					url: base_url+'Pdf_generator/dv',
					success: function(data){
					}
				})
			}
			if(type == 107){//liquidation of ca
				$.ajax({
					type: "POST",
					dataType: "JSON",
					async: false,
					data: {todo:3,img:img,dtsno:dtsno},
					url: base_url+'Pdf_generator/ca_liquidation',
					success: function(data){
					}
				})
			}
			if(type == 115){//CONC
				$.ajax({
					type: "POST",
					dataType: "JSON",
					async: false,
					data: {todo:3,img:img,dtsno:dtsno},
					url: base_url+'Pdf_generator/conc',
					success: function(data){
					}
				})
			}    
			<?php 
      if($linked_doc){ 
        foreach($linked_doc as $val){
  	?>
				var canvas_linked = document.createElement("canvas");
				JsBarcode(canvas, "<?= $val->linked_dtsno ?>", {format: "CODE128",width: 1,
		                  height: 25,fontSize: 15});
				var img_linked = canvas.toDataURL("image/png");		
    <?php if($val->type == 5){?>
			// $.ajax({
			// 	type: "POST",
			// 	dataType: "JSON",
			// 	async: false,
			// 	data: {todo:3,img:img_linked,dtsno:"<?= $val->linked_dtsno ?>"},
			// 	url: base_url+'Pdf_generator/travel_order',
			// 	success: function(data){
			// 	}
			// })
			<?php }
			if($val->type == 2){ ?>
			$.ajax({
				type: "POST",
				dataType: "JSON",
				async: false,
				data: {todo:3,img:img_linked,dtsno:"<?= $val->linked_dtsno ?>"},
				url: base_url+'Pdf_generator/dv',
				success: function(data){
				}
			})
			<?php } ?>
  	<?php }
		  }
		?>
    <?php 
    if($ad_id){
      foreach($ad_id as $val){
    	?>
			$.ajax({
				type: "POST",
				dataType: "JSON",
				async: false,
				data: {todo:3,img:img,dtsno:dtsno},
				url: base_url+'Pdf_generator/<?= $val->pdf_link ?>',
				success: function(data){
				}
			})
		<?php }//end foreach ?>      
	<?php }//end if $ad_id?>      
		$.ajax({
			type: "POST",
			dataType: "JSON",
			async: false,
			data: {dtsno:dtsno,doc_type_id:doc_type_id,sub_type_id:sub_type_id},
			url: base_url+'Pdf_generator/mergepdf_gs_permanent',
			success: function(data){
				// $("#form_download_all").attr('action', '<?= base_url() ?>Pdf_generator/download_mergedPdf');
				// $('#form_download_all').submit();
			},
			complete : function(){
	          $('#dts_body').removeClass('disable_page');
			    document.getElementById("loader").style.display = "none";
          window.location.replace("<?php echo base_url(); ?>Document/"+dtsno);
			}
		})
	}
	},100);
}

function to_signatory(){
  var uid = $("#euid").val();
  var daterange = $("#daterangepicker").val();
  if(doc_type_id == 5 || doc_type_id == 107){
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>Submit_document/generate_signatory",
      dataType: "JSON",
      data:{uid:uid,doc_type_id:doc_type_id, daterange:daterange,dtsno:dtsno},
      success: function(data){
        var doc_detail = "";
        var label, select_name, selected="";
        $.each(data.selected_signatories, function(i, value) {
          if(value!=false){
            if(value.signatory_id!=0){
              doc_detail += `<input type="hidden" name="cs_id[]" value="${value.id}" >`;
              doc_detail += `<input type="hidden" name="to_unit_id[]" value="${value.signatory_unit_id}" >`;
              doc_detail += `<input type="hidden" name="to_designation_id[]" value="${value.signatory_type}">`;
              doc_detail += `<input type="hidden" name="ads_id[]" value="${value.ads_id}">`;
              doc_detail += `<input type="hidden" name="label[]" value="${value.label}">`;

              doc_detail +=`<label>${value.label}:</label>`;
	      			//use ad_signatory id for unique select class and id to be used in selecting of selected option in update
              doc_detail +=`<select class="form-control select2_dynamic" name="sid[]">`;
              if(value.ads_id == 18){
	              if(value.uid == 0){
	                doc_detail += `<option value="0" selected>Not Applicable</option>`; 
              	}else{
	                doc_detail += `<option value="0">Not Applicable</option>`; 
              	}
              }
              $.each(data.signatories, function(i, val) {
                selected="";
                if(val.uid == value.uid){
                  selected = "selected";
                }
                //if ad_sig is section / unit Initial (ERDB MAIN)
              if(value.ads_id == 18){
	              if(data.employee.unit == val.unit_id){
                doc_detail += `<option value="${val.id}" ${selected}>${val.designation}:${val.lname}, ${val.fname} ${val.mname}</option>`; 
              	}
            	}else{
                doc_detail += `<option value="${val.id}" ${selected}>${val.designation}:${val.lname}, ${val.fname} ${val.mname}</option>`; 
            	}
              });
              doc_detail += `</select>`;
            }
          }
        });
        $("#signature_div").html(doc_detail);
        	//enable select2 in signatory select
	        $(`.select2_dynamic`).select2();
      }
    })
  }
}
$( window ).on( "pageshow", function() {
		<?php 
		if($list_already_signed){
			foreach($list_already_signed as $val){ 
				if($val->fullname!=""){
			?>
	$('dd:contains("<?= $val->fullname ?>")').html("<?= $val->fullname ?><i class='fa fa-check'></i>").css({ 'color': 'red', 'font-size': '120%', 'font-weight':'bold' });
		<?php }//end if val !=""
		 }//end foreach
	  }//end if($list_already_signed) ?>
	//check if forward button is active
	var forward_btn_is_disabled = $("#forwardBtn").attr('is_disabled')==" "?0:1;
	//if logged user is accountant & forward btn is not disabled & document is already signed by logged user & doc type is voucher
	if(logged_user_designation == 5 && forward_btn_is_disabled == 0 && is_signed_by_logged_user == 1 && jQuery.inArray(doc_type_id, ["2","107"]) !== -1 && is_permanent == 0){
		unit_id = "15";
		$("#action_done_fwd").val("Signed by AA");
		$("#action_req_fwd").val("For Signature / Approval");
		$("input[name=is_manually_signed][value='0']").prop("checked",true);
		//show forward button
		setTimeout(function(){
				$(".forwardBtn").trigger("click");
		},300)
		setTimeout(function(){
		$("#div_id_fwd").val("1").change();
		},400)
	}	
})

$(document).ready(function() { 
		while($('#forward_modal').hasClass('in')){
			
		}

	$("#checklist_tb").DataTable({
    order: [[ 0, "asc" ]], //Initial no order.
    responsive: true,
    "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
    "iDisplayLength": 5,
     bAutoWidth: false, 
	});
	var tr_tb =  $("#tr_tb").DataTable({
    responsive: true,
    "aLengthMenu": [[1, 10, 20, 50], [1, 10, 20, 50]],
    "iDisplayLength": 1,
     bAutoWidth: false, 
     scrollY: '450px',
    scrollCollapse: true,
	});

	var acc_ent_tb =  $("#acc_ent_tb").DataTable({
    responsive: true,
    "aLengthMenu": [[1, 10, 20, 50], [1, 10, 20, 50]],
    "iDisplayLength": 4,
     bAutoWidth: false, 
    scrollCollapse: true,
	});

	var table =  $("#audit_trail_table").DataTable({
    "order": [3,'DESC'], //Initial no order.
    responsive: true,
    "aLengthMenu": [[5, 10, 20, 50], [5, 10, 20, 50]],
    "iDisplayLength": 5,
	});
	$(".receiveBtn").click(function(){
		var tracker_id = this.getAttribute("tracker_id"); 
		$("#receive_tracker_id").val(tracker_id);
		$("#receive_modal").modal("show");
	})



	$("#confirmReceive_btn").click(function(){
		var tracker_id = $("#receive_tracker_id").val();
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {tracker_id:tracker_id, doc_type_id:doc_type_id, dtsno:dtsno},
			url: base_url+'General/fast_receive',
			success: function(data){
				if(data.error_msg==0){
          window.location.replace("<?php echo base_url(); ?>Document/"+dtsno);
				}else{
					if(data.refresh == 0){
						toastr.warning(data.error_msg);
					}else{
						location.reload();
					}
				}
			}
		})
	})

	$(".signatureBtn").click(function(){
		$("#signature_modal").modal("show");
	})

	$("#confirmSignature_btn").click(function(){
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno, doc_type_id:doc_type_id},
			url: base_url+'Viewdoc/for_signature',
			success: function(data){
				if(data!=false){
	              window.location.replace("<?php echo base_url(); ?>Document/"+data);
				}
			}
		})
	})


	$(".cancel_signatureBtn").click(function(){
		$("#cancel_signature_modal").modal("show");
	})

	$("#confirmCancel_btn").click(function(){
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno,doc_type_id:doc_type_id},
			url: base_url+'Viewdoc/cancel_signature',
			success: function(data){
				if(data!=false){
	              window.location.replace("<?php echo base_url(); ?>Document/"+data);
				}
			}
		})
	});

	$(".forwardBtn").click(function(){
		var tracker_id = this.getAttribute("tracker_id"); 
		var copy_no = this.getAttribute("copy_no"); 
		$("#forward_tracker_id").val(tracker_id);
		$("#forward_copy_no").val(copy_no);
		$(".divid").val("").change();
        var unit_options =`<option value='' selected disabled>Please Select Division First</option>`;
        $(".unitid").html(unit_options);
		$("#forward_modal").modal("show");
	})


	$("#confirmForward_btn").click(function(e){
	    if($("#form_forward")[0].checkValidity()!=false){
	      	e.preventDefault();
		    var form_data = new FormData($('#form_forward')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data:form_data,
				contentType: false, 
				processData: false,
				url: base_url+'Viewdoc/forward',
				success: function(data){
					if(data!=false){
	          window.location.replace("<?php echo base_url(); ?>Document/"+data);
					}
				}
			})
		}
	})

	$(".makecopyBtn").click(function(){
		var copy_no = this.getAttribute("copy_no"); 
		$(".divid").val("").change();
        var unit_options =`<option value='' selected disabled>Please Select Division First</option>`;
        $(".unitid").html(unit_options);
		$("#mc_copy_no").val(parseInt(copy_no)+1);
		$("#mc_modal").modal("show");
	})

	$("#confirmMc_btn").click(function(e){
	    if($("#form_mc")[0].checkValidity()!=false){
	      	e.preventDefault();
		    var form_data = new FormData($('#form_mc')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data:form_data,
				contentType: false, 
				processData: false,
				url: base_url+'Viewdoc/make_copy',
				success: function(data){
					if(data!=false){
		              window.location.replace("<?php echo base_url(); ?>Document/"+data);
					}
				}
			})
		}
	})


	$(".archiveBtn").click(function(){
		var tracker_id = this.getAttribute("tracker_id"); 
		var copy_no = this.getAttribute("copy_no"); 
		$("#archive_tracker_id").val(tracker_id);
		$("#archive_copy_no").val(copy_no);
		$("#archive_modal").modal("show");
	})


	$("#confirmArchive_btn").click(function(e){
	    if($("#form_archive")[0].checkValidity()!=false){
	      	e.preventDefault();
		    var form_data = new FormData($('#form_archive')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data:form_data,
				contentType: false, 
				processData: false,
				url: base_url+'Viewdoc/archive',
				success: function(data){
					if(data!=false){
						if(doc_type_id == 117){
	          	generate_permanent_pdf();
						}else{
	            window.location.replace("<?php echo base_url(); ?>Document/"+data);
	          }
					}
				}
			})
		}
	})

	$(document).on("click",".edit_details",function(){
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno},
			url: base_url+'Viewdoc/doc_details',
			success: function(data){
				if(data.payee_details){
	        if(data.payee_details.designation == "3" || data.payee_details.designation == "4" ){
	          $("#unit_head_span").hide();
	          $("#unit_head").prop("disabled",true);
	          $(".dvch").hide();
	          $("#select_dvch").prop("disabled",true);
	          //show directors office signatory
	          $("#approval_span").show();
	          $("#select_d").prop("disabled",false);
	        //if AD or D remove initial and set RC to Director
	        }else if(data.payee_details.designation == "2" || data.payee_details.designation == "1" ){
	          $("#unit_head_span").hide();
	          $("#unit_head").prop("disabled",true);
	          $(".dvch").hide();
	          $("#select_dvch").prop("disabled",true);
	          $(".rc").hide();
	          $("#rc").prop("disabled",true);
	        }else if(data.payee_details.designation == "8" && data.payee_details.is_region == "1"){
	          $("#unit_head").val(data.payee_details.user_unit_head_sid).change();
	          $("#unit_head_span").show();
	          $("#unit_head").prop("disabled",false);
	          $("#unit_head").val();
	          $(".dvch").show();
	          $("#select_dvch").prop("disabled",false);
	          $(".rc").show();
	          $("#rc").prop("disabled",false);
	          //hide directors office signatory
	          $("#approval_span").hide();
	          $("#select_d").prop("disabled",true);
	        }else if(data.payee_details.designation == "6" && data.payee_details.is_region == "1"){
	          $("#unit_head_span").hide();
	          $("#unit_head").prop("disabled",true);
	          $(".dvch").show();
	          $("#select_dvch").prop("disabled",false);
	          $(".rc").show();
	          $("#rc").prop("disabled",false);
	          //hide directors office signatory
	          $("#approval_span").hide();
	          $("#select_d").prop("disabled",true);
	        }else if(jQuery.inArray(data.payee_details.designation, [8,7,6,5]) && data.payee_details.is_region == "0" && data.payee_details.division!="1"){
	          //hide unit head
	          $("#unit_head_span").hide();
	          $("#unit_head").prop("disabled",true);
	          $(".dvch").show();
	          $("#select_dvch").prop("disabled",false);
	          $(".rc").show();
	          $("#rc").prop("disabled",false);
	          //hide directors office signatory
	          $("#approval_span").hide();
	          $("#select_d").prop("disabled",true);
	        }else{
	          $("#unit_head_span").hide();
	          $("#unit_head").prop("disabled",true);
	          $(".dvch").show();
	          $("#select_dvch").prop("disabled",false);
	          $(".rc").show();
	          $("#rc").prop("disabled",false);
	          //show directors office signatory
	          $("#approval_span").show();
	          $("#select_d").prop("disabled",false);
	        }
	      }

        $.each(data.details, function(key, val) {
	      	$(".fieldname_id"+val.fieldname_id).val(val.value).change();
        })
        if(!already_signed){
	        $.each(data.signatories, function(key, val) {
	      		setTimeout(function(){
	      			//use ad_signatory id for unique select class and id
		      		$(`#sid${val.ads_id}`).val(val.sid).change();
			    	},200);
	        })
    		}
			}
		})

		$("#edit_details_modal").modal("show");
	    $('.daterangepicker_dynamic').daterangepicker({
	      // autoUpdateInput: false,
	      autoApply: true,
	      locale: {
	          format: 'MMMM D, YYYY'
	        }
	    });

	})

	$("#confirmEdit_btn").click(function(){
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: $('#form_update').serialize(),
			url: base_url+'Viewdoc/update',
			success: function(data){
				if(data){
					$("#document_details").html(data);
					$("#document_details").effect("highlight", {color: '#ADD8E6'}, 3000);
					$("#doc_details").val(data);
					$(".main_details_header").load(location.href + " .main_details_header");
					toastr.success("Details has been updated!");
					$("#edit_details_modal").modal("hide");
				}else{
					toastr.warning("Update Detail Not allowed! Already Signed by all signatories!");
				}
			}
		})
	})

	$(document).on("click","#download",function(){
		var type = this.getAttribute("type");
		var canvas = document.createElement("canvas");
		JsBarcode(canvas, dtsno, {format: "CODE128",width: 1,
                  height: 25,fontSize: 15});
		var img = canvas.toDataURL("image/png");
		$("#img").val(img)
		$("#todo").val(1)
		switch(type){
			case "107":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/ca_liquidation-${dtsno}.pdf`;
				link.download = `CA_Liquidation-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/ca_liquidation');
			}
			break;			
			case "117":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/ada-${dtsno}.pdf`;
				link.download = `CA_Liquidation-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/ada');
			}
			break;
			case "5":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/travel_order-${dtsno}.pdf`;
				link.download = `travel_order-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/travel_order');
			}
			break;
			case "2":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/dv-${dtsno}.pdf`;
				link.download = `dv-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/dv');
			}
			break;
			case "obr":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/obr-${dtsno}.pdf`;
				link.download = `obr-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/obr');
			}
			break;
			case "iot":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/iot-${dtsno}.pdf`;
				link.download = `iot-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/iot');
			}
			break;
			case "cotc":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/cotc-${dtsno}.pdf`;
				link.download = `cotc-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/cotc');
			}
			break;
			case "115":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/conc-${dtsno}.pdf`;
				link.download = `conc-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/conc');
			}
			break;
			case "travel_report":
			if(is_permanent==1){
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/travel_report-${dtsno}.pdf`;
				link.download = `travel_report-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/travel_report');
			}
			break;
			case "ors_burs":
			if(is_permanent==1){
				var ors_burs = this.getAttribute("ors_burs")=="ORS"?"ors":"burs"; 
				var link = document.createElement('a');
				link.href = `<?= base_url() ?>assets/pdf/approved/${ors_burs}-${dtsno}.pdf`;
				link.download = `${ors_burs}-${dtsno}.pdf`;
				link.click();
				link.remove();
			}else{
				var ors_burs = this.getAttribute("ors_burs")=="ORS"?"ors":"burs"; 
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/'+ors_burs);
			}
			break;
			default:
			$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/');
		}
		$('#form_submit').submit();
	})

	$(".content-wrapper").on("click",".print", function(){
		var type = this.getAttribute("type");
		var canvas = document.createElement("canvas");
		JsBarcode(canvas, dtsno, {format: "CODE128",width: 1,
                  height: 25,fontSize: 15});
		var img = canvas.toDataURL("image/png");
		$("#img").val(img)
		$("#todo").val(0)
		switch(type){
			//ADA
			case "117":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/ADA-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/ada');
			}
			break;
			//TO
			case "5":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/travel_order-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/travel_order');
			}
			break;
			//Liquidation of CA
			case "107":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/ca_liquidation-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/ca_liquidation');
			}
			break;
			//DV
			case "2":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/dv-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/dv');
			}
			break;
			case "51":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/obr-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/obr');
			}
			break;
			case "115":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/conc-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/conc');
			}
			break;
			case "obr":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/obr-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/obr');
			}
			break;
			case "iot":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/iot-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/iot');
			}
			break;
			case "cotc":
			if(is_permanent==1){
				window.open(`<?= base_url() ?>assets/pdf/approved/cotc-${dtsno}.pdf`);
			}else{
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/cotc');
			}
			break;
			case "travel_report":
				if(is_permanent==1){
					window.open(`<?= base_url() ?>assets/pdf/approved/travel_report-${dtsno}.pdf`);
				}else{
					$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/travel_report');
				}
			break;
			case "ors_burs":
				var ors_burs = this.getAttribute("ors_burs")=="ORS"?"ors":"burs"; 
				if(is_permanent==1){
					window.open(`<?= base_url() ?>assets/pdf/approved/${ors_burs}-${dtsno}.pdf`);
				}else{
					$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/'+ors_burs);
				}
			break;
			default:
				$("#form_submit").attr('action', '<?= base_url() ?>Pdf_generator/');
		}
		if(is_permanent==0){
			$('#form_submit').submit();
		}
	}) 
	$(".content-wrapper").on("click",".print_all", function(){
		if(is_permanent==1){
			var link = document.createElement('a');
			link.href = `<?= base_url() ?>assets/pdf/approved/MergedPDF-${dtsno}.pdf`;
			link.download = `allPdf-${dtsno}.pdf`;
			link.click();
			link.remove();
		}else{
			var type = this.getAttribute("type");
			var canvas = document.createElement("canvas");
			JsBarcode(canvas, dtsno, {format: "CODE128",width: 1,
	                  height: 25,fontSize: 15});
			var img = canvas.toDataURL("image/png");

			$("#todo").val(2)
		    $('#dts_body').addClass('disable_page');
		    $('#loader').show();
			setTimeout(function(){ 
				if(doc_type_id == 2){//if doc type is voucher
					$.ajax({
						type: "POST",
						dataType: "JSON",
						async: false,
						data: {todo:2,img:img,dtsno:dtsno},
						url: base_url+'Pdf_generator/dv',
						success: function(data){
						}
					})
				}
				if(doc_type_id == 107){//if doc type is liquidation of ca
					$.ajax({
						type: "POST",
						dataType: "JSON",
						async: false,
						data: {todo:2,img:img,dtsno:dtsno},
						url: base_url+'Pdf_generator/ca_liquidation',
						success: function(data){
						}
					})
				}
	      <?php 
	        if($linked_doc){ 
	          foreach($linked_doc as $val){
	    	?>
						var canvas_linked = document.createElement("canvas");
						JsBarcode(canvas, "<?= $val->linked_dtsno ?>", {format: "CODE128",width: 1,
				                  height: 25,fontSize: 15});
						var img_linked = canvas.toDataURL("image/png");		
	      <?php if($val->type == 5){?>
					$.ajax({
						type: "POST",
						dataType: "JSON",
						async: false,
						data: {todo:2,img:img_linked,dtsno:"<?= $val->linked_dtsno ?>"},
						url: base_url+'Pdf_generator/travel_order',
						success: function(data){
						}
					})
					<?php }
					if($val->type == 2){ ?>
					$.ajax({
						type: "POST",
						dataType: "JSON",
						async: false,
						data: {todo:2,img:img_linked,dtsno:"<?= $val->linked_dtsno ?>"},
						url: base_url+'Pdf_generator/dv',
						success: function(data){
						}
					})
					<?php }
					if($val->type == 107){ ?>
					$.ajax({
						type: "POST",
						dataType: "JSON",
						async: false,
						data: {todo:2,img:img_linked,dtsno:"<?= $val->linked_dtsno ?>"},
						url: base_url+'Pdf_generator/ca_liquidation',
						success: function(data){
						}
					})
					<?php } ?>
	    	<?php }
				  }
	  		?>
	      <?php 
	      if($ad_id){
		      foreach($ad_id as $val){
	      	?>
					$.ajax({
						type: "POST",
						dataType: "JSON",
						async: false,
						data: {todo:2,img:img,dtsno:dtsno},
						url: base_url+'Pdf_generator/<?= $val->pdf_link ?>',
						success: function(data){
						}
					})
				<?php }//end foreach ?>      
			<?php }//end if $ad_id?>      

				$.ajax({
					type: "POST",
					dataType: "JSON",
					async: false,
					data: {dtsno:dtsno,doc_type_id:doc_type_id,sub_type_id:sub_type_id},
					url: base_url+'Pdf_generator/mergepdf_gs',
					success: function(data){
						$("#form_download_all").attr('action', '<?= base_url() ?>Pdf_generator/download_mergedPdf');
						$('#form_download_all').submit();
					},
					complete : function(){
			          $('#dts_body').removeClass('disable_page');
					    document.getElementById("loader").style.display = "none"
					}
				})
			},100);
		}
	}) 

	$(".content-wrapper").on("click",".print_linked_docs", function(){
		var linked_dtsno = this.getAttribute("dtsno");
		var to_todo = this.getAttribute("to_todo");
		var canvas = document.createElement("canvas");
		var doc_type_id = this.getAttribute("doc_type_id");
		var sub_type_id = this.getAttribute("sub_type_id");
		$("#todo").val(2);
		$("#linked_dtsno").val(dtsno);

		JsBarcode(canvas, dtsno, {format: "CODE128",width: 1,
                  height: 25,fontSize: 15});
		var img = canvas.toDataURL("image/png");
		$("#to_img").val(img)
		$("#to_todo").val(to_todo)
		$("#to_dtsno").val(linked_dtsno)
		if(doc_type_id == 5){
			var url = `<?= base_url() ?>assets/pdf/approved/travel_order-${linked_dtsno}.pdf`;
			$.get(url)
	    .done(function() { 
				window.open(url);
	    }).fail(function() { 
				$("#form_to_pdf").attr('action', '<?= base_url() ?>Pdf_generator/travel_order');
				$('#form_to_pdf').submit();
	    })
		}
		if(doc_type_id == 2){
			var url = `<?= base_url() ?>assets/pdf/approved/dv-${linked_dtsno}.pdf`;
			$.get(url)
	    .done(function() { 
				window.open(url);
	    }).fail(function() { 
				$("#form_to_pdf").attr('action', '<?= base_url() ?>Pdf_generator/dv');
				$('#form_to_pdf').submit();
	    })
	  }
		if(doc_type_id == 107){
			var url = `<?= base_url() ?>assets/pdf/approved/ca_liquidation-${linked_dtsno}.pdf`;
			$.get(url)
	    .done(function() { 
				window.open(url);
	    }).fail(function() { 
				$("#form_to_pdf").attr('action', '<?= base_url() ?>Pdf_generator/ca_liquidation');
				$('#form_to_pdf').submit();
	    })
	  }
	  //   $('#dts_body').addClass('disable_page');
	  //   $('#loader').show();
			// setTimeout(function(){ 
			// 	$.ajax({
			// 		type: "POST",
			// 		dataType: "JSON",
			// 		async: false,
			// 		data: {todo:2,img:img,dtsno:dtsno},
			// 		url: base_url+'Pdf_generator/dv',
			// 		success: function(data){
			// 		}
			// 	})

			// 	$.ajax({
			// 		type: "POST",
			// 		dataType: "JSON",
			// 		async: false,
			// 		data: {todo:2,img:img,dtsno:dtsno},
			// 		url: base_url+'Pdf_generator/obr',
			// 		success: function(data){
			// 		}
			// 	})

			// 	$.ajax({
			// 		type: "POST",
			// 		dataType: "JSON",
			// 		async: false,
			// 		data: {todo:2,img:img,dtsno:dtsno},
			// 		url: base_url+'Pdf_generator/ors',
			// 		success: function(data){
			// 		}
			// 	})

			// 	$.ajax({
			// 		type: "POST",
			// 		dataType: "JSON",
			// 		async: false,
			// 		data: {todo:2,img:img,dtsno:dtsno},
			// 		url: base_url+'Pdf_generator/iot',
			// 		success: function(data){
			// 		}
			// 	})

			// 	$.ajax({
			// 		type: "POST",
			// 		dataType: "JSON",
			// 		async: false,
			// 		data: {dtsno:dtsno,sub_type_id:sub_type_id},
			// 		url: base_url+'Pdf_generator/mergepdf_gs',
			// 		success: function(data){
			// 			$("#form_download_all_linked").attr('action', '<?= base_url() ?>Pdf_generator/download_mergedPdf');
			// 			$('#form_download_all_linked').submit();
			// 		},
			// 		complete : function(){
			//           $('#dts_body').removeClass('disable_page');
			// 		    document.getElementById("loader").style.display = "none"
			// 		}
			// 	})
			// },100);
		// }
		// $('#form_to_pdf').submit();
	}) 

	$(".main_details_header").on("click","#view_audit_trail",function(){
    table.clear().draw();
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno},
			url: base_url+'Viewdoc/get_audit_trail',
			success: function(data){
				let details = "";
		        if(data != false){
		            $.each(data, function(i, val) {
    	            table.row.add([ val.fieldname, 
                      val.old_detail, 
                      val.new_detail, 
                      val.date_updated, 
                      val.updated_by, 
                    ]).draw( false );
		            });
		        }
				$("#audit_trail_modal").modal("show");
			}
		})
	})

	$("#attachment_div").on('click','.edit_upload',function(e){
		var fieldname = this.getAttribute("fieldname"); 
		var file_id = this.getAttribute("file_id");
		var old_file = this.getAttribute("old_file");
		$("#upload_file").val(null); 
		$("#upload_label").html(fieldname);
		$("#file_id").val(file_id);
		$("#old_file").val(old_file);
		$("#fieldname").val(fieldname);
		$("#upload_modal").modal("show");
	})


	$("#confirmUpload_btn").click(function(e){
        if($("#form_upload")[0].checkValidity()!=false){
	      e.preventDefault();
		    var form_data = new FormData($('#form_upload')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
		        contentType: false, 
		        processData: false, 
				url: base_url+'Viewdoc/reupload_file',
				success: function(data){
					if(data.status == 0){
						$("#file"+data.id).html(`${data.fieldname}: 
		                <a href="#" id="edit_upload" fieldname="${data.fieldname}"  file_id="${data.id}" class="edit_upload">
		                    <span class="label label-warning pull-right" style="font-size:100% !important">
		                        Edit <i class="fa fa-edit"></i>
		                    </span>
		                </a>
						<a href="${data.href}" target="_blank">
		                  <span class="input-group-addon active" style="text-align: left !important;"><i class="fa fa-download"></i> 
		                    ${data.filename}
		                  </span>
		                </a>
                	`)
						$("#file"+data.id).effect("highlight", {color: '#ADD8E6'}, 3000);
					}else{
						$("#general_file").html(`Attached File: 
		                <a href="#" id="edit_upload" fieldname=""  file_id="" class="edit_upload">
		                    <span class="label label-warning pull-right" style="font-size:100% !important">
		                        Edit <i class="fa fa-edit"></i>
		                    </span>
		                </a>
						<a href="${data.href}" target="_blank">
		                  <span class="input-group-addon active" style="text-align: left !important;"><i class="fa fa-download"></i> 
		                    ${data.filename}
		                  </span>
		                </a>
                	`)
						$("#general_file").effect("highlight", {color: '#ADD8E6'}, 3000);
					}

					$("#upload_modal").modal("hide");
				}
			})
		}
	})

	$("#linked_doc_tbody").on("click",".edit_linked_doc", function(){
		var id = this.getAttribute('id');
		var type = this.getAttribute('type');
		var fieldname = this.getAttribute('fieldname');
		var linked_dtsno = this.getAttribute('linked_dtsno');
		var employee_id = this.getAttribute('employee_id');
		$("#linked_employee_id").val(employee_id);
		$("#linked_doc_type").val(type);
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {type:type,sub_type_id:sub_type_id,dtsno:dtsno,employee_id:employee_id},
			url: base_url+'Viewdoc/linked_doc_data',
			success: function(data){
				$("#linked_id").val(id);
				$("#linked_label").html(fieldname);
				var ItemArray = [];
        $.each(data, function(i, val) {
        	if(doc_type_id == 107){
        		var details = val.details;
        	}else if(doc_type_id == 117){
        		var details = val.approved_number;
        	}else{
        		var details = val.date_of_travel;
        	}

					ItemArray.push({
				    id : val.dtsno, 
				    text : `${val.dtsno} - ${details}`
					});
        });
        $("#linked_id").val(id);
      	$("#select2_linked_doc").html('').select2({data: ItemArray});
      	$("#select2_linked_doc").val(linked_dtsno).change();
				$("#edit_linked_doc_modal").modal("show");
			}
		})
	})

	$("#linked_doc_tbody").on("click",".delete_linked_doc", function(){
		var id = this.getAttribute('id');
		var linked_dtsno = this.getAttribute('linked_dtsno');
		$("#delete_linked_id").val(id);
		$("#linked_dtsno_title").html(linked_dtsno);
		$("#delete_linked_doc_modal").modal("show");
	})

	$(document).on("click","#create_iot",function(){
		$("#iot_todo").val("add");
		$("#iot_modal").modal("show");
	})
	
	$("#copy_iot").click(function(){

	$('#iot_tb tbody tr:last').clone().insertAfter('#iot_tb tbody tr:last');
	  $( ".datepicker_iot" ).removeClass('hasDatepicker').removeData('datepicker').unbind().datepicker({
	    //changeYear:true,
	    changeMonth: true,
	    minDate: iot_date_from,
	    maxDate: iot_date_to,
	    dateFormat: 'yy-mm-dd'
    });
	})

	
	$("#add_iot").click(function(){
		var $tableBody = $('#iot_tb').find("tbody");
		var travel_duration = $("#travel_duration").val();
		$trLast = $tableBody.find("tr:last");
		// $trNew = $trLast.clone();
		var readonly = travel_duration!=""?"":"readonly";
		var tr = `<tr>
                <td>
                  <input type="text" name="date[]" class="form-control datepicker_iot" required="required" ${readonly}>
                </td>
                <td>
                  <input type="text" name="place[]" id="place" class="form-control" required="required">
                </td>
                <td>
                  <input type="time" name="departure[]" id="departure" class="form-control">
                </td>
                <td>
                  <input type="time" name="arrival[]" id="arrival" class="form-control">
                </td>
                <td>
                  <input type="text" name="means_transpo[]" id="means_transpo" class="form-control" required="required" value="">
                </td>
                <td>
                  <input type="text" name="transpo[]" id="transpo" value="0" class="form-control">
                </td>
                <td>
                  <input type="text" name="per_diem[]" id="per_diem" class="form-control" required="required">
                </td>
                <td>
                  <input type="text" name="others[]" id="others" class="form-control">
                </td>
              </tr>`;
		$trLast.after(tr);
    $( ".datepicker_iot" ).datepicker({
    //changeYear:true,
    changeMonth: true,
    minDate: iot_date_from,
    maxDate: iot_date_to,
    dateFormat: 'yy-mm-dd'
    });
	})

	$("#remove_iot").click(function(){
		var num = $('#iot_tb tr').length;
		if(num >2){
			var $tableBody = $('#iot_tb').find("tbody");
			$trLast = $tableBody.find("tr:last").remove();
		}else{
			alert("Itinerary Cannot be Empty!");
		}
	})

	$("#form_iot").on("submit", function (e) {
  	    if($("#form_iot")[0].checkValidity()!=false){
	      e.preventDefault();
		    var form_data = new FormData($('#form_iot')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
				url: base_url+'Viewdoc/add_iot',
		        contentType: false, 
		        processData: false, 
				success: function(data){
					if(data.error == 0){
						var action = `
					                    <a href="#!" id="view_iot" class="print"  type="iot">
					                      <span class="label label-success pull-right" style="font-size:100% !important">Pdf
					                      <i class="fa fa-file-pdf-o"></i></span>
					                    </a>  
										<a href="#!" id="edit_iot">
					                      <span class="label label-warning pull-right" style="font-size:100% !important">Edit
					                      <i class="fa fa-edit"></i></span>
					                    </a>    
										`;
						var action_cotc = `
					                    <a href="#!" id="view_iot" class="print"  type="cotc">
					                      <span class="label label-success pull-right" style="font-size:100% !important">Pdf
					                      <i class="fa fa-file-pdf-o"></i></span>
					                    </a>  
										`;
						// $("#iot_detail").html(data.travel_duration);
						// $("#iot_action").html(action);
						$("#other_req_tb").load(location.href + " #other_req_tb");
						$("#iot_modal").modal("hide");
						// $("#cotc_detail").html(data.official_station);
						// $("#cotc_action").html(action_cotc);
						// $("#iot_tr").removeClass("tr_red");
						// $("#cotc_tr").removeClass("tr_red");
						setTimeout(function(){ 
						$("#iot_detail").closest("tr").effect("highlight", {color: '#ADD8E6'}, 3000).focus();
						$("#cotc_detail").closest("tr").effect("highlight", {color: '#ADD8E6'}, 3000).focus();
						},200);
					}else{
		        toastr.warning(`Itenerary of travel already exist! Cannot add duplicate ${data.duplicate_date}`);
					}
				}
			});
		}
	})

	$("#other_req_tb").on("click","#edit_iot",function(){
		$("#iot_todo").val("update");
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno},
			url: base_url+'Viewdoc/get_iot_details',
			success: function(data){
				var tr = "";
				$("#condition_no").val(data.cotc.condition_no).change();
				$("#explanation").val(data.cotc.explanation);
				$("#evidence").val(data.cotc.evidence);
				$("#entity_name").val(data.iot_main.entity_name);
				$("#fund_cluster").val(data.iot_main.fund_cluster);
				$("#iot_uid").val(data.iot_main.uid);
				$("#official_station").val(data.iot_main.official_station);
				$("#travel_duration").val(data.iot_main.travel_duration);
				$("#purpose").val(data.iot_main.purpose);
				$("#amount_cotc").val(data.cotc.amount);
				$("#or_no").val(data.cotc.or_no);
				$("#date_cotc").val(data.cotc.date);
				$.each(data.iot_details, function(i, val) {
					tr += `<tr>
		                <td>
		                  <input type="hidden" name="iot_id[]" id="iot_id" class="form-control datepicker" value="${val.id}">
		                  <input type="text" name="date[]" class="form-control datepicker_iot" required="required" value="${val.date}">
		                </td>
		                <td>
		                  <input type="text" name="place[]" id="place" class="form-control" required="required" value="${val.place}">
		                </td>
		                <td>
		                  <input type="time" name="departure[]" id="departure" class="form-control"  value="${val.departure}">
		                </td>
		                <td>
		                  <input type="time" name="arrival[]" id="arrival" class="form-control" value="${val.arrival}">
		                </td>
		                <td>
		                  <input type="text" name="means_transpo[]" id="means_transpo" class="form-control" required="required" value="${val.means_transpo}">
		                </td>
		                <td>
		                  <input type="number" name="transpo[]" id="transpo" class="form-control" value="${val.transpo}">
		                </td>
		                <td>
		                  <input type="text" name="per_diem[]" id="per_diem" class="form-control" required="required" value="${val.per_diem}">
		                </td>
		                <td>
		                  <input type="text" name="others[]" id="others" class="form-control" value="${val.others}">
		                </td>
	              	</tr>`;
				})
				$("#tbody_iot").html(tr);
				data.iot_main.travel_duration
				$(".datepicker_iot").datepicker({
		    	setDate: "",
		    //changeYear:true,
		    changeMonth: true,
		    minDate: data.from,
		    maxDate: data.to,
		    dateFormat: 'yy-mm-dd'
		    });
				$(".datepicker_iot").datepicker( "refresh" );
			}
		});

		$("#iot_modal").modal("show");
	})

	$(document).on("click","#create_obr",function(){
		$("#obr_todo").val("add");
		$("#obr_modal").modal("show");
	})

	$("#form_obr").on("submit", function (e) {
        if($("#form_obr")[0].checkValidity()!=false){
	      e.preventDefault();
		    var form_data = new FormData($('#form_obr')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
				url: base_url+'Viewdoc/add_obr',
		        contentType: false, 
		        processData: false, 
				success: function(data){
					if(data.error == 0){
						var action = `
					                    <a href="#!" id="view_iot" class="print"  type="obr">
					                      <span class="label label-success pull-right" style="font-size:100% !important">Pdf
					                      <i class="fa fa-file-pdf-o"></i></span>
					                    </a>  
										<a href="#!" id="edit_obr">
					                      <span class="label label-warning pull-right" style="font-size:100% !important">Edit
					                      <i class="fa fa-edit"></i></span>
					                    </a>    
										`;
						// $("#obr_detail").html(data.particulars);
						// $("#obr_action").html(action);
						$("#other_req_tb").load(location.href + " #other_req_tb");
						$("#obr_modal").modal("hide");
						setTimeout(function(){ 
						$("#obr_tr").removeClass("tr_red");
						$("#obr_detail").closest("tr").effect("highlight", {color: '#ADD8E6'}, 3000).focus();
						},200);
					}else{
          	toastr.warning("Something Went Wrong. Try Again and make sure to fill up all required field.");
					}
				}
			});
		}
	})

	$("#other_req_tb").on("click","#edit_obr",function(){
		$("#obr_todo").val("update");
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno},
			url: base_url+'Viewdoc/get_obr_details',
			success: function(data){
				var tr = "";
				$("#particulars").val(data.obr_main.particulars);
				$("#funding_source").val(data.obr_main.funding_source).change();
				$("#funding_source_code").val(data.obr_main.funding_source_code);
				$("#fund_cluster").val(data.obr_main.fund_cluster);
				$("#address").val(data.obr_main.address);
				$("#obr_date").val(data.obr_main.date);
				$("#certifier").val(data.certifier.sid).change();
				$.each(data.obr_details, function(i, val) {
					var disable_rc = `<?= $userdata->unit_id == "19" || $first_track->sub_type == 106 || $first_track->sub_type == 118?"":"readonly"; ?>`;
					tr += `<tr>
		                <td>
		                  <input type="hidden" name="obr_id_tb[]" id="obr_id_tb" class="form-control" value="${val.id}">
		                  <select class="select2_obr rc_desc" name="rc_desc[]" required ${disable_rc}>
		                    <option value="${val.rc_desc}" code="${val.rc_code}" selected>${val.rc_desc} (${val.rc_code}) </option>
		                    <?php foreach($rc as $val){
		                      echo "<option value='{$val->description}' code='{$val->code}'>{$val->description} ({$val->code})</option>";
		                    }
		                    ?>
		                  </select>
		                  <input type="hidden" name="rc_code[]" id="rc_code" class="form-control rc_code" required="required" value="${val.rc_code}" readonly>
		                </td>
		                <td>
		                  <select class="select2_obr prexc" name="prexc[]" required>
		                    <option value="${val.prexc}" code="${val.prexc}" selected>${val.prexc}</option>
		                    <?php foreach($prexc as $val){ 
		                      echo "<option value='{$val->code}' code='{$val->code}'>{$val->description}({$val->code})</option>";
		                    }
		                    ?>
		                  </select>                
		                </td>
		                <td>
		                  <select class="select2_obr uacs_desc" name="uacs_desc[]" required>
		                    <option value="${val.uacs_desc}" code="${val.uacs_code}" selected>${val.uacs_desc}</option>
		                    <?php foreach($uacs as $val){
		                      echo "<option value='{$val->description}' code='{$val->code}'>{$val->description}</option>";
		                    }
		                    ?>
		                  </select>
		                  <input type="hidden" name="uacs_code[]" id="uacs_code" class="form-control uacs_code" required="required" value="${val.uacs_code}" readonly>
		                </td>
		                <td>
		                  <input type="text" name="amount[]" id="obr_amount" class="form-control" required="required" value="${val.amount}">
		                </td>
	              	</tr>`;
				})
				$("#tbody_obr").html(tr);
			    $('.datepicker_dynamic').datepicker({ 
	      			dateFormat: 'yy-mm-dd', 
			    })
			    $(".select2_obr").select2();

			}
		});

		$("#obr_modal").modal("show");
	})

	$("#add_obr").click(function(){
		var $tableBody = $('#obr_tb').find("tbody");
		$trLast = $tableBody.find("tr:last");
		// $trNew = $trLast.clone();
				var tr = `<tr>
		                <td>
		                  <input type="hidden" name="obr_id_tb[]" id="obr_id_tb" class="form-control" value="">
		                  <select class="select2_obr rc_desc" name="rc_desc[]" required>
		                    <?php foreach($rc as $val){
		                      echo "<option value='{$val->description}' code='{$val->code}'>{$val->description} ({$val->code})</option>";
		                    }
		                    ?>
		                  </select>
		                  <input type="hidden" name="rc_code[]" id="rc_code" class="form-control rc_code" required="required" value="" readonly>
		                </td>
		                <td>
		                  <select class="select2_obr prexc" name="prexc[]" required>
		                    <?php foreach($prexc as $val){ 
		                      echo "<option value='{$val->code}' code='{$val->code}'>{$val->description}({$val->code})</option>";
		                    }
		                    ?>
		                  </select>                
		                </td>
		                <td>
		                  <select class="select2_obr uacs_desc" name="uacs_desc[]" required>
		                    <?php foreach($uacs as $val){
		                      echo "<option value='{$val->description}' code='{$val->code}'>{$val->description}</option>";
		                    }
		                    ?>
		                  </select>
		                  <input type="hidden" name="uacs_code[]" id="uacs_code" class="form-control uacs_code" required="required" value="" readonly>
		                </td>
		                <td>
		                  <input type="text" name="amount[]" id="obr_amount" class="form-control" required="required" value="">
		                </td>
	              	</tr>`;
		$trLast.after(tr);
		$(".select2_obr").select2();
	})

	$("#remove_obr").click(function(){
		var num = $('#obr_tb tr').length;
		if(num >2){
			var $tableBody = $('#obr_tb').find("tbody");
			$trLast = $tableBody.find("tr:last").remove();
		}else{
			alert("Itinerary Cannot be Empty!");
		}
	})

  $(".content").on('click','.sign_docs',function(){
    $('#sign_docs_modal').modal("show");
  })

  $("#confirm_sign_btn").click(function(){
    var dtsno = $("#dtsno").val();
    var date_signed = $("#date_signed").val();
    $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {dtsno:dtsno,date_signed:date_signed},
      url: base_url+'Signatory/embed_signature',
      success: function(data){
        if(data.details!=false){
          check_alerts();
          $('#confirm_modal').modal("hide");
          if(data.is_approved){
          	generate_permanent_pdf();
          }else{
         	 window.location.replace("<?php echo base_url(); ?>Document/"+dtsno);
        	}
        }else{
          check_alerts();
          $('#confirm_modal').modal("hide");
          toastr.warning("Document may have been removed for E-Signature / E-Initial");
        }
      }
    })
  })

  $("#generate_permanent_pdf").click(function(){
    $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {dtsno:dtsno},
      url: base_url+'Viewdoc/generate_permanent_pdf',
      success: function(data){
      	generate_permanent_pdf();
	     	// window.location.replace("<?php echo base_url(); ?>Document/"+dtsno);
      }
    })
  })

  $("#checklist").click(function(){
    $('#tev_checklist_modal').modal("show");
  })

  $("#tev_checklist_modal").on("click",".add_remarks",function(){
  	var checklist_id = this.getAttribute("checklist_id");
  	var checklist = this.getAttribute("checklist");
  	$("#checklist_id").val(checklist_id);
  	$("#checklist_remarks").val("");
  	$("#checklist_label").html(checklist);
    $('#remarks_modal').modal("show");
  })

  $("#add_remarks_btn").click(function(){
  	var tev_checklist_id = $("#checklist_id").val();
  	var checklist_remarks = $("#checklist_remarks").val();
    $.ajax({
      type: "POST",
      dataType: "JSON",
      data: {tev_checklist_id:tev_checklist_id,checklist_remarks:checklist_remarks,dtsno:dtsno},
      url: base_url+'Viewdoc/add_tev_remarks',
      success: function(data){
      	var html = `<hr class="nm">${data.remarks} <br><small><strong>- ${data.added_by} (${data.date_added}</strong></small>)
      						`;
      	$("#tev_remarks"+data.tev_checklist_id).append(html);
        toastr.success("TEV Remark has been added!");
		    $('#remarks_modal').modal("hide");
      }
    })
  })

  $(document).on("click",".add_travel_report",function(){
  	$("#form_tr")[0].reset();
		$("#travel_report_todo").val("add");
  	$("#add_travel_report_modal").modal("show");
  })
	$("#form_tr").on("submit", function (e) {
      if($("#form_tr")[0].checkValidity()!=false){
      e.preventDefault();
	    var form_data = new FormData($('#form_tr')[0]);
	    $('#dts_body').addClass('disable_page');
	    $('#loader').show();
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
				url: base_url+'Viewdoc/add_travel_report',
		        contentType: false, 
		        processData: false, 
				success: function(data){
					if(data.error==0){
						var action = `
		                    <a href="#!" class="print"  type="travel_report">
		                      <span class="label label-success pull-right" style="font-size:100% !important">Pdf
		                      <i class="fa fa-file-pdf-o"></i></span>
		                    </a>  
							<a href="#!" id="view_travel_report">
		                      <span class="label label-warning pull-right" style="font-size:100% !important">Edit
		                      <i class="fa fa-edit"></i></span>
		                    </a>    
							`;
							// $("#travel_report_detail").html(data.purpose);
							// $("#travel_report_action").html(action);
							$("#other_req_tb").load(location.href + " #other_req_tb");
							setTimeout(function(){ 
							$("#travel_report_tr").removeClass("tr_red");
							toastr.success("Travel Report Details has been updated!");
							$("#travel_report_detail").closest("tr").effect("highlight", {color: '#ADD8E6'}, 3000).focus();
							},200);
						}else{
						toastr.warning("Cannot delete all records!");
					}
					$("#add_travel_report_modal").modal("hide");
					travel_order();
				},
				complete: function(){
			    $('#dts_body').removeClass('disable_page');
					$('#loader').hide();
				}
			})
		}
	})
	function travel_order(){
	    tr_tb.clear().draw();
	    $.ajax({
	      type: "POST",
	      dataType: "JSON",
	      data: {dtsno:dtsno},
	      url: base_url+'Viewdoc/get_travel_report',
	      success: function(data){
	      	var tbody = "";
	      	$.each(data, function(i,val){
	      		var img = val.attached_file!=""?`<img src="${base_url}assets/uploads/travel_report/${val.attached_file}" style="width:400px">`:"No Uploaded Image";
	      		var img2 = val.attached_file2!=""?`<img src="${base_url}assets/uploads/travel_report/${val.attached_file2}" style="width:400px">`:"No Uploaded Image";
	      		var nextpage = (val.is_nextpage == 1)?"Yes":"No";
	      		tbody = `<table>
	          <tr>
	            <td colspan="2" class="border_btm">
	              <a href="#"
	              todo="delete" 
	              traveL_report_id="${val.id}"  
	              dot="${val.dot}"  
	              travel_report_purpose="${val.purpose}"  
	              travel_report_destination="${val.destination}"  
	              travel_report_accomplishment="${val.accomplishment}"  
	              is_nextpage="${val.is_nextpage}"  
	              caption="${val.caption}"  
	              caption2="${val.caption2}"  
	              class="btn btn-header pull-right update_travel_report">
	                <span class="label bg bg-red" style="font-size:100% !important">
	                    DELETE <i class="fa fa-trash"></i>
	                </span>
	              </a>
	              <a href="#" 
	              todo="update" 
	              traveL_report_id="${val.id}"  
	              dot="${val.dot}"  
	              travel_report_purpose="${val.purpose}"  
	              travel_report_destination="${val.destination}"  
	              travel_report_accomplishment="${val.accomplishment}"  
	              is_nextpage="${val.is_nextpage}" 
	              caption="${val.caption}"  
	              caption2="${val.caption2}"  
	              class="btn btn-header pull-right update_travel_report">
	                <span class="label bg bg-yellow" style="font-size:100% !important">
	                    UPDATE <i class="fa fa-edit"></i>
	                </span>
	              </a>	              
	            </td>
	          </tr>
	      		<tr>
	            <td><label>Date of travel</label></td>
	            <td>${val.dot}</td>
	          </tr>
	          <tr>
	            <td><label>Purpose of Travel</label></td>
	            <td>${val.purpose}</td>
	          </tr>
	          <tr>
	            <td><label>Destination</label></td>
	            <td>${val.destination}</td>
	          </tr>
	          <tr>
	            <td><label>Accomplishment Report</label></td>
	            <td>${val.accomplishment}</td>
	          </tr>
	          <tr>
	            <td><label>Set to next page?</label></td>
	            <td>${nextpage}</td>
	          </tr>
	          <tr>
	          	<td><label>Uploaded Image:</label></td>
	          	<td>${img}</td>
	          </tr>
	          <tr>
	          	<td><label>Image Caption:</label></td>
	          	<td>${val.caption}</td>
	          </tr>
	          <tr>
	          	<td><label>Uploaded Image:</label></td>
	          	<td>${img2}</td>
	          </tr>
	          <tr>
	          	<td><label>Image Caption:</label></td>
	          	<td>${val.caption2}</td>
	          </tr>
	          </table>`;
          tr_tb.row.add([tbody]).draw( false );	      	
	      	})
	   		$("#view_travel_report_modal").modal("show");
	   		}
	   	});
	}
	$("#other_req_tb").on("click","#view_travel_report",function(){
		travel_order();
	})

	$("#view_travel_report_modal").on("click",".update_travel_report",function(){
		var todo = this.getAttribute("todo");
		var travel_report_id = this.getAttribute("travel_report_id");
		var dot = this.getAttribute("dot");
		var purpose = this.getAttribute("travel_report_purpose");
		var destination = this.getAttribute("travel_report_destination");
		var accomplishment = this.getAttribute("travel_report_accomplishment");
		var is_nextpage = this.getAttribute("is_nextpage");
		var caption = this.getAttribute("caption");
		var caption2 = this.getAttribute("caption2");
		$("#travel_report_todo").val(todo);
		$("#travel_report_id").val(travel_report_id);
		$("#dot").val(dot);
		$("#tr_purpose").val(purpose);
		$("#tr_destination").val(destination);
		$("#tr_accomplishment").val(accomplishment);
		$("#is_nextpage").val(is_nextpage).change();
		$("#caption").val(caption);
		$("#caption2").val(caption2);
		$("#tr_image").val("");
  	$("#add_travel_report_modal").modal("show");
	})

	$("#view_travel_report_modal").on("click",".upload_img",function(){
		dot = this.getAttribute("dot");
		traveL_report_id = this.getAttribute("traveL_report_id");
		$("#tr_img_header").html(dot);
		$("#tr_id_img").val(traveL_report_id);
		$("#add_travel_report_img_modal").modal("show");
	})

	$("#condition_no").change(function(){
		var val = $(this).val();
		if(val == 2){
			$("#cut_short").removeClass("hideme");
			$("#amount_cotc").prop("required",true);
			$("#or_no").prop("required",true);
			$("#date_cotc").prop("required",true);
		}else{
			$("#cut_short").addClass("hideme");
			$("#amount_cotc").prop("required",false);
			$("#or_no").prop("required",false)
			$("#date_cotc").prop("required",false)
		}
	})
	$("#acc_ent_liq").click(function(){
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno},
			url: base_url+'Viewdoc/get_accounting_entry_liq',
			success: function(data){
				if(data){
					$("#acc_ent_liq_id").val(data[0].id);
					$("#serial_no").val(data[0].serial_no);
					$("#jev_no").val(data[0].jev_no);
					$("#acc_entry_liq_modal").modal("show");
				}
			}
		})
	})
	$("#acc_ent").click(function(){
    acc_ent_tb.clear().draw();
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno},
			url: base_url+'Viewdoc/get_accounting_entry',
			success: function(data){
				if(data){
					$.each(data, function(i, val) {
  	            acc_ent_tb.row.add([ val.account_title, 
                    val.uacs_code, 
                    val.debit, 
                    val.credit, 
                    `<a href="#!" class="edit_acc_ent" 
                    accounting_entry_id = "${val.accounting_entry_id}"
                    acc_ent_id="${val.id}"
                    account_title="${val.account_title}"
                    uacs_code="${val.uacs_code}"
                    debit="${val.debit}"
                    credit="${val.credit}"
                    ><i class="fa fa-edit"></i></a>`, 
                  ]).draw( false );
          })
				}
  		}
		});
		$("#add_accounting_entry_modal").modal("show");
	})
	$("#form_acc_ent_liq").on("submit", function (e) {
    if($("#form_acc_ent_liq")[0].checkValidity()!=false){
	    e.preventDefault();
	    var form_data = new FormData($('#form_acc_ent_liq')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
				url: base_url+'General/update',
        contentType: false, 
        processData: false, 
				success: function(data){
					if(data){
						$("#acc_entry_liq_modal").modal("hide");
						toastr.success("Accounting Entry Has been added / Updated!");
					}else{
						toastr.warning("Error updating data!");
					}
    		}
  		});
		}
	})

	$("#form_acc_ent").on("submit", function (e) {
    if($("#form_acc_ent")[0].checkValidity()!=false){
	    e.preventDefault();
	    var form_data = new FormData($('#form_acc_ent')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
				url: base_url+'Viewdoc/add_accounting_entry',
		        contentType: false, 
		        processData: false, 
				success: function(data){
					if(data.error==0){
						$("#acc_ent_id").val("");
						form_acc_ent.reset();
				    acc_ent_tb.clear().draw();
						$.each(data.list, function(i, val) {
    	            acc_ent_tb.row.add([ val.account_title, 
                      val.uacs_code, 
                      val.debit, 
                      val.credit, 
                      `<a href="#!" class="edit_acc_ent" 
	                    accounting_entry_id = "${val.accounting_entry_id}"
                      acc_ent_id="${val.id}"
                      account_title="${val.account_title}"
                      uacs_code="${val.uacs_code}"
                      debit="${val.debit}"
                      credit="${val.credit}"
                      ><i class="fa fa-edit"></i></a>`, 
                    ]).draw( false );
	          })
						toastr.success(data.message);
					}else{
						toastr.warning(data.message);
					}
    		}
  		});
		}
	})

	$("#acc_ent_tb").on("click",".edit_acc_ent",function(e){
		$("#acc_ent_id").val(this.getAttribute("acc_ent_id"));
		$("#account_title").val(this.getAttribute("accounting_entry_id")).change();
		$("#account_title_desc").val(this.getAttribute("account_title"));
		$("#auacs_code").val(this.getAttribute("uacs_code"));
		$("#debit").val(this.getAttribute("debit"));
		$("#credit").val(this.getAttribute("credit"));
	})

	$("#account_title").change(function(){
		var account_title_desc = $('option:selected', this).attr('account_title');
		$("#account_title_desc").val(account_title_desc);
	})

	$("#funding_source").change(function(){
		$("#funding_source_code").val($('option:selected', this).attr('code'));
		$("#fund_cluster_obr").val($('option:selected', this).attr('fund_cluster'));
		$("#ors_burs_obr").val($('option:selected', this).attr('ors_burs'));
		$("#funding_source_id").val($('option:selected', this).attr('funding_source_id'));
		$("#mds").val($('option:selected', this).attr('mds'));
		$("#nca").val($('option:selected', this).attr('nca'));
	})

	$("#add_ors").click(function(){
		var ors_burs = this.getAttribute("ors_burs"); 
		$(".ors_burs").val(ors_burs);
		if(ors_burs == "ORS"){
			$("#yoi_div").addClass("hideme");
			$("#payable_div").addClass("hideme");
			$("#payment_div").addClass("hideme");
			$("#nyd_div").addClass("hideme");
			$("#yoi").prop("required",false);
			$("#yoi").prop("disabled",true);
			$("#add_ors_modal").modal("show");
		}else{
			$("#yoi_div").removeClass("hideme");
			$("#payable_div").removeClass("hideme");
			$("#payment_div").removeClass("hideme");
			$("#nyd").removeClass("hideme");
			$("#yoi").prop("required",true);
			$("#yoi").prop("disabled",false);
			$("#add_ors_modal").modal("show");
		}
	})

	$("#form_ors").on("submit", function (e) {
    if($("#form_ors")[0].checkValidity()!=false){
	    e.preventDefault();
	    var form_data = new FormData($('#form_ors')[0]);
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
				url: base_url+'Viewdoc/add_ors',
        contentType: false, 
        processData: false, 
				success: function(data){
					if(data.error == 0){
						var yoi = (data.data.yoi!=null)?`<br>Year of Implementation: ${data.data.yoi}`:"";
						$("#ors_tr").removeClass("tr_red");
						$("#ors_detail").html(`Date: ${data.data.date}<br>${data.data.ors_burs} No.: ${data.data.ors_burs_no} ${yoi}`);
						$("#ors_action").html(`
			                      <a href="#!" id="" class="print" type="ors_burs" ors_burs="${data.data.ors_burs}">
			                        <span class="label label-success pull-right" style="font-size:100% !important">Pdf
			                        <i class="fa fa-file-pdf-o"></i></span>
			                      </a>
			                      <a href="#" id="download" type="ors_burs" ors_burs="${data.data.ors_burs}" class="btn btn-header pull-right " >
			                        <span class="label label-primary pull-right" style="font-size:100% !important" >
			                            Download <i class="fa fa-download"></i>
			                        </span>
			                      </a>
														<a href="#!" id="edit_ors_burs" 
                            class="btn btn-header pull-right" 
                            allotment_class="${data.allotment_class}" 
                            ors_burs_id="${data.id}" 
                            ors_burs_date="${data.data.date}" 
                            ors_burs_no="${data.data.ors_burs_no}" 
                            yoi="${data.data.yoi}" 
                            payable="${data.data.payable}" 
                            payment="${data.data.payment}" 
                            nyd="${data.data.nyd}" 
                            ors_burs="${data.data.ors_burs}" 
                            >
                              <span class="label label-warning pull-right" style="font-size:85% !important">Edit
                              <i class="fa fa-edit"></i></span>
                            </a> `);
						$("#add_ors_modal").modal("hide");
						$(".fma").removeClass("disabled");
					}else{
						toastr.warning("ORS / BURS No. Already Existed!");
					}
				}
			})
		}
	})

	$("#ors_tr").on("click","#edit_ors_burs", function(){
		var allotment_class = this.getAttribute("allotment_class"); 
		var ors_burs = this.getAttribute("ors_burs"); 
		var ors_burs_id = this.getAttribute("ors_burs_id"); 
		var date = this.getAttribute("ors_burs_date"); 
		var ors_burs_no = this.getAttribute("ors_burs_no"); 
		var yoi = this.getAttribute("yoi"); 
		$("#allotment_class").val(allotment_class).change();
		$(".ors_burs").val(ors_burs);
		$("#ors_burs_id").val(ors_burs_id);
		$("#ors_burs_date").val(date);
		$("#ors_burs_no").val(ors_burs_no);
		if(ors_burs == "ORS"){
			$("#yoi_div").addClass("hideme");
			$("#payable_div").addClass("hideme");
			$("#payment_div").addClass("hideme");
			$("#nyd_div").addClass("hideme");
			$("#yoi").prop("required",false);
			$("#yoi").prop("disabled",true);
			$("#add_ors_modal").modal("show");
		}else{
			var payable = this.getAttribute("payable"); 
			var payment = this.getAttribute("payment"); 
			var nyd = this.getAttribute("nyd"); 
			$("#yoi_div").removeClass("hideme");
			$("#payable_div").removeClass("hideme");
			$("#payment_div").removeClass("hideme");
			$("#nyd").removeClass("hideme");
			$("#yoi").prop("required",true);
			$("#yoi").prop("disabled",false);
			$("#add_ors_modal").modal("show");
		}

	})

	$(".edit_track").click(function(){
		$("#tracker_id").val(this.getAttribute("tracker_id")).change();
		$("#div_id_edit").val(this.getAttribute("to_div_id")).change();
		$("#unit_id_edit").val(this.getAttribute("to_unit_id")).change();
		$("#action_req_edit").val(this.getAttribute("action_req"));
		$("#edit_track_modal").modal("show");
	})

 $('#travel_duration').on('apply.daterangepicker', function(ev, picker) {
    $(this).val(picker.startDate.format('Y-MM-DD') + ' - ' + picker.endDate.format('Y-MM-DD'));
    iot_date_from = picker.startDate.format('Y-MM-D');
    iot_date_to = picker.endDate.format('Y-MM-D');
    $(".datepicker_iot").prop("readonly",false);
    $('.datepicker_iot').val("");
		$(".datepicker_iot").datepicker('destroy');
    $(".datepicker_iot").datepicker({
    	setDate: "",
    //changeYear:true,
    changeMonth: true,
    minDate: iot_date_from,
    maxDate: iot_date_to,
    dateFormat: 'yy-mm-dd'
    });
	$(".datepicker_iot").datepicker( "refresh" );
  });

 $("#obr_modal").on("change",".rc_desc", function(){
 	$(this).closest('tr').find('.rc_code').val($('option:selected', this).attr('code'));
 })

 $("#obr_modal").on("change",".uacs_desc", function(){
 	$(this).closest('tr').find('.uacs_code').val($('option:selected', this).attr('code'));
 })

	$(".select2_obr").select2();

	$("#user_ent").click(function(){
		$.ajax({
			type: "POST",
			dataType: "JSON",
			data: {dtsno:dtsno},
			url: base_url+'Viewdoc/get_ca_liquidation',
			success: function(data){
				if(data){
					$("#or_no_liq").val(data[0].or_no);
					$("#or_date").val(data[0].or_date);
					$("#or_img_display").html(`<img src="${base_url}assets/uploads/ca_liquidation/${data[0].or_image}" style="width:270px">`);
				}
				$("#user_ent_liq_modal").modal("show");
			}
		})
	})

	$("#form_user_ent_liq").on("submit", function (e) {
    if($("#form_user_ent_liq")[0].checkValidity()!=false){
    e.preventDefault();
    var form_data = new FormData($('#form_user_ent_liq')[0]);
    $('#dts_body').addClass('disable_page');
    $('#loader').show();
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: form_data,
				url: base_url+'Viewdoc/add_liq_or',
        contentType: false, 
        processData: false, 
				success: function(data){
					if(data.error==0){
						toastr.success("OR No. has been updated!");
					}
					$("#user_ent_liq_modal").modal("hide");
				},
				complete: function(){
			    $('#dts_body').removeClass('disable_page');
			    $('#loader').hide();
	      }
			})
		}
	})	

	$("#delete_linked_doc_btn").click(function(e){
		e.preventDefault();
		$("#clinked_dtsno_title").html($("#linked_dtsno_title").html());
		$("#confirm_delete_linked_doc_modal").modal("show");
	})

	$("#cancel_to").click(function(e){
		e.preventDefault();
		$("#cancel_to_modal").modal("show");
	})

	$("#submit_cancel_to").click(function(e){
		e.preventDefault();
		$("#confirm_calcel_to_modal").modal("show");
	});

	$("#confirm_delete_linked_doc_btn").click(function(e){
		e.preventDefault();
		var password = $("#password").val();
		if(password!=""){
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: {password:password},
				url: base_url+'General/verify_password',
				success: function(data){
					if(data.error==0){
						$("#form_delete_linked_doc").submit();
					}else{
						toastr.warning("Incorrect Password!");
					}
				}
			})
		}else{
			alert("Password cannot be empty!");
		}
	})

	$("#confirm_cancel_to_btn").click(function(e){
		e.preventDefault();
		var password = $("#password_to").val();
		if(password!=""){
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: {password:password},
				url: base_url+'General/verify_password',
				success: function(data){
					if(data.error==0){
						$("#cancel_to_form").submit();
					}else{
						toastr.warning("Incorrect Password!");
					}
				}
			})
		}else{
			alert("Password cannot be empty!");
		}
	})

	$("#approve_so").click(function(){
		$("#approve_so_modal").modal("show");
	})


	$("#confirm_approve_so_btn").click(function(e){
		e.preventDefault();
		var is_with_claim = $("#is_with_claim").val();
		if(password!=""){
			$.ajax({
				type: "POST",
				dataType: "JSON",
				data: {is_with_claim:is_with_claim,dtsno:dtsno},
				url: base_url+'Viewdoc/approve_so',
				success: function(data){
					if(data){
						location.reload();
					}
				}
			})
		}else{
			alert("Password cannot be empty!");
		}
	})
})

</script>