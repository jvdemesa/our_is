<style type="text/css">

</style>
<!---- Archive MODAL-->
<div class="modal fade" id="archive_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Archive Track
        </h4>
      </div>
      <form id="form_archive" method="POST">
      <!-- Modal Body For Update -->
        <div class="modal-body">
          <p class="lead"> Are you sure you want to archive this document?</p>
          <input type="hidden" name="archive_tracker_id" id="archive_tracker_id">
          <input type="hidden" name="archive_dtsno" id="archive_dtsno" value="<?= $dtsno ?>">
          <input type="hidden" name="archive_copy_no" id="archive_copy_no">

          <label>Action Done:</label>
          <textarea name="action_done" id="action_done" class="form-control" required="required"></textarea>
        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="confirmArchive_btn">
            <i class="fa fa-archive fa-lg"></i> Archive
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- Make Copy MODAL-->
<div class="modal fade" id="mc_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg bg-aqua">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title">
          Make Copy
        </h4>
      </div>
      <form id="form_mc" action="<?= base_url().'Viewdoc/make_copy'?>" method="POST">
      <!-- Modal Body For Update -->
        <div class="modal-body">
          <input type="hidden" name="mc_dtsno" id="mc_dtsno" value="<?= $dtsno ?>">
          <input type="hidden" name="mc_copy_no" id="mc_copy_no">
          <table class="table table-bordered-bottom">
            <tr>
              <td width="30%"><label>Division:</label></td>
              <td width="70%">
                <select class="select2 form-control divid" id="divid" name="div_id" onChange="getDiv(this);" required="required" style="width: 100%">
                    <option value="" selected disabled>Select Division</option>
                    <?php foreach($division as $val){ ?>
                        <option value="<?= $val->divunit_id?>"><?= $val->divunit_abv ." - ".$val->divunit_name?></option>
                    <?php } ?>
                </select>
              </td>
            </tr>
            <tr>
              <td><label>Unit:</label></td>
              <td>
                <select class="select2 form-control unitid" id="unitid" name="unit_id" id="unitid"  required="required" style="width: 100%">
                  <option value="" selected disabled>Select Division First</option>
                </select>
              </td>
            </tr>
            <tr>
              <td><label>Action Requested:</label></td>
              <td>
                <input list="encodings"  value="" class="form-control" name="action_req" id="action_req" required="required">
                <datalist id="encodings">
                    <?php foreach($action_list as $val){ ?>
                    <option value="<?= $val->action_requested ?>"><?= $val->action_requested ?></option>
                    <?php } ?>
                </datalist>
              </td>
            </tr>
          </table>
        </div>
        <div class="modal-footer  bg bg-aqua" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="confirmMc_btn">
            <i class="fa fa-copy fa-lg"></i> Make Copy
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- FORWARD MODAL-->
<div class="modal modal-default fade" id="forward_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg bg-green">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 id="status_title">
          Forward Document
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body">
        <form id="form_forward" action="<?= base_url().'Viewdoc/forward'?>" method="POST">
          <input type="hidden" name="forward_tracker_id" id="forward_tracker_id">
          <input type="hidden" name="forward_dtsno" id="forward_dtsno" value="<?= $dtsno ?>">
          <input type="hidden" name="forward_copy_no" id="forward_copy_no">
          <table class="table table-bordered-bottom table-responsive">
            <tr>
              <td><label>Action Done:</label></td>
              <td>
                <textarea name="action_done" id="action_done_fwd" class="form-control" required="required"></textarea>
              </td>
            </tr>
            <tr>
              <td width="30%"><label>Division:</label></td>
              <td width="70%">
                <select class="select2 form-control divid" id="div_id_fwd" name="div_id" onChange="getDiv(this);" required="required">
                  <option value="" selected disabled>Select Division</option>
                  <?php foreach($division as $val){ ?>
                      <option value="<?= $val->divunit_id?>"><?= $val->divunit_abv ." - ".$val->divunit_name?></option>
                  <?php } ?>
                </select>
              </td>
            </tr>
            <tr>
              <td><label>Unit:</label></td>
              <td>
                <select class="select2 form-control unitid " id="unit_id_fwd" name="unit_id" id="unitid"  required="required">
                    <option value="" selected disabled>Select Division First</option>
                </select>
              </td>
            </tr>
            <tr>
              <td><label>Action Requested:</label></td>
              <td>
                <input list="encodings"  value="" class="form-control" name="action_req" id="action_req_fwd" required="required">
                <datalist id="encodings">
                    <?php foreach($action_list as $val){ ?>
                      <option value="<?= $val->action_requested ?>">
                        <?= $val->action_requested ?>
                      </option>
                    <?php } ?>
                </datalist>
              </td>
            </tr>
            <tr>
              <td><label>Manually Signed?</label></td>
              <td>
                <div class="form-check">
                  <?php
                  if($cs_detail!=null){
                    $no = ($cs_detail->is_signed==1)?'checked':'';
                  }else{
                    $no = '';
                  }
                  //$yes = ($cs_detail->is_for_signature==0)?'checked':'';
                  $not_applicable = (!in_array($first_track->type, ["5"]))?'checked':'';
                  ?>
                  <label class="form-check-label">
                    <input type="radio" value="1" class="form-check-input is_manually_signed" name="is_manually_signed" required>Yes
                  </label><br>
                  <label class="form-check-label">
                    <input type="radio" value="0" class="form-check-input is_manually_signed" name="is_manually_signed" <?= $no ?>>No
                  </label><br>
                  <label class="form-check-label">
                    <input type="radio" value="2" class="form-check-input is_manually_signed" name="is_manually_signed" <?= $not_applicable ?>>Not Applicable
                  </label>
                </div>
              </td>
            </tr>
          </table>
        </div>
        <div class="modal-footer  bg bg-green">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>          
          <button type="submit" class="btn btn-outline" id="confirmForward_btn">
            <i class="fa fa-forward fa-lg"></i> Forward
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- CONFIRM RECEIVE MODAL-->
<div class="modal fade" id="receive_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-blue">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title">
          Confirm Receive
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body table-responsive">
        <input type="hidden" name="receive_tracker_id" id="receive_tracker_id">
        <p class="lead">Are you sure you want to receive this document?</p>
      </div>
      <div class="modal-footer bg-blue" align="right">
        <button type="button" class="btn btn-outline" data-dismiss="modal">
          <i class="fa fa-times fa-lg"></i> Close
        </button>
        <button type="button" class="btn btn-outline" id="confirmReceive_btn">
          <i class="fa fa-save fa-lg"></i> Receive
        </button>
      </div>
    </div>
  </div>
</div>

<!--- CONFIRM FOR SIGNATURE / INITIAL MODAL -->
<div class="modal fade" id="signature_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-purple">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Confirm For Signature / Initial
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body table-responsive">
        <input type="hidden" name="signature_dtsno" id="signature_dtsno">
        <p class="lead">Submit this document for Digital signature / Initial?</p>
      </div>
      <div class="modal-footer bg-purple" align="right">
        <button type="button" class="btn btn-outline" data-dismiss="modal">
          <i class="fa fa-times fa-lg"></i> Close
        </button>
        <button type="button" class="btn btn-outline" id="confirmSignature_btn">
          <i class="fa fa-save fa-lg"></i> Confirm
        </button>
      </div>
    </div>
  </div>
</div>

<!--- CANCEL FOR SIGNATURE / INITIAL MODAL -->
<div class="modal fade" id="cancel_signature_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-red">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Confirm Cancellation For E-Signature / E-Initial
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body table-responsive">
        <input type="hidden" name="signature_dtsno" id="signature_dtsno">
        <p class="lead">Are you sure you want to cancel this document for E-signature / E-Initial?</p>
      </div>
      <div class="modal-footer bg-red" align="right">
        <button type="button" class="btn btn-outline" data-dismiss="modal">
          <i class="fa fa-times fa-lg"></i> Close
        </button>
        <button type="button" class="btn btn-outline" id="confirmCancel_btn">
          <i class="fa fa-save fa-lg"></i> Confirm
        </button>
      </div>
    </div>
  </div>
</div>


<!--- EDIT DETAILS -->
<div class="modal fade" id="edit_details_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Update Document Details
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body table-responsive" id="doc_detail_fieldss_body">
        <?php 
        if($already_signed){
          $already_signed = 'readonly';
          $signed_read_only = 'readonly';
          $activate_drp = "";
        }else{
          $already_signed = "onChange='to_signatory()'";
          $signed_read_only = '';
          $activate_drp = "daterangepicker_dynamic";
        }
        ?>
        <form id="form_update">
          <input type="hidden" name="dtsno" value="<?= $dtsno ?>">
          <input type="hidden" name="doc_type_id" value="<?= $first_track->type ?>">
          <input type="hidden" name="sub_type" value="<?= $first_track->sub_type ?>">
          <input type="hidden" name="doc_details" id="doc_details" value="<?= $first_track->doc_details ?>">
          <?php 
          $doc_detail_fields="";
          foreach($fieldname as $val){
            switch($val->fieldtype){
              case '1':
              $doc_detail_fields .="<span class='text_span'><label>{$val->fieldname}:</label>
              <input type='text' class='form-control fieldname_id{$val->id} text' name='{$val->id}' required='required'></span>
                            ";
              break;
              case '3':
              $doc_detail_fields .="<span class='textarea_span'><label>{$val->fieldname}:</label><textarea class='form-control fieldname_id{$val->id} textarea' rows='3' name='{$val->id}' required='required'></textarea></span>
                            ";
              break;
              case '4'://for erdb employees list

              $doc_detail_fields .="<label>{$val->fieldname}:</label>
                            <select class='form-control select2 fieldname_id{$val->id}' name='{$val->id}' id='euid' {$already_signed} readonly='readonly'>";
                            //put all names to option
                            foreach($names as $name){
                             $doc_detail_fields .= "<option value='{$name->uid}'>{$name->lname}, {$name->fname} {$name->mname}</option>"; 
                            }
                            //});
             $doc_detail_fields .='</select>';
               break;
              case '5':

              $doc_detail_fields .="<label>{$val->fieldname}:</label>";
              $doc_detail_fields .="<input type='text' class='form-control datepicker fieldname_id{$val->id}' name='{$val->id}' required='required'>
                            ";
               break;
              case '6':

              $doc_detail_fields .="<label>{$val->fieldname}:</label>";
              $doc_detail_fields .="<input type='text' class='form-control  fieldname_id{$val->id} {$activate_drp}' name='{$val->id}' required='required' id='daterangepicker' {$already_signed}>
                            ";
               break;
              case '7'://for recommending approval list
              //value = array[signatory_id,unique_case_no,fullname]
              $uid='';
              $div_id='';
              $unit_id='';
              $doc_detail_fields .="<label>{$val->fieldname}:</label>
                            <select class='form-control select2 fieldname_id{$val->id}' name='{$val->id}' id='select_ad' {$signed_read_only}>";
                              $doc_detail_fields .= "<option value=''>Not Applicable</option>"; 
                              //put all signatories to option
                              foreach($signatories as $sig){
                                $doc_detail_fields .= "<option uid='{$sig->uid}' div_id='{$sig->uid}' unit_id='{$sig->unit_id}' value='{$sig->id}'>{$sig->designation}:{$sig->lname}, {$sig->fname} {$sig->mname}</option>"; 
                              }
              $doc_detail_fields .="</select>";
               break;
              case '8'://for approval list
              //value = array[signatory_id,unique_case_no,fullname]
              $doc_detail_fields .="<span id='approval_span'><label>{$val->fieldname}:</label>
                            <select class='form-control select2 fieldname_id{$val->id}' name='{$val->id}' id='select_d' {$signed_read_only}>";
                            //put all signatories to option
                              foreach($signatories as $sig){
                                $doc_detail_fields .= "<option uid='{$sig->uid}' div_id='{$sig->uid}' unit_id='{$sig->unit_id}' value='{$sig->id}' >{$sig->designation}:{$sig->lname}, {$sig->fname} {$sig->mname}</option>"; 
                              }
              $doc_detail_fields .="</select></span>";
               break;            
            case '9'://for initial list
            //value = array[signatory_id,unique_case_no,fullname]
              $doc_detail_fields .="<span class='dvch'><label>{$val->fieldname}:</label>
                            <select class='form-control select2 fieldname_id{$val->id}' name='{$val->id}' id='select_dvch' {$signed_read_only}>";
                            $doc_detail_fields .= "<option value=''>Not Applicable</option>"; 
                            //put all signatories to option
                            foreach($signatories as $sig){
                              if($sig->designation == '3'){
                                $selected = 'selected';
                                $uid = $sig->uid;
                                $div_id = $sig->div_id;
                                $unit_id = $sig->unit_id;
                              }else{
                                $selected = '';
                              }
                                $doc_detail_fields .= "<option uid='{$sig->uid}' div_id='{$sig->uid}' unit_id='{$sig->unit_id}' value='{$sig->id}' ${selected}>{$sig->designation}:{$sig->lname}, {$sig->fname} {$sig->mname}</option>"; 
                            }
              $doc_detail_fields .="</select></span>";
               break;
      case "15"://for Accountant
        $doc_detail_fields .="<label>{$val->fieldname}:</label>
        <select class='form-control select2 fieldname_id{$val->id}' name='{$val->id}' id='select_acc' {$signed_read_only}>";
              $doc_detail_fields .= "<option value=''>Not Applicable</option>"; 
              //put all signatories to option
              foreach($signatories as $sig){
                if($sig->designation == '5'){
                  $selected = 'selected';
                  $uid = $sig->uid;
                  $div_id = $sig->div_id;
                  $unit_id = $sig->unit_id;
                }else{
                  $selected = '';
                }
                $doc_detail_fields .= "<option uid='{$sig->uid}' div_id='{$sig->uid}' unit_id='{$sig->unit_id}' value='{$sig->id}' ${selected}>{$sig->designation}:{$sig->lname}, {$sig->fname} {$sig->mname}</option>"; 
              }
        $doc_detail_fields .="</select>";
      break;      
      case "16"://for Unit Head
        $doc_detail_fields .="<span id='unit_head_span'><label>{$val->fieldname}:</label>
        <select class='form-control select2 fieldname_id{$val->id}' name='{$val->id}' id='select_unit_head' {$signed_read_only} id='unit_head'>";
              $doc_detail_fields .= "<option value=''>Not Applicable</option>"; 
              //put all signatories to option
              foreach($signatories as $sig){
                if($sig->designation == '6'){
                  $selected = 'selected';
                  $uid = $sig->uid;
                  $div_id = $sig->div_id;
                  $unit_id = $sig->unit_id;
                }else{
                  $selected = '';
                }
                $doc_detail_fields .= "<option uid='{$sig->uid}' div_id='{$sig->uid}' unit_id='{$sig->unit_id}' value='{$sig->id}' ${selected}>{$sig->designation}:{$sig->lname}, {$sig->fname} {$sig->mname}</option>"; 
              }
        $doc_detail_fields .="</select></span>";
      break;        
      case "17"://for Budget Officer
        $doc_detail_fields .="<label>{$val->fieldname}:</label>
        <select class='form-control select2 fieldname_id{$val->id}' name='{$val->id}' id='select_bo' {$signed_read_only}>";
              $doc_detail_fields .= "<option value=''>Not Applicable</option>"; 
              //put all signatories to option
              foreach($signatories as $sig){
                if($sig->designation == '7'){
                  $selected = 'selected';
                  $uid = $sig->uid;
                  $div_id = $sig->div_id;
                  $unit_id = $sig->unit_id;
                }else{
                  $selected = '';
                }
                $doc_detail_fields .= "<option uid='{$sig->uid}' div_id='{$sig->uid}' unit_id='{$sig->unit_id}' value='{$sig->id}' ${selected}>{$sig->designation}:{$sig->lname}, {$sig->fname} {$sig->mname}</option>"; 
              }
        $doc_detail_fields .="</select>";
        break; 
        case "23"://yes or no
        $doc_detail_fields .='<label>'.$val->fieldname.':</label>
                      <select class="form-control select2_yn fieldname_id'.$val->id.'" name="'.$val->id.'" id="select2_yn">
                      <option value="NO">NO</option>
                      <option value="YES">YES</option>
                      </select>';
        }
      }
    echo $doc_detail_fields;
    ?>
        <div id="signature_div">
        </div>
      </form>
      </div>
      <div class="modal-footer bg-yellow" align="right">
        <button type="button" class="btn btn-outline" data-dismiss="modal">
          <i class="fa fa-times fa-lg"></i> Close
        </button>
        <button type="button" class="btn btn-outline" id="confirmEdit_btn">
          <i class="fa fa-save fa-lg"></i> Confirm
        </button>
      </div>
    </div>
  </div>
</div>

<!---- Audit Trail-->
<div class="modal fade" id="audit_trail_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-purple">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Audit Trail
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body">
        <table class="table table-striped" id="audit_trail_table" width="100%">
          <thead>
            <tr>
              <td>Field Name:</td>
              <td>Old Details:</td>
              <td>New Details:</td>
              <td>Date updated:</td>
              <td>Updated By:</td>
            </tr>
          </thead>
          <tbody id="audit_trail_modal_body">
          </tbody>
        </table>
      </div>
      <div class="modal-footer bg-purple" align="right">
        <button type="button" class="btn btn-outline" data-dismiss="modal">
          <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
        </button>
      </div>
    </div>
  </div>
</div>

<!---- Audit Trail-->
<div class="modal fade" id="upload_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Upload <span id="upload_label"></span>
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_upload">
        <div class="modal-body">
          <input type="hidden" id="upload_dtsno" name="dtsno" value="<?= $dtsno ?>">
          <input type="hidden" id="file_id" name="file_id">
          <input type="hidden" id="fieldname" name="fieldname">
          <input type="hidden" id="old_file" name="old_file">
          <input type="file" accept="application/pdf" name="upload_file" id="upload_file" class="form-control btn btn-default" required="required">
        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="button" class="btn btn-outline" id="confirmUpload_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- EDIT LINKED DOC-->
<div class="modal fade" id="edit_linked_doc_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Update Linked Document
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_linked_doc" action="<?= base_url("/viewdoc/update_linked_doc"); ?>" method="POST">
        <input type="hidden" name="dtsno" value="<?= $dtsno ?>">
        <input type="hidden" name="linked_id" id="linked_id">
        <input type="hidden" name="doc_type_id" id="linked_doc_type">
        <input type="hidden" name="linked_employee_id" id="linked_employee_id">
        <div class="modal-body">
          <label id="linked_label"></label>
          <select class="select2" name="linked_doc" id="select2_linked_doc" required="required">
          </select>
        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="edit_linked_doc_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- CREATE IoT-->
<div class="modal modal-default fade" id="iot_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-green" id="obr_header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="obr_title">
          Create Itinerary of Travel and Certificate of Travel Completed
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_iot" class="form-horizontal">

        <input type="hidden" name="dtsno" id="dtsno" value="<?= $dtsno ?>">
        <input type="hidden" name="uid" id="iot_uid" value="<?= $employee_id ?>">
        <input type="hidden" name="iot_todo" id="iot_todo" value="">
        <!--if sub type is cash advance set is actual to 0-->
        <input type="hidden" name="is_actual" id="is_actual" value="<?= $first_track->sub_type==80?0:1; ?>">
        <div class="modal-body">
          <h3>For Certificate of Travel Completed</h3>
           <div class="form-group" >
              <label for="rc_code" class="col-sm-2 control-label">Conditions </label>
              <div class="col-sm-10">
                <select class="select2" name="condition_no" id="condition_no">
                  <option value="1">Strictly in accordance with the approved itinerary</option>
                  <option value="2">Cut short as explained below.</option>
                  <option value="3">Extended as explained below, additional itinerary was submitted.</option>
                  <option value="4">Other deviation as explained below.</option>
                </select>   
              </div>
          </div>
         <div class="form-group hideme" id="cut_short">
              <label for="rc_code" class="col-sm-2 control-label">Excess payment Amount:</label>
              <div class="col-sm-10">
                <input type="text" name="amount" id="amount_cotc" class="form-control">   
              </div>
              <label for="rc_code" class="col-sm-2 control-label">Refunded under OR No:</label>
              <div class="col-sm-10">
                <input type="text" name="or_no" id="or_no" class="form-control">   
              </div>
              <label for="rc_code" class="col-sm-2 control-label">Dated:</label>
              <div class="col-sm-10">
                <input type="text" name="date_cotc" id="date_cotc" class="form-control datepicker">   
              </div>
          </div>
         <div class="form-group" >
              <label for="rc_code" class="col-sm-2 control-label">Explanation or justifications</label>
              <div class="col-sm-10">
                <input type="text" name="explanation" id="explanation" class="form-control">   
              </div>
          </div>
         <div class="form-group" >
              <label for="rc_code" class="col-sm-2 control-label">Evidence of travel: </label>
              <div class="col-sm-10">
                <input type="text" name="evidence" id="evidence" class="form-control" required="required" value="Certificate of appearance, approved T.O, accomplishment report">   
              </div>
          </div>
          <h3>Itinerary of Travel</h3>
         <div class="form-group" >
              <label for="rc_code" class="col-sm-2 control-label">Entity Name</label>
              <div class="col-sm-10">
                <input type="text" name="entity_name" id="entity_name" class="form-control" required="required" value="ERDB">   
              </div>
          </div>

<!--          <div class="form-group" >
              <label for="rc_desc" class="col-sm-2 control-label">Fund Cluster</label>
              <div class="col-sm-10">
                <input type="text" name="fund_cluster" id="fund_cluster" class="form-control" required="required">   
              </div>
          </div>
 -->
<!--          <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">Official Station</label>
              <div class="col-sm-10">
                <input type="text" name="official_station" id="official_station" class="form-control" required="required">   
              </div>
          </div>
 -->
         <div class="form-group" >
              <label for="uacs_code" class="col-sm-2 control-label">Travel Duration</label>
              <div class="col-sm-10">
                <input type="text" name="travel_duration" id="travel_duration" class="form-control daterange" required="required">   
              </div>
          </div>

         <div class="form-group" >
              <label for="uacs_desc" class="col-sm-2 control-label">Purpose of Travel</label>
              <div class="col-sm-10">
                <input type="text" name="purpose" id="purpose" class="form-control" required="required" value="Please see attached Travel Order">   
              </div>
          </div>
          <a href="#" id="remove_iot">
            <span class="label label-danger pull-right" style="font-size:100% !important">Remove Last
            <i class="fa fa-minus"></i></span>
          </a>  

          <a href="#" id="add_iot">
            <span class="label label-success pull-right" style="font-size:100% !important">Add Blank
            <i class="fa fa-plus"></i></span>
          </a>  

          <a href="#" id="copy_iot">
            <span class="label label-info pull-right" style="font-size:100% !important">Copy Last
            <i class="fa fa-copy"></i></span>
          </a>  
          <table class="table table-bordered" id="iot_tb">
            <thead>
              <th width="15%">Date</th>
              <th width="22%">Place to be visited</th>
              <th width="10%">Departure</th>
              <th width="10%">Arrival</th>
              <th width="15%">Means of Transportation</th>
              <th width="10%">Transportation</th>
              <th width="10%">Per Diem</th>
              <th width="8%">Others</th>
<!--               <th width="10%">Total Amount</th>
 -->            </thead>
            <tbody id="tbody_iot">
              <tr>
                <td>
                  <input type="hidden" name="iot_id[]" id="iot_id" class="form-control" required="required">
                  <input type="text" name="date[]" id="date" class="form-control datepicker_iot" readonly="readonly" required="required">
                </td>
                <td>
                  <input type="text" name="place[]" id="place" class="form-control" required="required">
                </td>
                <td>
                  <input type="time" name="departure[]" id="departure" class="form-control">
                </td>
                <td>
                  <input type="time" name="arrival[]" id="arrival" class="form-control">
                </td>
                <td>
                  <input type="text" name="means_transpo[]" id="means_transpo" class="form-control" required="required">
                </td>
                <td>
                  <input type="text" name="transpo[]" id="transpo" class="form-control" value="0">
                </td>
                <td>
                  <input type="text" name="per_diem[]" id="per_diem" class="form-control" required="required">
                </td>
                <td>
                  <input type="text" name="others[]" id="others" class="form-control">
                </td>
<!--                 <td>
                  <input type="text" name="amount[]" id="amount" class="form-control" required="required">
                </td>
 -->              </tr>
            </tbody>
          </table>
        </div>
        <div class="modal-footer bg-green" align="right" id="obr_footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="submit_iot_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!---- CREATE OBR-->
<div class="modal modal-default fade" id="obr_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-green" id="obr_header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="obr_title">
          Create OBR
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_obr" class="form-horizontal">
        <input type="hidden" name="obr_todo" id="obr_todo">
        <input type="hidden" name="obr_id" id="obr_id">
        <?php if($payee){ ?>
          <input type="hidden" name="payee" id="payee" value="<?= $payee->lname.", ".$payee->fname ?>">
          <input type="hidden" name="payee_uid" id="payee_uid" value="<?= $payee->uid ?>">
        <?php } ?>
        <input type="hidden" name="dtsno" id="dtsno" value="<?= $dtsno ?>">
        <div class="modal-body">
         <div class="form-group" >
              <label for="rc_code" class="col-sm-2 control-label">Particulars</label>
              <div class="col-sm-10">
                <input type="text" name="particulars" id="particulars" class="form-control" required="required">   
              </div>
          </div>

         <div class="form-group" >
              <label for="rc_desc" class="col-sm-2 control-label">Funding Source</label>
              <div class="col-sm-10">
                <select name="funding_source" id="funding_source" class="form-control select2" required="required">
                  <option value="" selected disabled="">Select Funding Source</option>
                  <?php 
                  foreach($funding_source as $val){ 
                    ?>
                    <option value="<?= $val->funding_source ?>" 
                      funding_source_id="<?= $val->id ?>"
                      mds="<?= $val->mds ?>"
                      nca="<?= $val->nca ?>"
                      code="<?= $val->code ?>"
                      fund_cluster="<?= $val->fund_cluster ?>"
                      ors_burs="<?= $val->ors_burs ?>"
                      >
                      <?= $val->funding_source ?></option>
                  <?php 
                  } 
                  ?>
                </select>
                <input type="hidden" name="ors_burs" id="ors_burs_obr">
                <input type="hidden" name="funding_source_id" id="funding_source_id">
                <input type="hidden" name="mds" id="mds">
                <input type="hidden" name="nca" id="nca">
              </div>
          </div>

         <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">Funding Source Code</label>
              <div class="col-sm-10">
                <input type="text" name="funding_source_code" id="funding_source_code" class="form-control" required="required" readonly>   
              </div>
          </div>

         <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">Fund Cluster</label>
              <div class="col-sm-10">
                <input type="text" name="fund_cluster" id="fund_cluster_obr" class="form-control" required="required" readonly>   
              </div>
          </div>

         <div class="form-group" >
              <label for="uacs_desc" class="col-sm-2 control-label">Date</label>
              <div class="col-sm-10">
                <input type="text" name="date" id="obr_date" class="form-control datepicker" required="required" value="<?= date("Y-m-d") ?>">   
              </div>
          </div>

         <div class="form-group" >
              <label for="uacs_desc" class="col-sm-2 control-label">Certifier</label>
              <div class="col-sm-10">
                <select class="select2 form-control" name="certifier" id="certifier" required="required">
                  <option value="" selected disabled>Select Certifier</option>
                  <?php
                  foreach($signatories as $sig){
                    echo "<option value='{$sig->id}'>{$sig->designation}:{$sig->lname}, {$sig->fname} {$sig->mname}</option>";
                  }
                  ?>
                </select>
              </div>
          </div>
          <a href="#" id="remove_obr">
            <span class="label label-danger pull-right" style="font-size:100% !important">Remove Last
            <i class="fa fa-minus"></i></span>
          </a>  

          <a href="#" id="add_obr">
            <span class="label label-success pull-right" style="font-size:100% !important">Add
            <i class="fa fa-plus"></i></span>
          </a>  
          <table class="table table-bordered" id="obr_tb">
            <thead>
              <th width="25%">RC Description</th>
              <th width="25%">Prexc</th>
              <th width="20%">UACS Description</th>
              <th width="10%">Amount</th>
          </thead>
            <tbody id="tbody_obr">
            <?php
            if($linked_rc){
              foreach($linked_rc as $linked_val){
                $disable_rc = $userdata->unit_id == "19" || ($first_track->sub_type == 106 || $first_track->sub_type == 118 )?"":"readonly";
            ?>
              <tr>
                <td> 
                  <input type="hidden" name="obr_id_tb[]" id="obr_id_tb" class="form-control">
                  <select class="select2_obr rc_desc" name="rc_desc[]" id="rc_desc" required <?= $disable_rc ?>>
                    <option selected disabled>Select RC</option>
                    <?php foreach($rc as $val){
                      if($linked_val->rc_id == $val->id){
                        $rc_code = "{$val->code}";
                        echo "<option value='{$val->description}' code='{$val->code}' selected='selected'>{$val->description}({$val->code})</option>";
                      }else{
                        echo "<option value='{$val->description}' code='{$val->code}'>{$val->description}({$val->code})</option>";
                      }
                    }
                    ?>
                  </select>
                  <input type="hidden" name="rc_code[]" id="rc_code" class="form-control rc_code" value="<?= $rc_code ?>" required="required" readonly>
                </td>
                <td>
                  <select class="select2_obr prexc" name="prexc[]" required>
                    <option selected disabled>Select PREXC</option>
                    <?php foreach($prexc as $val){
                      echo "<option value='{$val->code}' code='{$val->code}'>{$val->description}({$val->code})</option>";
                    }
                    ?>
                  </select>                
                </td>
                <td>
                  <select class="select2_obr uacs_desc" name="uacs_desc[]" required>
                    <option selected disabled>Select UACS</option>
                    <?php foreach($uacs as $val){
                      echo "<option value='{$val->description}' code='{$val->code}'>{$val->description} ({$val->code})</option>";
                    }
                    ?>
                  </select>
                  <input type="hidden" name="uacs_code[]" id="uacs_code" class="form-control uacs_code" required="required" readonly>
                </td>
                <td>
                  <input type="text" name="amount[]" id="amount" class="form-control">
                </td>
             </tr>
             <?php }
             }else{ ?>
              <tr>
                <td>
                  <input type="hidden" name="obr_id_tb[]" id="obr_id_tb" class="form-control">
                  <select class="select2_obr rc_desc" name="rc_desc[]" id="rc_desc" required>
                    <option selected disabled>Select RC</option>
                    <?php foreach($rc as $val){
                        echo "<option value='{$val->description}' code='{$val->code}'>{$val->description}({$val->code})</option>";
                    }
                    ?>
                  </select>
                  <input type="hidden" name="rc_code[]" id="rc_code" class="form-control rc_code" value="" required="required" readonly>
                </td>
                <td>
                  <select class="select2_obr prexc" name="prexc[]" required>
                    <option selected disabled>Select PREXC</option>
                    <?php foreach($prexc as $val){
                      echo "<option value='{$val->code}' code='{$val->code}'>{$val->description}({$val->code})</option>";
                    }
                    ?>
                  </select>                
                </td>
                <td>
                  <select class="select2_obr uacs_desc" name="uacs_desc[]" required>
                    <option selected disabled>Select UACS</option>
                    <?php foreach($uacs as $val){
                      echo "<option value='{$val->description}' code='{$val->code}'>{$val->description} ({$val->code})</option>";
                    }
                    ?>
                  </select>
                  <input type="hidden" name="uacs_code[]" id="uacs_code" class="form-control uacs_code" required="required" readonly>
                </td>
                <td>
                  <input type="text" name="amount[]" id="amount" class="form-control">
                </td>
             </tr>
           <?php } ?>
            </tbody>
          </table>
        </div>
        <div class="modal-footer bg-green" align="right" id="obr_footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="submit_obr_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="sign_docs_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Sign all Documents
        </h4>
      </div>
      <!-- Modal Body For Update -->
        <div class="modal-body">
       <div class="form-group" id="nyd_div">
          <h4>Are you sure you want to sign this documents and all of its linked documents?</h4>
        </div>
          Date Signed:
          <br><input type="text" name="date_signed" id="date_signed" class="form-control datepicker" value="<?= date("Y-m-d"); ?>">

        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="button" class="btn btn-outline" id="confirm_sign_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- tev_checklist_modal-->
<div class="modal fade" id="tev_checklist_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          TEV Checklist
        </h4>
      </div>
      <!-- Modal Body For Update -->
        <div class="modal-body">
          <table class="table table-bordered table-striped" id="checklist_tb" width="100%">
            <thead>
              <tr>
                <td width="3%">#</td>
                <td width="45%">Checklist</td>
                <td width="49%">Remarks</td>
                <td width="3%">Action</td>
              </tr>
            </thead>
            <tbody>
              <?php foreach($tev_checklist as $key=>$val){ ?>
                <tr>
                  <td><?= $key+1 ?></td>
                  <td><?= $val->tev_checklist ?></td>
                  <td id="tev_remarks<?= $val->id ?>"><?= $val->remarks ?></td>
                  <td>
                    <?php if($is_signed_aa == 0 && $is_signed_dir == 0){ ?>
                    <a href="#!" class="btn btn-header add_remarks" 
                    checklist_id="<?= $val->id ?>"
                    checklist="<?= $val->tev_checklist ?>"
                    >
                      <span class="label label-warning pull-right" style="font-size:85% !important">Add
                      <i class="fa fa-plus"></i></span>
                    </a>  
                  <?php } ?>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- ADD REMARKS -->
<div class="modal fade" id="remarks_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Add remarks
        </h4>
      </div>
      <!-- Modal Body For Update -->
        <div class="modal-body">
          <input type="hidden" name="checklist_id" id="checklist_id">
          <label id="checklist_label"></label>
          <label id="checklist_label">Remarks:</label>
          <textarea id="checklist_remarks" name="checklist_remarks" class="form-control" rows="8"></textarea>
        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="button" class="btn btn-outline" id="add_remarks_btn">
            <i class="fa fa-save fa-lg"></i> ADD
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Create Travel Report-->
<div class="modal modal-default fade" id="view_travel_report_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-blue" id="travel_report_header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="obr_title">
          Travel Report
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body" id="tr_modal_body">
        <table class="table table-bordered table-striped" id="tr_tb" width="100%">
          <thead>
            <th></th>
          </thead>
          <tbody id="tr_tbody">
          </tbody>
        </table>
      </div>
      <div class="modal-footer bg-blue" align="right" id="obr_footer">
        <button type="button" class="btn btn-outline" data-dismiss="modal">
          <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
        </button>
        <button type="submit" class="btn btn-outline add_travel_report" id="">
          <i class="fa fa-save fa-lg"></i> ADD
        </button>
      </div>
    </div>
  </div>
</div>
<!-- ADD TRAVEL REPORT-->
 <div class="modal modal-default fade" id="add_travel_report_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-green" id="travel_report_header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="obr_title">
          Add Travel Report
        </h4>
      </div>
      <!-- Modal Body For Update -->
        <tbody>
          <tr>
            <td>
            <form id="form_tr" class="form-horizontal">
              <input type="hidden" name="dtsno"  value="<?= $dtsno ?>">
              <input type="hidden" name="uid"  value="<?= $employee_id ?>">
              <input type="hidden" name="travel_report_todo" id="travel_report_todo"  value="">
              <input type="hidden" name="travel_report_id" id="travel_report_id"  value="">
              <div class="modal-body">

               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Date of Travel</label>
                    <div class="col-sm-10">
                      <input type="text" name="dot" id="dot" class="form-control daterange" required="required">   
                    </div>
                </div>

               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Purpose of Travel</label>
                    <div class="col-sm-10">
                      <input type="text" name="purpose" id="tr_purpose" class="form-control" required="required" value="Please see attached Travel Order">   
                    </div>
                </div>

               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Destination</label>
                    <div class="col-sm-10">
                      <input type="text" name="destination" id="tr_destination" class="form-control" required="required">   
                    </div>
                </div>

               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Accomplishment</label>
                    <div class="col-sm-10">
                      <textarea class="form-control" rows="10" name="accomplishment" id="tr_accomplishment"></textarea>
                    </div>
                </div>
               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Set this to next page</label>
                    <div class="col-sm-10">
                      <select name="is_nextpage" id="is_nextpage" class="select2">
                        <option value="0">NO</option>
                        <option value="1">YES</option>
                      </select>
                    </div>
                </div>
               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Upload Image</label>
                    <div class="col-sm-10">
                      <label class="form-label" for="customFile">Default file input example</label>
                      <input type="file" name="upload_file" class="form-control" id="tr_image" accept="image/png, image/gif, image/jpeg"/>
                    </div>
                </div>
               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Image Caption</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="caption" id="caption">
                    </div>
                </div>
               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Upload Image</label>
                    <div class="col-sm-10">
                      <label class="form-label" for="customFile">Default file input example</label>
                      <input type="file" name="upload_file2" class="form-control" id="tr_image" accept="image/png, image/gif, image/jpeg"/>
                    </div>
                </div>
               <div class="form-group" >
                    <label for="mfo" class="col-sm-2 control-label">Image Caption</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="caption2" id="caption2">
                    </div>
                </div>
              </div>
              <div class="modal-footer bg-green" align="right" id="obr_footer">
                <button type="button" class="btn btn-outline" data-dismiss="modal">
                  <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
                </button>
                <button type="submit" class="btn btn-outline" id="confirmAddTrBtn">
                  <i class="fa fa-save fa-lg"></i> Confirm
                </button>
              </div>
            </form>
    </div>
  </div>
</div>

<!-- AUPLOAD IMAGE TRAVEL REPORT-->
 <div class="modal modal-default fade" id="add_travel_report_img_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-green" id="travel_report_header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title">
          Add Travel Report Image (<span id="tr_img_header"></span>)
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_tr" class="form-horizontal">
        <input type="hidden" name="dtsno"  value="<?= $dtsno ?>">
        <input type="hidden" name="tr_id" id="tr_id_img"  value="">
        <div class="modal-body">

          <div class="form-group" >
            <label for="mfo" class="col-sm-2 control-label">Date of Travel</label>
            <div class="col-sm-10">
              <input type="text" name="dot" id="dot" class="form-control daterange" required="required">   
            </div>
          </div>
        </div>
        <div class="modal-footer bg-green" align="right" id="obr_footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline update_travel_report" id="confirmAddTrBtn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Accounting Entry-->
 <div class="modal modal-default fade" id="add_accounting_entry_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-light-blue" id="travel_report_header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title">
          Add Accounting Entry
        </h4>
      </div>
      <!-- Modal Body For Update -->

        <div class="modal-body">
          <form id="form_acc_ent" class="form-horizontal">
          <div class="form-group" >
            <input type="hidden" name="dtsno"  value="<?= $dtsno ?>">
            <input type="hidden" name="acc_ent_id"  id="acc_ent_id">
            <div class="col-md-12 col-sm-12">
              <div class="col-md-4 col-sm-4">
                <label>Account Title</label>
                <select class="select2" name="account_title" id="account_title" required>
                  <?php foreach($accounting_entry as $val){ 
                  echo "<option value='{$val->id}' account_title='{$val->accounting_entry}'>{$val->accounting_entry}</option>";
                  } ?>
                </select>
                <input type="hidden" name="account_title_desc" id="account_title_desc">
              </div>
              <div class="col-md-3 col-sm-3">
                <label>UACS Code</label>
                <input type="text" name="auacs_code" id="auacs_code" class="form-control">   
              </div>
              <div class="col-md-2 col-sm-2">
                <label>Debit</label>
                <input type="text" name="debit" id="debit" class="form-control">   
              </div>
              <div class="col-md-2 col-sm-2">
                <label>Credit</label>
                <input type="text" name="credit" id="credit" class="form-control">
              </div>
              <div class="col-md-1 col-sm-1"><label>&nbsp;</label>
                <button type="submit" class="btn btn-primary" id="confirmAddAccEnt">
                  <i class="fa fa-plus fa-lg"></i>
                </button>
             </div>
            </div> 
          </div>
          </form>
          <table class="table table-bordered table-striped" id="acc_ent_tb" width="100%">
            <thead width="100%">
              <th>Account Title</th>
              <th>UACS Code</th>
              <th>Debit</th>
              <th>Credit</th>
              <th width="50px">Action</th>
            </thead>
            <tbody id="acc_entry_tbody">
            </tbody>
          </table>
        </div>
        <div class="modal-footer bg-light-blue" align="right" id="obr_footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
        </div>
    </div>
  </div>
</div>

<!-- ADD ORS-->
 <div class="modal modal-default fade" id="add_ors_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-light-blue" id="ors_header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title">
          Add ORS
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_ors" class="form-horizontal">
      <input type="hidden" name="dtsno"  value="<?= $dtsno ?>">
      <input type="hidden" name="ors_burs_id" id="ors_burs_id"  value="">
      <input type="hidden" name="ors_burs" class="ors_burs"  value="">
        <div class="modal-body">
         <div class="form-group" >
              <label for="mfo" class="col-sm-3 control-label">ORS Date</label>
              <div class="col-sm-9">
                <input type="text" name="ors_burs_date" id="ors_burs_date" class="form-control datepicker" value="<?= date("Y-m-d") ?>" required="required">
              </div>
          </div>

           <div class="form-group" >
            <label for="mfo" class="col-sm-3 control-label">ORS / BURS No.</label>
            <div class="col-sm-9">
              <input type="text" name="ors_burs_no" id="ors_burs_no" class="form-control" required="required">
            </div>
          </div>

           <div class="form-group" >
            <label for="mfo" class="col-sm-3 control-label">Allotment Class</label>
            <div class="col-sm-9">
              <select name="allotment_class" id="allotment_class" class="select2">
                <option value="MOOE">MOOE</option>
                <option value="PS">PS</option>
                <option value="CO">CO</option>
              </select>
            </div>
          </div>

         <div class="form-group" id="yoi_div">
              <label for="mfo" class="col-sm-3 control-label">Year of Implementation</label>
              <div class="col-sm-9">
                <select class="select2" name="yoi" id="yoi">
                  <option value="Year 1">Year 1</option>
                  <option value="Year 2">Year 2</option>
                  <option value="Year 3">Year 3</option>
                  <option value="Year 4">Year 4</option>
                  <option value="Year 5">Year 5</option>
                  <option value="Year 6">Year 6</option>
                  <option value="Year 7">Year 7</option>
                  <option value="Year 8">Year 8</option>
                  <option value="Year 9">Year 9</option>
                  <option value="Year 10">Year 10</option>
                </select>
              </div>
          </div>

         <div class="form-group" id="payable_div" >
            <label for="mfo" class="col-sm-3 control-label">Payable</label>
            <div class="col-sm-9">
              <input type="text" name="payable" id="payable" class="form-control">
            </div>
          </div>

         <div class="form-group" id="payment_div">
            <label for="mfo" class="col-sm-3 control-label">payment</label>
            <div class="col-sm-9">
              <input type="text" name="payment" id="payment" class="form-control">
            </div>
          </div>

         <div class="form-group" id="nyd_div">
            <label for="mfo" class="col-sm-3 control-label">Not Yet Due</label>
            <div class="col-sm-9">
              <input type="text" name="nyd" id="nyd" class="form-control">
            </div>
          </div>

        </div>
        <div class="modal-footer bg-light-blue" align="right" id="obr_footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline save_orsBtn" id="save_orsBtn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--EDIT TRACK -->
<div class="modal modal-default fade" id="edit_track_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg bg-blue">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 id="status_title">
          Edit Track
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <div class="modal-body">
        <form id="form_edit_track" action="<?= base_url().'Viewdoc/edit_track'?>" method="POST">
          <input type="hidden" name="tracker_id" id="tracker_id">
          <input type="hidden" name="dtsno" id="dtsno" value="<?= $dtsno ?>">
          <table class="table table-bordered-bottom table-responsive">
            <tr>
              <td width="30%"><label>Division:</label></td>
              <td width="70%">
                <select class="select2 form-control divid" id="div_id_edit" name="div_id" onChange="getDiv(this);" required="required">
                  <option value="" selected disabled>Select Division</option>
                  <?php foreach($division as $val){ ?>
                      <option value="<?= $val->divunit_id?>"><?= $val->divunit_abv ." - ".$val->divunit_name?></option>
                  <?php } ?>
                </select>
              </td>
            </tr>
            <tr>
              <td><label>Unit:</label></td>
              <td>
                <select class="select2 form-control unitid " id="unit_id_edit" name="unit_id" id="unitid"  required="required">
                    <option value="" selected disabled>Select Division First</option>
                </select>
              </td>
            </tr>
            <tr>
              <td><label>Action Requested:</label></td>
              <td>
                <input list="encodings"  value="" class="form-control" name="action_req" id="action_req_edit" required="required">
                <datalist id="encodings">
                    <?php foreach($action_list as $val){ ?>
                      <option value="<?= $val->action_requested ?>">
                        <?= $val->action_requested ?>
                      </option>
                    <?php } ?>
                </datalist>
              </td>
            </tr>
          </table>
        </div>
        <div class="modal-footer  bg bg-blue">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>          
          <button type="submit" class="btn btn-outline" id="edit_trackBtn">
            <i class="fa fa-forward fa-lg"></i> Forward
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Accounting entry for liquidation of ca -->
 <div class="modal modal-default fade" id="acc_entry_liq_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-light-blue" id="header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title">
          Add Accounting Entry
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_acc_ent_liq" class="form-horizontal">
        <div class="modal-body">
            <input type="hidden" name="table_name"  value="ca_liquidation">
            <input type="hidden" name="id"  id="acc_ent_liq_id">
            <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">Serial No.</label>
              <div class="col-sm-10">
                <input type="text" name="serial_no" id="serial_no" class="form-control" required="required">   
              </div>
            </div>
            <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">JEV No.</label>
              <div class="col-sm-10">
                <input type="text" name="jev_no" id="jev_no" class="form-control" required="required">   
              </div>
            </div>
          </div>
        <div class="modal-footer bg-light-blue" align="right" id="obr_footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="submit_acc_ent_liqBtn">
            <i class="fa fa-save fa-lg"></i> Submit
          </button>
        </div>          
      </form>
    </div>
  </div>
</div>
<!-- User entry for liquidation of CA -->
 <div class="modal modal-default fade" id="user_ent_liq_modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-light-blue" id="header">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title">
          Add OR No. and OR Copy
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_user_ent_liq" class="form-horizontal">
        <div class="modal-body">
            <input type="hidden" name="table_name"  value="ca_liquidation">
            <input type="hidden" name="dtsno"  value="<?= $dtsno ?>">
            <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">OR No.</label>
              <div class="col-sm-10">
                <input type="text" name="or_no" id="or_no_liq" class="form-control" required="required">   
              </div>
            </div>
            <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">OR Date</label>
              <div class="col-sm-10">
                <input type="text" name="or_date" id="or_date" class="form-control datepicker" required="required">   
              </div>
            </div>

            <div class="form-group" >
              <label for="mfo" class="col-sm-2 control-label">Upload OR Copy</label>
              <div class="col-sm-10">
                <label class="form-label" for="customFile">Default file input example</label>
                <input type="file" name="upload_file" class="form-control" id="or_image" accept="image/png, image/gif, image/jpeg"/>
              </div>
            </div>
            <div id="or_img_display">
            </div>
          </div><!-- End modal body -->
        <div class="modal-footer bg-light-blue" align="right" id="obr_footer">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="submit_acc_ent_liqBtn">
            <i class="fa fa-save fa-lg"></i> Submit
          </button>
        </div>          
      </form>
    </div>
  </div>
</div>

<!---- Delete LINKED DOC-->
<div class="modal fade" id="delete_linked_doc_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Delete Linked Document - <span id="linked_dtsno_title"></span>
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="form_delete_linked_doc" action="<?= base_url("/viewdoc/delete_linked_doc"); ?>" method="POST">
        <input type="hidden" name="linked_id" id="delete_linked_id">
        <input type="hidden" name="dtsno" value="<?= $dtsno ?>">
        <div class="modal-body">
          <label>Reason for deletion</label>
          <textarea id="delete_reason" name="delete_reason" class="form-control" required="required"></textarea>
        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="delete_linked_doc_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- Delete LINKED DOC-->
<div class="modal fade" id="confirm_delete_linked_doc_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-red">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Confirm Delete Linked Document - <span id="clinked_dtsno_title"></span>
        </h4>
      </div>
      <!-- Modal Body For Update -->
        <input type="hidden" name="linked_id" id="delete_linked_id">
        <input type="hidden" name="dtsno" value="<?= $dtsno ?>">
        <div class="modal-body">
          <label>Enter Your Password</label>
          <input type="password" name="password" id="password" class="form-control" required="required">
        </div>
        <div class="modal-footer bg-red" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="button" class="btn btn-outline" id="confirm_delete_linked_doc_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
    </div>
  </div>
</div>

<!---- Delete LINKED DOC-->
<div class="modal fade" id="cancel_to_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-yellow">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Cancel Travel Order
        </h4>
      </div>
      <!-- Modal Body For Update -->
      <form id="cancel_to_form" action="<?= base_url("/viewdoc/cancel_to"); ?>" method="POST">
        <input type="hidden" name="dtsno" value="<?= $dtsno ?>">
        <div class="modal-body">
          <label>Reason for Cancellation</label>
          <textarea id="reason" name="reason" class="form-control" required="required"></textarea>
        </div>
        <div class="modal-footer bg-yellow" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="submit" class="btn btn-outline" id="submit_cancel_to">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!---- Cancel TO-->
<div class="modal fade" id="confirm_calcel_to_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-red">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Confirm cancellation of Travel Order
        </h4>
      </div>
      <!-- Modal Body For Update -->
        <input type="hidden" name="dtsno" value="<?= $dtsno ?>">
        <div class="modal-body">
          <label>Enter Your Password to confirm calcellation</label>
          <input type="password" name="password" id="password_to" class="form-control" required="required">
        </div>
        <div class="modal-footer bg-red" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="button" class="btn btn-outline" id="confirm_cancel_to_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
    </div>
  </div>
</div>

<!---- Approve SO -->
<div class="modal fade" id="approve_so_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header bg-green">
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="status_title">
          Approve Special Order
        </h4>
      </div>
      <!-- Modal Body For Update -->
        <input type="hidden" name="dtsno" value="<?= $dtsno ?>">
        <div class="modal-body">
          <label>With Claim?</label>
          <select class="form-control select2" id="is_with_claim" name="is_with_claim">
            <option value="YES">YES</option>
            <option value="NO">NO</option>
          </select>
        </div>
        <div class="modal-footer bg-green" align="right">
          <button type="button" class="btn btn-outline" data-dismiss="modal">
            <i class="fa fa-times fa-lg"></i>&nbsp; CLOSE
          </button>
          <button type="button" class="btn btn-outline" id="confirm_approve_so_btn">
            <i class="fa fa-save fa-lg"></i> Confirm
          </button>
        </div>
    </div>
  </div>
</div>
